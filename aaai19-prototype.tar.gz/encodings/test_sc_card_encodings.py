from __future__ import print_function, division
import os
import argparse
import os
import numpy as np
import math 
from utils import *
import string
from con2cnf import *
import random

parser = argparse.ArgumentParser(description='Test SC card')
parser.add_argument('--nbtest', '-t', default=100, help='number of tests')
parser.add_argument('--nblits', '-n', default=10, help='number of lits')

args = parser.parse_args()
args.nbtest = int(args.nbtest)
args.nblits = int(args.nblits)

def test_sc_card_reified():
    # We test: 
    # sum lits_i >= k <=> o
    random.seed(0)
    
    cnt = 0

    


    

    
    temp_file = "test_sc_card.txt";
    output_file = "test_sc_card.cnf";
    solver_result_file = "solver_res.txt";
   
    project_dir = '/home/nina/workspace/loglearn/'
    while(cnt < args.nbtest):

        print(">>test<< Test #", cnt)
        nb_lits = random.randrange(1, args.nblits + 1)
        print(">>test<< nb_lits = ", nb_lits)
        k = random.randrange(0, nb_lits)
        
        polarities = np.random.choice(a=[-1, 1], size=(nb_lits))
        vars_ids = []
        varids2cnf_varids = {}
        for i in range(0, nb_lits):
            x_id = "x_{}".format(i)
            vars_ids.append(x_id)
            varids2cnf_varids[x_id] = i + 1;
                
        
        
        coeffs = polarities
        vars_ids = vars_ids
       
        output_var_id = "z"
        varids2cnf_varids[output_var_id] = nb_lits + 1;
    
        constterm = -k
        print(">>test<< coeffs = ", polarities)
        print(">>test<< vars_ids = ", vars_ids)
        print(">>test<< output_var_id = ", output_var_id)
        print(">>test<< constterm = ", constterm)
        
        cnf_file = open(temp_file, 'w')
        cnt += 1
        
        # generate assignment 
        assign_x = np.random.choice(a=[0, 1], size=(nb_lits))
        assign_z = np.random.choice(a=[0, 1], size=(1))
        print(">>test<< assignment of x = ", assign_x)
        print(">>test<< assignment of output = ", assign_z)

        # compute output 
        s = 0
        for i in range(0, nb_lits):
            if (assign_x[i] > 0):
                if (polarities[i] > 0):
                    s = s + 1
                else: 
                    s = s - 1
        result = bool(s + constterm >= 0) == bool(assign_z[0])
        
        print(">>test<< true outcome={}: sum  +  rhs = ({} + {}) >= 0;  generated output = {}".format(result, s, constterm, assign_z[0]))
     
        
        # add constraints
        for i in range(0, nb_lits):     
            x_id = "x_{}".format(i)
            unary_constraint4bool_var(cnf_file, varids2cnf_varids, [x_id, assign_x[i]])
        
        unary_constraint4bool_var(cnf_file, varids2cnf_varids, [output_var_id, assign_z[0]])
        seqcounters4unary_coeff_linear_reified(cnf_file, varids2cnf_varids, coeffs, vars_ids, output_var_id, constterm)
        cnf_file.close() 
        add_first_line2cnf(temp_file, output_file, len(varids2cnf_varids))
        
        # execute SAT solver
        os.system(project_dir + '/src/encodings/glucose/glucose_static  -model ' + project_dir + output_file + " > " + project_dir + solver_result_file)
        
        # parse the output of the solver   
        sat_result, model = process_SAT_solver_output(project_dir + solver_result_file)    
        print(sat_result, model)
        # check if it produced the wright outcome                        
        if (result == True and  sat_result == 'UNSATISFIABLE'):
            print("Invalid encoding, should be SAT")
            exit()
        if (result == False and  sat_result == 'SATISFIABLE'):
            print("Invalid encoding, should be UNSAT")
            exit() 
            
        if (result):
            for i in range(0, nb_lits):     
                x_id = "x_{}".format(i)
                if (assign_x[i] != (True  if model[varids2cnf_varids[x_id] ] >= 0 else False)):
                    print("x gets an invalid value, should be {}, model {}".format(assign_x[i], model[varids2cnf_varids[x_id]]))
                    exit()         
                if (assign_z[0] != (True  if model[varids2cnf_varids[output_var_id] ] >= 0 else False)):
                    print("z gets an invalid value, should be {}".format(x))
                    exit() 
            
    print("SUCCESS")
test_sc_card_reified()
