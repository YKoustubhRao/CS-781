from __future__ import print_function, division
import os
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from torch.autograd import Variable
from torchvision.transforms import ToTensor
from torchvision.datasets import ImageFolder
from torch.utils.data import Dataset, DataLoader
import os
from PIL import Image
from PIL import ImageOps
import torchvision.models as models

import pandas as pd
from skimage import io, transform
import numpy as np
import matplotlib.pyplot as plt
from adam import Adam

#import pandas as pd
import numpy as np
from parser import *
from con2cnf import *
from utils import *
from bnnencoder import *
from bnnlearner import *
from satsolver import *
from pyminisolvers import minisolvers
import copy
import z3
import math 
import string


# python3.5 /home/nina/workspace/loglearn/src/encodings/main.py --database /home/nina/workspace/loglearn/flow_data/ --network  /home/nina/workspace/loglearn/flow_data/networks/16x16_200_100_100_1/ --process 'Generator2ILP'  --gen_nb_grains 3 --gen_central_points_i 3 13 8 --gen_central_points_j 3 13 8 --gen_output_min 10 --gen_output_max 20 --seed 10000
#  python src/encodings/main.py -s src/encodings/tests/input.txt -c cnf.txt
parser = argparse.ArgumentParser(description='BNN to CNF')
parser.add_argument('--database', '-d', default='mnist10_10', help='Input description file')
parser.add_argument('--gencnfs', '-g', default= False, help='Generate CNF files before running SAT solver')
parser.add_argument('--process', '-p', default= ACTION_CONVER2CNF)
parser.add_argument('--focuslabels_teacher', '-f', nargs='+', type=int, default=[0,1,2,3,4,5,6,7,8,9])
# parser.add_argument('--source', '-s', default='', help='Inputdescription file')
parser.add_argument('--network', '-w', default='', help='Network file')
parser.add_argument('--reduce',   default= True)
parser.add_argument('--restore',  default= False)
parser.add_argument('--acc_drop',  type=float, default=0.0)
parser.add_argument('--gen_nb_grains',  type=int, default=3)
parser.add_argument('--gen_central_points_i',  nargs='+', type=int, default=[])
parser.add_argument('--gen_central_points_j',  nargs='+', type=int, default=[])
parser.add_argument('--gen_output_min',  type=int, default= 50)
parser.add_argument('--gen_output_max',  type=int, default= 60)
parser.add_argument('--seed',  type=int, default= 0)
parser.add_argument('--timelim',  type=int, default= 60)
parser.add_argument('--saveimages',  default= '')
parser.add_argument('--prev_circle',  nargs='+', type=int, default=[])
parser.add_argument('--card_min',  nargs='+', type=int, default=[])
parser.add_argument('--card_max',  nargs='+', type=int, default=[])

parser.add_argument('--lr',  type=float, default= 0.01)


# parser.add_argument('--definenetwork', '-d', default='./data/mnist/mnist_define.txt', help='Network description file')
# parser.add_argument('--cnfdest', '-c', default='./cnf.txt', help='Output CNF file')
# parser.add_argument('--data', '-a', default='./data/mnist/images_train_vec/', help='Output CNF file')

s = z3.Solver()
args = parser.parse_args()
#args.small_test = ""#test1"
args.cnfdest = './cnf.txt'

if ("mnist" in args.database):
    print("consider mnist")

    args.definenetwork = args.database + '/mnist_define.txt'
    args.network =  args.network + '/mnist.txt'
    args.data_train =  args.database + '/images_train_vec/'
    args.data_test = args.database + '/images_test_vec/'
    args.small_test = False
    network_definition = args.network
elif ("flow" in args.database):
    args.network =  args.network + '/flow.txt'
    args.data_train =  args.database + '/images_train_vec/'
    args.data_test = args.database + '/images_test_vec/'
    args.small_test = False
    network_definition = args.network
else:
    args.database = "test1"
    args.definenetwork = './data/small_tests/' + args.database + '/network_define.txt'
    args.network = './data/small_tests/' + args.database + '/network.txt'
    args.data_train = './data/small_tests/' + args.database + '/inputs/'
    args.small_test = True
    network_definition = args.definenetwork

    

print(args.data_train)
####################################3
# Convert to CNF
#######################################


if (args.process in ACTION_CONVER2CNF):
    bnnconvertor = BNNConvertor(args, network_definition)    
    bnnconvertor.run()
    exit()          


####################################3
# Convert to ILP to generate images
#######################################

if (args.process in ACTION_GENERATOR2ILP):
    bnngenerator = BNNGenerator(args, network_definition)    
    bnngenerator.run()
    exit()          

####################################3
# Learn last layer
#######################################
    
if (args.process in ACTION_LEARNLASTLAYER):
    bnnconvertor = BNNConvertor(args, network_definition)    
    bnnconvertor.run_learn_last_layer()
    exit()          
        
if (args.process in ACTION_LEARNREDUCELASTLAYER):
    bnnconvertor = BNNConvertor(args, network_definition)    
    bnnconvertor.run_learn_incremental_reduce_last_layer()
    exit()            
        
        
####################################3
# Learn CNF
#######################################          
if (args.process in 'Learner'):
    ############################
    # STEP 1 Create learner 
    ############################
    
    bnnlearner = BNNLearner(args, network_definition)
    learnable_parameters =  bnnlearner.get_learnable_parameters()
    
    ############################################
    # STEP 2 Create assignment of A
    ###########################################
    
    if (args.small_test):
         layers = parse_network(args.network)
         test_var2cnf = {}
         test_bnnenc = BNNEncoder(args.network, test_var2cnf) 
         a_test = test_bnnenc.get_learnable_vars_asignment_as_dict()
         #print(a_test)
    else:     
        a_test = {}
        for a_id in learnable_parameters:
            a_test[a_id] = np.random.choice(a=[-1, 1], size=(1))
        #print(a_test)
    
    ############################
    # STEP 3 Run forward path  
    ############################
    
    learner_result, purecore = bnnlearner.run(a_test)
    if (learner_result == LEARNER_NEG_RESULT):
        print("Core size = {} out of {}".format(len(purecore), len(learnable_parameters)))
