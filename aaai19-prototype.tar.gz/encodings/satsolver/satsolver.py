from __future__ import print_function, division
import numpy as np
from parser import *
import json
import math 
import string
from pyminisolvers import minisolvers
import time

class MinisatSolverExt(object):
    def __init__(self, cnf_infile = None, assump_infile = None, polarity= None, rand_seed=None, var2cnf = None, nb_sat_vars = None, is_progress_bar = None):
        
        self.s = minisolvers.MinisatSolver()
        self.var2cnf = var2cnf
        self.nb_sat_vars = nb_sat_vars       
        self.is_progress_bar = is_progress_bar
        self.assumptions = []
        # Initialize random seed and randomize variable activity if seed is given
        if rand_seed is not None:
            self.s.set_rnd_seed(rand_seed)
            self.s.set_rnd_init_act(True)

        if cnf_infile is not None:
            self.read_dimacs(cnf_infile)
        else:
            while self.s.nvars() < self.nb_sat_vars:
            # let instance variables do whatever...

                if (polarity is None):
                    self.s.new_var()
                else:
                    c = np.random.choice([0, 1], size=(1,), p=[2/10, 8/10])
                    bc =  (c[0] == 1)
                    self.s.new_var(polarity = bc)
            
        if assump_infile is not None:
            self.read_assumptions(assump_infile)
        

    def populate_solver(self, constraints):                    
        self.s = minisolvers.MinisatSolver()
        self.assumptions = []
        cnt_prefix = 0
        l = len(constraints)
        if (self.is_progress_bar == True):
            printProgressBar(0, l, prefix = 'Progress:', suffix = 'Complete', length = 50 )
        start = time.time()
        for keys, values in sorted(constraints.items()):               
            con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + str(cnt_prefix) + "_"
            if (UNARY_CON_ID in keys): 
                unary_constraint4bool_var([SOLVER_DESTINATION, self.s], self.var2cnf, x=values[0], value=values[1])            
            if (ASSUMPTION_CON_ID in keys): 
                assumption_constraint4bool_var([LIST_DESTINATION, self.assumptions], self.var2cnf, x=values[0], value=values[1])            
            if (XOR_CON_ID  in keys): 
                xor_input_reified([SOLVER_DESTINATION, self.s], self.var2cnf, x=values[0], y=values[1], z=values[2], constraint_prefix=con_prefix)            
            if (NXOR_CON_ID  in keys): 
                nxor_input_reified([SOLVER_DESTINATION, self.s], self.var2cnf, x=values[0], y=values[1], z=values[2], constraint_prefix=con_prefix)            
            if (WRAP_A_MULT_X_CON_ID  in keys): 
                wrap_a_mult_x_input_reified([SOLVER_DESTINATION, self.s], self.var2cnf, r=values[0], b=values[1], w=values[2], s=values[3], constraint_prefix=con_prefix)            
            if (LIN_REIFIED_CON_ID  in keys):
                seqcounters4unary_coeff_linear_reified([SOLVER_DESTINATION, self.s], self.var2cnf, coeffs=values[0], vars_ids=values[1], output_var_id=values[2], constterm=values[3], constraint_prefix=con_prefix)
            cnt_prefix += 1  
            if (self.is_progress_bar == True):
                printProgressBar(cnt_prefix, l, prefix = 'Progress:', suffix = 'Complete', length = 50)
        #print("Total number of clause {}, generation time {}".format(self.s.nclauses(), time.time() - start))

     
    def parse_dimacs(self, f):
        i = 0
        for line in f:
            #print("read line :", line)
            if line.startswith(b'p'):
                tokens = line.split()
                self.nvars = int(tokens[2])
                self.nclauses = int(tokens[3])
                while self.s.nvars() < self.nvars:
                    # let instance variables do whatever...
                    self.s.new_var()
                continue

            if line.startswith(b'c'):
                continue

            line = line.strip()
            if line == b'':
                continue

            vals = line.split()
            assert vals[-1] == b'0'
            
            clause = [int(x) for x in vals[:-1]]
            self.s.add_clause(clause)

            i += 1

        assert i == self.nclauses
        
    def read_assumptions(self, infile):
        self.assumptions = []
        for line in infile:
            #print("read line :", line)
            vals = line.split()
            clause = [int(x) for x in vals[:-1]]
            self.assumptions.append(clause[0])
            #print(self.assumptions)
            
    def read_dimacs(self, infile):
        if infile.name.endswith('.gz'):
            # use gzip to decompress
            infile.close()
            with gzip.open(infile.name, 'rb') as gz_f:
                self.parse_dimacs(gz_f)
        else:
            # XXX TODO: using open() here to avoid dupe infile object for parallel branch,
            #           but this breaks reading from stdin.
            # assume plain .cnf and pass through the file object
            with open(infile.name, 'rb') as f:
                self.parse_dimacs(f)
    
    def update_assumptions(self, assumptions):
        self.assumptions = assumptions
    
    def solve_limited(self):
        #print(self.assumptions, len(self.assumptions))
        if (len(self.assumptions) > 0):
            result = self.s.solve(self.assumptions)
        else:    
            result = self.s.solve()
        model = []
        purecore = [] # just assigmnts that are NOT negated 
                
        if (result):
            model = self.s.get_model(0, self.s.nvars()) 
            result  = SOLVER_SAT_RESULT
            #print("SAT, model: ", model)

        else:
            purecore =  self.s.unsat_core()
            result  = SOLVER_UNSAT_RESULT            
            #print("UNSAT, core: ", purecore)

        return result, model, list(purecore) 

#     def check_subset(self, seed, improve_seed=False):
#         is_sat = self.s.solve_subset([i-1 for i in seed])
#         if improve_seed:
#             if is_sat:
#                 seed = self.s.sat_subset(offset=1)
#             else:
#                 seed = self.s.unsat_core(offset=1)
#             return is_sat, seed
#         else:
#             return is_sat
# 
#     def complement(self, aset):
#         return set(range(1, self.n+1)).difference(aset)
# 
#     def shrink(self, seed):
#         hard = self._msolver.implies()
#         current = set(seed)
#         for i in seed:
#             if i not in current or i in hard:
#                 # May have been "also-removed"
#                 continue
#             current.remove(i)
#             if not self.check_subset(current):
#                 # Remove any also-removed constraints
#                 current = set(self.s.unsat_core(offset=1))  # helps a bit
#             else:
#                 current.add(i)
#         return current
# 
#     def to_c_lits(self, seed):
#         # this is slow...
#         nv = self.nvars+1
#         return [nv + i for i in seed]
# 
#     def check_above(self, seed):
#         comp = self.complement(seed)
#         x = self.s.new_var() + 1
#         self.s.add_clause([-x] + self.to_c_lits(comp))  # add a temporary clause
#         ret = self.s.solve([x] + self.to_c_lits(seed))  # activate the temporary clause and all seed clauses
#         self.s.add_clause([-x])  # remove the temporary clause
#         return ret
# 
#     def grow(self, seed):
#         current = seed
# 
#         #while self.check_above(current):
#         #    current = self.s.sat_subset()
#         #return current
# 
#         # a bit slower at times, much faster others...
#         for x in self.complement(current):
#             # skip any included by sat_subset()
#             assumes seed is always sorted
#             i = bisect.bisect_left(current, x)
#             if i != len(current) and current[i] == x:
#                 continue
# 
#             current.append(x)
#             if self.check_subset(current):
#                 # Add any also-satisfied constraint
#                 current = self.s.sat_subset(offset=1)
#             else:
#                 current.pop()
# 
#         return current


