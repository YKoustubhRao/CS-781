from __future__ import print_function, division
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from torch.autograd import Variable
from torch.utils.data import Dataset, DataLoader
import os
from PIL import Image
from PIL import ImageOps
import torchvision.models as models

import pandas as pd
from skimage import io, transform
import numpy as np
import matplotlib.pyplot as plt
from adam import Adam

import numpy as np
import json
import math 
import string
from parser import *
from con2cnf import *
from utils import *
from bnnencoder import *
from bnnlearner import *
from satsolver import *
from pyminisolvers import minisolvers
import copy
import ntpath
import pprint
from bnn import *


class BNNConvertor(object):
    """A encoding of BNN to CNFs:
    
    Attributes:
        config file: network structure
    """

    def __init__(self, args, network_definition):
        self.args  = args

        self.sample_test_files = [] 
        for label in args.focuslabels_teacher:
            path  = args.data_test + "/" + str(label) + "/"
            for name in os.listdir(path):
                if os.path.isfile(os.path.join(path, name)):
                    self.sample_test_files.append(path + name)
        

        self.sample_files = [] 
        for label in args.focuslabels_teacher:
            path  = args.data_train + "/" + str(label) + "/"
            for name in os.listdir(path):
                if os.path.isfile(os.path.join(path, name)):
                    self.sample_files.append(path + name)
        
        self.sample_inputs = {}
        
        self.nb_images = len( self.sample_files)
        
        # init network
        self.var2cnf = {}
        #print("reading network {}".format(args.definenetwork))
        self.bnnenc = BNNEncoder4Convertor(network_definition, self.var2cnf) 
                
    def save_cnf(self, constraints, constraints_ordering, cnf_file_name, var2cnf):     
        cnf_file_name = cnf_file_name + CNF_FILE_TEMP_EXTENTION 
        assumption_file_name = cnf_file_name + ASSUMPTIONS_FILE_TEMP_EXTENTION
        temp_file = cnf_file_name + FILE_TEMP_EXTENTION;
        cnf_file = open(temp_file, 'w')
        assump_cnf_file = open(assumption_file_name, 'w')
        l = len(constraints)
        #printProgressBar(0, l, prefix = 'Progress:', suffix = 'Complete', length = 50 ) 
        cnt_prefix = 0
        for i,keys in constraints_ordering.items():
            values = constraints[keys]
            #print(i, keys, constraints[keys])    
            con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + str(cnt_prefix) + "_"
            if (UNARY_CON_ID in keys):
                unary_constraint4bool_var([CNF_DESTINATION, cnf_file],var2cnf, x=values[0], value=values[1])            
            if (ASSUMPTION_CON_ID in keys): 
                assumption_constraint4bool_var([CNF_DESTINATION, assump_cnf_file], var2cnf, x=values[0], value=values[1])            
            if (NXOR_CON_ID  in keys): 
                nxor_input_reified([CNF_DESTINATION, cnf_file], var2cnf, x=values[0], y=values[1], z=values[2], constraint_prefix=con_prefix)            
            if (XOR_CON_ID  in keys): 
                xor_input_reified([CNF_DESTINATION, cnf_file], var2cnf, x=values[0], y=values[1], z=values[2], constraint_prefix=con_prefix)
            if (WRAP_A_MULT_X_CON_ID  in keys): 
                wrap_a_mult_x_input_reified([SOLVER_DESTINATION, cnf_file], self.var2cnf, r=values[0], b=values[1], w=values[2], s=values[3], constraint_prefix=con_prefix)                               
            if (LIN_REIFIED_CON_ID  in keys):
                seqcounters4unary_coeff_linear_reified([CNF_DESTINATION, cnf_file], var2cnf, coeffs=values[0], vars_ids=values[1], output_var_id=values[2], constterm=values[3], constraint_prefix=con_prefix)
            #printProgressBar(cnt_prefix, l, prefix = 'Progress:', suffix = 'Complete', length = 50)
            cnt_prefix += 1     
         
             
        cnf_file.close()
        assump_cnf_file.close()
        add_first_line2cnf(temp_file, cnf_file_name, len(var2cnf))    
        return cnf_file_name, assumption_file_name  
    
    def run_muser_gcnf(self, constraints, constraints_ordering, gcnf_file_name, var2cnf, is_suffle_asm = True, reuse_cnf_file_name = False):     
        
        cnf_file_name  = self.save_gcnf(constraints = constraints, constraints_ordering = constraints_ordering,  gcnf_file_name = gcnf_file_name, var2cnf = var2cnf, is_suffle_asm = is_suffle_asm, reuse_cnf_file_name= reuse_cnf_file_name)
        assumption_file_name = self.save_assumptions(constraints, constraints_ordering, gcnf_file_name, var2cnf, is_suffle_asm)       
        gcnf_file_name = gcnf_file_name + GCNF_FILE_TEMP_EXTENTION 
        group2asm = cnf_asm2gcnf(cnf_file_name, assumption_file_name, gcnf_file_name,  len(var2cnf), is_suffle_asm)
        muser_core = self.gen_mus_gcnf(gcnf_file_name, group2asm)
        return muser_core

    def gen_mus_gcnf(self, gcnf_file_name, group2asm):     
        gcnf_file_name_out  = gcnf_file_name + GCNF_FILE_OUT_EXTENTION
        exe_str = EXE_FILES_DIR + "muser-2 -grp -comp ./" + gcnf_file_name + " > " + gcnf_file_name_out
        #print(exe_str) 
        os.system(exe_str)
        
        #print(group2asm)
        try:
            gcnf_file_out = open(gcnf_file_name_out, "r+") # or "a+", whatever you need
        except IOError:
            print ("cannot open {}".format(gcnf_file_name_out))
            exit()
        with gcnf_file_out:
            gcnf_lines_raw = gcnf_file_out.read().splitlines()
            gcnf_lines = iter(gcnf_lines_raw)
            gcnf_file_out.close()
        
        muser_core  = []
        for line in gcnf_lines:
            if line[0] == 'v':
                line = line[1:].split()
                #print(line)
                for l in line:
                    int_l = int(l)
                    if (int_l > 0):
                        muser_core.append(group2asm[l])

        return muser_core
    def save_assumptions(self, constraints, constraints_ordering, gcnf_file_name, var2cnf, is_suffle_asm):     
        assumption_file_name = gcnf_file_name + ASSUMPTIONS_FILE_TEMP_EXTENTION
        assump_cnf_file = open(assumption_file_name, 'w')
        l = len(constraints)
        cnt_prefix = 0
        for i,keys in constraints_ordering.items():
            values = constraints[keys]
            con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + str(cnt_prefix) + "_"
            if (ASSUMPTION_CON_ID in keys): 
                assumption_constraint4bool_var([CNF_DESTINATION, assump_cnf_file], var2cnf, x=values[0], value=values[1])            
            cnt_prefix += 1             
        assump_cnf_file.close()        
        return assumption_file_name 

    def save_gcnf(self, constraints, constraints_ordering, gcnf_file_name, var2cnf, is_suffle_asm, reuse_cnf_file_name):     
        cnf_file_name = gcnf_file_name + FILE_TEMP_EXTENTION;        
        
        if (reuse_cnf_file_name != False):
            return cnf_file_name
        
        
        cnf_file = open(cnf_file_name, 'w')
        l = len(constraints)
        #printProgressBar(0, l, prefix = 'Progress:', suffix = 'Complete', length = 50 ) 
        cnt_prefix = 0
        for i,keys in constraints_ordering.items():
            values = constraints[keys]
            #print(i, keys, constraints[keys])    
            con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + str(cnt_prefix) + "_"
            if (UNARY_CON_ID in keys):
                unary_constraint4bool_var([CNF_DESTINATION, cnf_file],var2cnf, x=values[0], value=values[1])            
            if (NXOR_CON_ID  in keys): 
                nxor_input_reified([CNF_DESTINATION, cnf_file], var2cnf, x=values[0], y=values[1], z=values[2], constraint_prefix=con_prefix)            
            if (XOR_CON_ID  in keys): 
                xor_input_reified([CNF_DESTINATION, cnf_file], var2cnf, x=values[0], y=values[1], z=values[2], constraint_prefix=con_prefix)   
            if (WRAP_A_MULT_X_CON_ID  in keys): 
                wrap_a_mult_x_input_reified([CNF_DESTINATION, cnf_file], self.var2cnf, r=values[0], b=values[1], w=values[2], s=values[3], constraint_prefix=con_prefix)                               
            if (LIN_REIFIED_CON_ID  in keys):
                seqcounters4unary_coeff_linear_reified([CNF_DESTINATION, cnf_file], var2cnf, coeffs=values[0], vars_ids=values[1], output_var_id=values[2], constterm=values[3], constraint_prefix=con_prefix)
            #printProgressBar(cnt_prefix, l, prefix = 'Progress:', suffix = 'Complete', length = 50)
            cnt_prefix += 1     
         
             
        cnf_file.close()
        return cnf_file_name

    def load_train_inputs(self):        
        nb_sample = 0
        for sample_file in self.sample_files:
            input, true_label = parse_input(sample_file, self.args.focuslabels_teacher)
            self.sample_inputs[nb_sample] = [input, true_label]
            nb_sample +=1
    
    def compute_train_accuracy(self):
        acc = 0
        tie = 0
        if (len(self.sample_inputs) == 0):
             self.load_train_inputs()
        for i, input_info in self.sample_inputs.items():
            # we need to propagate all by the lasyr layer
            #########################
            # Read input file
            # We assume that all inputs/matrices are 1/-1
            #########################
            #print("Reading input: {}".format(sample_file))            
            input = input_info[0]
            true_label = input_info[1]
            #print_vec_as_textimage(input[:], self.bnnenc.side)       
            forward_assignments, winner = self.bnnenc.forward(input[:])
            #print("original network winner {} true winner {}".format(winner, true_label))
            #print("forward_assignments", forward_assignments)
            if (winner  == WINNER_TIE  or  winner == true_label):
               acc += 1              
            if (winner  == WINNER_TIE):
               tie +=1 
        no_tie_acc = (acc - tie)/(len(self.sample_files))        
        acc = acc/(len(self.sample_files))

        print("Train accuracy {0:.2f}/{1:.2f}".format(acc,no_tie_acc))


        return acc, no_tie_acc

    def compute_test_accuracy(self):
        acc = 0
        tie = 0
        for sample_file in self.sample_test_files:
            # we need to propagate all by the lasyr layer
            #########################
            # Read input file
            # We assume that all inputs/matrices are 1/-1
            #########################
            #print("Reading input: {}".format(sample_file))            
            input, true_label = parse_input(sample_file, self.args.focuslabels_teacher)
            #print_vec_as_textimage(input[:], self.bnnenc.side)       
            forward_assignments, winner = self.bnnenc.forward(input[:])
            #print("original network winner {} true winner {}".format(winner, true_label))
            #print("forward_assignments", forward_assignments)
            if (winner  == WINNER_TIE  or  winner == true_label):
               acc += 1              
            if (winner  == WINNER_TIE):
               tie +=1 
        print("Test accuracy {}: {}/{}, ties {}".format(acc/(len(self.sample_test_files)), acc, len(self.sample_test_files), tie))    

        no_tie_acc = (acc - tie)/(len(self.sample_test_files))        
        acc = acc/(len(self.sample_test_files))
            
    def generate_input_features(self, layerL_local, thresh_reasonable_occ):
        inputs_features_prep = {}
        for sample_file in self.sample_files:
            # we need to propagate all by the lasyr layer
            #########################
            # Read input file
            # We assume that all inputs/matrices are 1/-1
            #########################
            #print("Reading input: {}".format(sample_file))            
            input, true_label = parse_input(sample_file, self.args.focuslabels_teacher)
            #print_vec_as_textimage(input[:], self.bnnenc.side)       
            forward_assignments, winner = self.bnnenc.forward(input[:])
            #print("original network winner {} true winner {}".format(winner, true_label))
            #print("forward_assignments", forward_assignments)
            #if (winner < 0  or  winner != true_label):
            #    print("skip this example")
            #    continue
             
            y_input = {}
            nb_input = layerL_local.nb_cols
            for i in range(0, nb_input):
                y_id = create_indexed_variable_name(NEURON_VAR_ID, [layerL_local.id, i]) 
                y_input[y_id] = forward_assignments[y_id]
            key = str(y_input)
            if key not in inputs_features_prep:
                inputs_features_prep[key] = [y_input, true_label]
            else:
                inputs_features_prep[key].append(true_label)
            #inputs_features_labels.append(true_label)
        #pp = pprint.PrettyPrinter(indent=4)
        #pp.pprint(inputs_features.values())
        inputs_features = {}
        for key in inputs_features_prep:
            labels = inputs_features_prep[key][1:]
            win_label = max(labels, key = labels.count)
            if (labels.count(win_label) >= thresh_reasonable_occ):
                inputs_features[key] = [inputs_features_prep[key][0], win_label]
                print(win_label, labels.count(win_label), inputs_features_prep[key][0])
        return inputs_features
  
    def manual_check_last_lin_layer(self, last_layer_input):
        ########################################################
        # check forward path                        
        print("Start extra checks...")
        print("Checking inputs")
        set_vars = {}
        print(last_layer_input)
       
        for y_id in last_layer_input:           
            y_id_val = last_layer_input[y_id]
            set_vars[y_id] = y_id_val
            print(y_id)
            sat_assignments = get_sat_value_by_id(y_id, var2cnf, model)
            if (sat_assignments != y_id_val):
                print("Input problem: ", y_id, "True ", y_id_val, "Comp", sat_assignments)
                exit()
        print("Inputs are ok")
       
        print("Checking coeffs")
        for i in range(0, layerL_local.nb_rows):
            for j in range(0, layerL_local.nb_cols):
                a_id = layerL_local.sym_a[i][j]
                a_id_val =  1  if layerL_local.a[i][j] >= 0 else 0 
                sat_assignments = get_sat_value_by_id(a_id, var2cnf, model)
                    
                set_vars[a_id] = a_id_val
                     
                if (sat_assignments != a_id_val):
                    print("Coef problem: ", a_id, "True ", a_id_val, "Comp", sat_assignments)

                r_id = layerL_local.sym_r[i][j]
                r_id_val =  1  if layerL_local.r[i][j] >= 1 else 0 
                sat_assignments = get_sat_value_by_id(r_id, var2cnf, model)
                    
                set_vars[r_id] = r_id_val
                     
                if (sat_assignments != r_id_val):
                    print("Coef Reduction problem: ", r_id, "True ", r_id_val, "Comp", sat_assignments)
                   
        print("Coeff/Reduction are ok, layer",)   
        for i in constraints_ordering:                        
            con_name = constraints_ordering[i]
            constraint = constraints[con_name]
            print_constraint(con_name, constraint)                                   
           
            if (UNARY_CON_ID in con_name): 
                [var_id, var_val] = constraint
                set_vars[var_id] = var_val
            if (ASSUMPTION_CON_ID in con_name): 
                [var_id, var_val] = constraint
                if (var_id in set_vars):
                    assert(var_val == var_val)
                else:    
                    set_vars[var_id] = var_val
            if (NXOR_CON_ID  in con_name):
                variables = constraint
                #print(variables)
                a  = set_vars[variables[0]]
                y  = set_vars[variables[1]]
                q_sat_assignments = get_sat_value_by_id(variables[2], var2cnf, model)
                print("Consider a({}) = {}, y({}) = {} sat({},{}) = {}".format(var2cnf[variables[0]], a, var2cnf[variables[1]], y,variables[2], var2cnf[variables[2]],q_sat_assignments))
                if (a*y == 1 and q_sat_assignments == 0) or (a*y == -1 and q_sat_assignments == 1):
                    print("NXOR problem: a=", variables[0], " y=", variables[1], "True=", a*y, "Comp", q_sat_assignments)
                    exit()
                else:
                    set_vars[variables[2]] = q_sat_assignments
                    print("OK")
            if (XOR_CON_ID  in con_name): 
                variables = constraint
                #print(variables)
                a  = set_vars[variables[0]]
                y  = set_vars[variables[1]]
                q_sat_assignments = get_sat_value_by_id(variables[2], var2cnf, model)
                print("Consider a={}, y={} sat ={}".format(a,y,q_sat_assignments))
                if (a*y == 1 and q_sat_assignments == 1) or (a*y == -1 and q_sat_assignments == 0):
                    print("XOR problem: a=", variables[0], " y=", variables[1], "True=", a*y, "Comp", q_sat_assignments)
                    exit()
                else:
                    set_vars[variables[2]] = q_sat_assignments
                    print("OK")
                    exit()            
            if (WRAP_A_MULT_X_CON_ID  in con_name):
                [r_id, b_id, w_id, s_id] = constraint
                r  = set_vars[r_id]
                b  = set_vars[b_id]
               
                w_sat_assignments = get_sat_value_by_id(w_id, var2cnf, model)
                s_sat_assignments = get_sat_value_by_id(s_id, var2cnf, model)
                #print(model)
                #it_var = 1491  
                #it_var_sat_assignments = get_sat_value_by_cnf_id(it_var, model)

                if (r == 0 and b == 0):
                    set_vars[w_id] = 0
                    set_vars[s_id] = 1
                   
                    if (w_sat_assignments == 1 or s_sat_assignments == 0):
                        print("WRAP_A_MULT_X_CON_ID problem: r={}, b={}, w=0, s=1 SAT w={}, s={}".format(r,b,w_sat_assignments,s_sat_assignments))
                        exit()
               
                if (r == 0 and b == 1):
                    set_vars[w_id] = 1
                    set_vars[s_id] = 0
                   
                    if (w_sat_assignments == 0 or s_sat_assignments == 1):
                        print("WRAP_A_MULT_X_CON_ID problem: r={}, b={}, w=1, s=0 SAT w={}, s={}".format(r,b,w_sat_assignments,s_sat_assignments))
                        exit()

                if (r == 1):
                    set_vars[w_id] = 0
                    set_vars[s_id] = 0
                   
                    if (w_sat_assignments == 1 or s_sat_assignments == 1):
                        print("WRAP_A_MULT_X_CON_ID problem: r={}, b={}, w=0, s=0 SAT w={}, s={}".format(r,b,w_sat_assignments,s_sat_assignments))
                        exit()
                           
            if (LIN_REIFIED_CON_ID  in con_name):
                [coeffs, vars_ids,  z_id, constterm] = constraint
                s = 0
                for i in range(len(vars_ids)):
                    a  = coeffs[i]
                    q  = set_vars[vars_ids[i]]
                    s = s + a*q
                    
                s = s + constterm
                    
                comp_y = 1 if s >= 0 else 0
                y_next_sat_assignments = get_sat_value_by_id(z_id, var2cnf, model)
                if (comp_y != y_next_sat_assignments):
                    print("LIN reified problem: sum a_x_i + cont > 0 ", comp_y, "Comp", y_sat_assignments)
                    exit()
                else:
                    set_vars[z_id] = y_next_sat_assignments
                    print("OK") 

        else:
            print("OK for this image")
        return True

#        o_dummy = []

#         for keys, values in sorted(constraints.items()):               
#             if (LIN_REIFIED_CON_ID  in keys):
#                 #print_constraint(keys, values)
#                 [coeffs, vars_ids,  z_id, constterm] = constraints[keys]
#                 s = 0
#                 for i in range(len(vars_ids)):
#                     coef  = coeffs[i]
#                      
#                     id = vars_ids[i].replace('[','_').replace(']','_')
#                     id  = id.split('_')
#                     k1 = id[2]
#                     i1 = id[4]
#                     j1 = id[6]
#                     t_y_id = create_indexed_variable_name(NEURON_VAR_ID, [k1, j1])
#                     t_a_id = create_indexed_variable_name(LAYER_VAR_ID, [k1, i1, j1])
#                                                      
#                     #print(t_a_id, assump[t_a_id])
#                     #print(t_y_id, forward_assignments[t_y_id]) 
#                     q  = (2*layerL.get_a_i_j_by_symbol(t_a_id)-1)*(2*forward_assignments[t_y_id]-1)
#                     s = s + coef*q
#                     #print(s, coef, q)
#                 s = s + constterm
#                 o_dummy.append(s)
        
    def run_learn_reduce_last_layer(self):
        init_start_time = time.time()
        acc_orig, no_tie_acc_orig =  self.compute_train_accuracy()
        self.compute_test_accuracy()
        #exit()
        debug = False
        blocking_clause = []
        all_correct = False
        total_runs = 0
        
        layerL = self.bnnenc.layers[-1]
        layerL_local = copy.deepcopy(self.bnnenc.layers[-1])
        layerL_local.use_reduction_a = True;
        print(layerL_local)                    
        
 
        
        cnt = 0
        thresh_reasonable_occ = len(self.sample_files)*0.005
        inputs_features =  self.generate_input_features(layerL_local, thresh_reasonable_occ) 
        #reduction_in_per = [1, 3, 6]
        #for row in range(layerL_local.nb_rows):
        #print("looking ar row {}".format(row))
        row2reduce = range(layerL_local.nb_rows)
        # set assumption variables
        learnable_parameters = layerL_local.get_all_symbols(rows = row2reduce)
        learnable_reduction_parameters = layerL_local.get_all_reduction_symbols(rows = row2reduce)        
        # we randomly reassign layer
        if (self.args.restore):
            layerL_local.set_a_to_constant(1, rows = row2reduce)
        layerL_local.set_r_to_constant(1, rows = row2reduce)
        #print(inputs_features)

        constrants_no_inputs = {}
        self.bnnenc.constraints_ordering = {}
        self.bnnenc.generate_last_linear_constraints_with_reduction(layerL_local, constrants_no_inputs, is_assum = True, row2reduce = row2reduce)        
        constraints_ordering = copy.deepcopy(self.bnnenc.constraints_ordering)
        #print_constraints(constrants_no_inputs)

        # assumption generator
        assum_mapping_global_asm_to_local = {}
        assum_var2cnf = {}
        for a_id in learnable_parameters:
            get_cnf_varid(assum_var2cnf, a_id)
            assum_mapping_global_asm_to_local[self.bnnenc.var2cnf[a_id]] = get_cnf_varid(assum_var2cnf, a_id)

        for r_id in learnable_reduction_parameters:
            get_cnf_varid(assum_var2cnf, r_id)
            assum_mapping_global_asm_to_local[self.bnnenc.var2cnf[r_id]] = get_cnf_varid(assum_var2cnf, r_id)

        #print(assum_mapping_global_asm_to_local, assum_var2cnf)

        assumption_solver = MinisatSolverExt(var2cnf = assum_var2cnf, nb_sat_vars = len(assum_var2cnf))        
        nb_correct = 0
        no_tie_acc = 0
        #nb_target = len(inputs_features)*0.95
        no_tie_acc_target = no_tie_acc_orig - self.args.acc_drop#*(reduction_in_per[row]/(2*layerL_local.nb_rows))
        acc_target = acc_orig - self.args.acc_drop
        ok_correct = False
        randw = randomword(7)
        while(not ok_correct):

            print("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< {0:d}, no_tie_acc={1:.2f}/{2:.2f}, blocks = {3:d},  {4:d}".format( nb_correct, no_tie_acc, no_tie_acc_target, len(blocking_clause), len(inputs_features)))
            nb_correct = 0
            nb_file = 0;
            #self.compute_test_accuracy()
            for key in inputs_features:                
                last_layer_input  = inputs_features[key][0]
                true_label = inputs_features[key][1]
                nb_file +=1
                # we work with originally correctly classified image
                start = time.time()
                constraints = {}                
                constraints = copy.deepcopy(constrants_no_inputs)
                var2cnf = copy.deepcopy(self.bnnenc.var2cnf)
                global_counter  = -1                 
                nb_input = layerL_local.nb_cols
                
                # reset assumptions
                for ra_id in assum_var2cnf:
                    v = layerL_local.get_var_i_j_by_symbol(ra_id)  
                    #print(ra_id,v, form_assumption_constraint_name(ra_id))
                    #print(constraints[form_assumption_constraint_name(a_id)])
                    constraints[form_assumption_constraint_name(ra_id)] = [ra_id,  1 if v >= 1 else 0]                
                    #print(constraints[form_assumption_constraint_name(a_id)])
                #exit()
                #print_constraints(constraints)

                # set imputs
                for i in range(0, nb_input):
                    y_id = create_indexed_variable_name(NEURON_VAR_ID, [layerL_local.id, i]) 
                    get_cnf_varid(var2cnf, y_id)
                    constraints[form_unary_constraint_name(y_id)] = [y_id, last_layer_input[y_id]] 
                    constraints_ordering[global_counter] = form_unary_constraint_name(y_id)
                    global_counter -= 1         
                # ensure the winner
                for j in range(0, self.bnnenc.layers[-1].nb_rows):        
                    if (true_label == j):
                        continue;
                    o_id = create_indexed_variable_name(ORDER_VAR_ID, [true_label, j])  
                    constraints[form_unary_constraint_name(o_id)] = [o_id, 1]  
                    constraints_ordering[global_counter] = form_unary_constraint_name(o_id)                    
                    # require strict ordering

                    o_id = create_indexed_variable_name(ORDER_VAR_ID, [j, true_label])  
                    constraints[form_unary_constraint_name(o_id)] = [o_id, 0]  
                    constraints_ordering[global_counter] = form_unary_constraint_name(o_id)
                    global_counter -= 1          
                                                 
                #print_constraints(constraints)

                if (debug):
                    print("Encoding total {}".format(time.time() -  start))
                constraints_ordering = dict(sorted(constraints_ordering.items()))
                #print_constraints(constraints)

                start = time.time()                
                #print_constraints(constraints)
                
                solver = MinisatSolverExt(var2cnf = var2cnf, nb_sat_vars = len(var2cnf))
                if (debug):
                    print("Create solver, # high-level constraints ({})".format(len(constraints)))      
                solver.populate_solver(copy.deepcopy(constraints))

                if (debug):   
                    print("Prepare solver {}".format(time.time() - start))
                    print("Run solver")            
                start = time.time()
                sat_result, model, purecore = solver.solve_limited()                    
                if (debug):
                    print("Solve time {}".format(time.time() - start))
                

                if (sat_result == SOLVER_SAT_RESULT):         
                    #print("OK")    
                    nb_correct += 1  
                    if (debug): 
                        manual_check_last_lin_layer(last_layer_input)
                    continue;                      
                if (sat_result == SOLVER_UNSAT_RESULT):
                    #print("UNSAT")
                    ####################################
                    # convertion to CNF
                    ####################################
                    #print(sample_file)
                    start = time.time()
                    reuse_cnf =  False
                    for r in range(10):
                        muser_core = self.run_muser_gcnf(constraints =  copy.deepcopy(constraints), 
                                                         constraints_ordering =  copy.deepcopy(constraints_ordering),  
                                                         gcnf_file_name = SAT_GEN_FILES_DIR + ntpath.basename("muser")+randw, 
                                                         var2cnf = var2cnf,
                                                         is_suffle_asm = True,
                                                         reuse_cnf_file_name = reuse_cnf)
                        reuse_cnf = True
                        muser_core.sort()
                        #print(muser_core)
                        clause = []
                        for a in muser_core:                            
                            #print(list(var2cnf.keys())[list(var2cnf.values()).index(abs(a))], end='')                            
                            clause.append(assum_mapping_global_asm_to_local[abs(a)] if a < 0 else -assum_mapping_global_asm_to_local[abs(a)])
                        clause.sort()
                        #print("<<")
                        #print(clause, len(clause))
                        if (clause not in blocking_clause):
                            blocking_clause.append(clause[:])
                    if (debug):                            
                        print("Gen cores {}".format(time.time() - start))
                    #exit()
                    
                    all_correct = False            
                    unsat_assignments = purecore
                    purecore.sort()
                    #print ("Core: ", purecore)
                    clause = []
                    #print(assum_mapping_global_asm_to_local)
                    for a in purecore:
                        clause.append(assum_mapping_global_asm_to_local[abs(a)] if a < 0 else -assum_mapping_global_asm_to_local[abs(a)])
                    #print(clause)
                    clause.sort()
                    if (clause not in blocking_clause):
                        blocking_clause.append(clause[:])
                    
                    # create assumption solver
                    if (self.args.reduce):
                        polarity = True
                    else:
                        polarity = None
                    assumption_solver = MinisatSolverExt(var2cnf = assum_var2cnf, polarity = polarity, nb_sat_vars = len(assum_var2cnf))        
                    for clause in blocking_clause:
                        assumption_solver.s.add_clause(clause)
                        #print(clause)
    
                    
                    # call assumption solver generator
                    #print('call assumption solver generator')
                    assumption_sat_result,  assumption_model,  assumption_purecore = assumption_solver.solve_limited()
                    
                    #print(assumption_model)
                    total_runs +=1
                    if (assumption_sat_result == SOLVER_SAT_RESULT):
                        for assum_id in assum_var2cnf:
                            v = get_sat_value_by_id(assum_id, assum_var2cnf, assumption_model)
                            if (layerL_local.is_a_i_j_by_symbol(assum_id)):
                                layerL_local.set_a_i_j_by_symbol(assum_id, 1 if v > 0 else -1)  
                            if (layerL_local.is_r_i_j_by_symbol(assum_id)):
                                layerL_local.set_r_i_j_by_symbol(assum_id, 1 if v > 0 else 0)  
                            #print(assum_id, v,  end='  ')
                        #print("<<")
                        #print(layerL_local)
                    #if (total_runs > 1):
                    #    exit()
                    if (assumption_sat_result == SOLVER_UNSAT_RESULT):
                        print("Fail to find")
                        exit()
                    
                    #print(no_tie_acc)
                    self.bnnenc.layers[-1] =layerL_local 
                    #print( self.bnnenc.layers[-1])            
                    acc, no_tie_acc = self.compute_train_accuracy()
                    
                    if ((no_tie_acc > no_tie_acc_target) and (acc > acc_target)):
                        ok_correct = True
                        break
                        
                    #exit()

                    #exit()
                    #break
                    #if (winner == true_label):
                    #    print("Error: UNSAT execution has a bug")
                    #    exit()
            
        print(layerL)    
        print(layerL_local)    
        self.bnnenc.layers[-1] =copy.deepcopy(layerL_local)
        print("Total time ", time.time() - init_start_time) 
        self.compute_train_accuracy()
        self.compute_test_accuracy()
    
    def prepare_block_from_core(self, core, assum_mapping_global_asm_to_local):
        core.sort()
        #print(muser_core)
        clause = []
        for a in core:                            
            #print(list(var2cnf.keys())[list(var2cnf.values()).index(abs(a))], end='')                            
            clause.append(assum_mapping_global_asm_to_local[abs(a)] if a < 0 else -assum_mapping_global_asm_to_local[abs(a)])
        clause.sort()
        return clause

    def train_network_layer(self, model, nbclasses, nbinputs, layerL_local, images, labels, labels_clone):
        mask = torch.FloatTensor(nbclasses, nbinputs)
        weights = torch.FloatTensor(nbclasses, nbinputs)
        
        for i in range(0, layerL_local.nb_rows):
            for j in range(0, layerL_local.nb_cols):
                mask[i][j] = float(1 - layerL_local.r[i][j])
                weights[i][j] = float(layerL_local.a[i][j])
       
        mask = Variable(mask.cuda())
        model.bfc.mask = mask
        #model.bfc.weights = weights
        optimizer = Adam(model.parameters(), lr=self.args.lr)
        criterion = nn.CrossEntropyLoss()  

        print("start train ")
        model.train()
        
        correct = 0
        total = 0        
        iter = 0
        max_iter = 200
        lr_decay = compute_lr_decay(self.args.lr, max_iter)
        while (iter < max_iter):  
        # Convert torch tensor to Variable
            #print(i, images,labels)
            #print(images, labels)
            correct = 0           

            # Forward + Backward + Optimize
            optimizer.zero_grad()  # zero the gradient buffer
            outputs = model(images)
            #print(outputs)
            maxs, predicted = torch.max(outputs.data, 1)
            total += labels_clone.size(0)
            for j in range(len(maxs)):
                l = labels_clone[j]
                ol = predicted[j]
                if (ol == l):
                    correct += 1
                    #print("+1",ol, l)
            #exit()
            #print(predicted, labels_clone)
            #exit()
            
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
    
            clip_weight(model.parameters())
                #print(outputs, labels,maxs,labels_clone)
            iter +=1
            #print(all_inputs_matrix)
            train_loss = correct/len(maxs)
            adjust_learning_rate(optimizer, lr_decay)
            #print ('Step [%d], Loss: %.4f' 
            #        %(iter+1,correct/len(maxs)))

            if (max_iter == iter):
                print ('Step [%d], Loss: %.4f' 
                       %(iter+1,correct/len(maxs)))
                trained_reduced_matrix = model.bfc.get_bin_reduced_matrix()
                print(trained_reduced_matrix)
                for i in range(0, layerL_local.nb_rows):
                    for j in range(0, layerL_local.nb_cols):                           
                        layerL_local.a[i][j] =  1 if trained_reduced_matrix.cpu().data[i][j] > 0 else -1

        return train_loss, layerL_local
    def run_learn_incremental_reduce_last_layer(self):
        init_start_time = time.time()
        acc_orig, no_tie_acc_orig =  self.compute_train_accuracy()
        self.compute_test_accuracy()
        #exit()
        debug = False
        blocking_clause = []
        all_correct = False
        total_runs = 0
        
        layerL = self.bnnenc.layers[-1]
        layerL_local = copy.deepcopy(self.bnnenc.layers[-1])
        layerL_local.use_reduction_a = True;
        print(layerL_local)                    
        
 
        
        cnt = 0
        thresh_reasonable_occ = len(self.sample_files)*0.005
        inputs_features =  self.generate_input_features(layerL_local, thresh_reasonable_occ) 
        #reduction_in_per = [1, 3, 6]
        #for row in range(layerL_local.nb_rows):
        #print("looking ar row {}".format(row))
        row2reduce = range(layerL_local.nb_rows)
        # set assumption variables
        learnable_parameters = layerL_local.get_all_symbols(rows = row2reduce)
        learnable_reduction_parameters = layerL_local.get_all_reduction_symbols(rows = row2reduce)        
        # we randomly reassign layer
        if (self.args.restore):
            layerL_local.set_a_to_constant(1, rows = row2reduce)
        layerL_local.set_r_to_constant(1, rows = row2reduce)
        #print(inputs_features)

        constrants_no_inputs = {}
        self.bnnenc.constraints_ordering = {}
        self.bnnenc.generate_last_linear_constraints_with_reduction(layerL_local, constrants_no_inputs, is_assum = True, row2reduce = row2reduce)        
        constraints_ordering = copy.deepcopy(self.bnnenc.constraints_ordering)
        #print_constraints(constrants_no_inputs)

        # assumption generator
        assum_mapping_global_asm_to_local = {}
        assum_var2cnf = {}
        for a_id in learnable_parameters:
            get_cnf_varid(assum_var2cnf, a_id)
            assum_mapping_global_asm_to_local[self.bnnenc.var2cnf[a_id]] = get_cnf_varid(assum_var2cnf, a_id)

        for r_id in learnable_reduction_parameters:
            get_cnf_varid(assum_var2cnf, r_id)
            assum_mapping_global_asm_to_local[self.bnnenc.var2cnf[r_id]] = get_cnf_varid(assum_var2cnf, r_id)

        #print(assum_mapping_global_asm_to_local, assum_var2cnf)
        # create as many solvers as features to speed up search
        solvers = {}
        feat_vec = 0
        all_inputs_matrix = []
        all_labels_matrix = []
        for key in inputs_features:                
            last_layer_input  = inputs_features[key][0]
            true_label = inputs_features[key][1]
            
            all_inputs_matrix.append(last_layer_input)
            all_labels_matrix.append(true_label)
            # we work with originally correctly classified image
            start = time.time()
            constraints = {}                
            constraints = copy.deepcopy(constrants_no_inputs)
            var2cnf = copy.deepcopy(self.bnnenc.var2cnf)
            global_counter  = -1                 
            nb_input = layerL_local.nb_cols            
            # reset assumptions
            for ra_id in assum_var2cnf:
                v = layerL_local.get_var_i_j_by_symbol(ra_id)  
                #print(a_id,v, form_assumption_constraint_name(a_id))
                #print(constraints[form_assumption_constraint_name(a_id)])
                constraints[form_assumption_constraint_name(ra_id)] = [ra_id,  1 if v >= 1 else 0]                
                #print(constraints[form_assumption_constraint_name(a_id)])
            
            #print_constraints(constraints)

            # set imputs
            for i in range(0, nb_input):
                y_id = create_indexed_variable_name(NEURON_VAR_ID, [layerL_local.id, i]) 
                get_cnf_varid(var2cnf, y_id)
                constraints[form_unary_constraint_name(y_id)] = [y_id, last_layer_input[y_id]] 
                constraints_ordering[global_counter] = form_unary_constraint_name(y_id)
                global_counter -= 1         
            # ensure the winner
            for j in range(0, self.bnnenc.layers[-1].nb_rows):        
                if (true_label == j):
                    continue;
                o_id = create_indexed_variable_name(ORDER_VAR_ID, [true_label, j])  
                constraints[form_unary_constraint_name(o_id)] = [o_id, 1]  
                constraints_ordering[global_counter] = form_unary_constraint_name(o_id)                    
                # require strict ordering

                o_id = create_indexed_variable_name(ORDER_VAR_ID, [j, true_label])  
                constraints[form_unary_constraint_name(o_id)] = [o_id, 0]  
                constraints_ordering[global_counter] = form_unary_constraint_name(o_id)
                global_counter -= 1          
            
            constraints_ordering = dict(sorted(constraints_ordering.items()))
            #print_constraints(constraints)
            solver = MinisatSolverExt(var2cnf = var2cnf, nb_sat_vars = len(var2cnf))
            if (debug):
                print("Create solver, # high-level constraints ({})".format(len(constraints)))      
            solver.populate_solver(copy.deepcopy(constraints))
            solvers[feat_vec] = solver
            feat_vec += 1

        
            #print(all_labels_matrix)
        # create assumption solver
        if (self.args.reduce):
            polarity = True
        else:
            polarity = None
        assumption_solver = MinisatSolverExt(var2cnf = assum_var2cnf,polarity = polarity, nb_sat_vars = len(assum_var2cnf))        
        nb_correct = 0
        no_tie_acc = 0
        #nb_target = len(inputs_features)*0.95
        no_tie_acc_target = no_tie_acc_orig - self.args.acc_drop#*(reduction_in_per[row]/(2*layerL_local.nb_rows))
        acc_target = acc_orig - self.args.acc_drop
        ok_correct = False
        randw = randomword(7)

        
        
        images = []
        labels = []
        for key in inputs_features:                
            input  = inputs_features[key][0].values()
            new_input = [1 if x==1 else -1 for x in input]
            true_label = inputs_features[key][1]
            images.append(new_input)
            labels.append(true_label)
        labels_clone = labels[:]
        images = torch.from_numpy(np.asarray(images)).float()
        labels = torch.from_numpy(np.asarray(labels))
        labels_clone = labels[:]


        labels = labels.type(torch.LongTensor)


        images, labels = images.cuda(), labels.cuda()   
        images = Variable(images)
        labels = Variable(labels)
        nbclasses = len(self.args.focuslabels_teacher)
        nbinputs = len(inputs_features[key][0])
        bnn_model =  BNNetLinear(nbclasses = nbclasses, nbinputs = nbinputs, mask = None)
        bnn_model =  bnn_model.cuda()

    

        while(not ok_correct):

            print("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< {0:d}, no_tie_acc={1:.2f}/{2:.2f}, blocks = {3:d},  {4:d}".format( nb_correct, no_tie_acc, no_tie_acc_target, len(blocking_clause), len(inputs_features)))
            nb_correct = 0
            nb_file = 0;
            #self.compute_test_accuracy()
            #print(solvers)
            new_assumptions = []
            for ra_id in assum_var2cnf:
                v = layerL_local.get_var_i_j_by_symbol(ra_id)  
                #print(ra_id,v, form_assumption_constraint_name(ra_id))
            #print(constraints[form_assumption_constraint_name(a_id)])
                cnf_id = var2cnf[ra_id]
                new_assumptions.append(cnf_id if v >= 1 else -cnf_id)

            for i, solver in solvers.items():                
                start = time.time()
                #print(solver)
                #print(solver.assumptions)
                solver.update_assumptions(assumptions = new_assumptions)
                #print(new_assumptions)                
                
                start = time.time()
                sat_result, model, purecore = solver.solve_limited()                    
                if (debug):
                    print("Solve time {}".format(time.time() - start))                
                if (sat_result == SOLVER_SAT_RESULT):         
                    #print("OK")    
                    nb_correct += 1  
                    if (debug): 
                        manual_check_last_lin_layer(last_layer_input)
                    continue;                      
                if (sat_result == SOLVER_UNSAT_RESULT):
                    #print("UNSAT")
                    ####################################
                    # convertion to CNF
                    ####################################
                    #print(sample_file)
                    start = time.time()
                    for r in range(30):
                        random.shuffle(new_assumptions)
                        solver.update_assumptions(assumptions = new_assumptions)
                        sat_result, model, purecore = solver.solve_limited()                    
                        clause = self.prepare_block_from_core(core = purecore, assum_mapping_global_asm_to_local = assum_mapping_global_asm_to_local) 
                        #print(clause)
                        #print("<<")
                        #print(clause, len(clause))
                        if (clause not in blocking_clause):
                            assumption_solver.s.add_clause(clause)
                            blocking_clause.append(clause[:])
                            #print(r, len(clause))
                    if (debug):                            
                        print("Gen cores {}".format(time.time() - start))
                    #exit()
                    
                    all_correct = False            
                    unsat_assignments = purecore
                    #print ("Core: ", purecore)
                    clause =  self.prepare_block_from_core(core = purecore, assum_mapping_global_asm_to_local = assum_mapping_global_asm_to_local) 
                    if (clause not in blocking_clause):
                        print(clause)
                        assumption_solver.s.add_clause(clause)
                        blocking_clause.append(clause[:])
                    

                    assumption_sat_result,  assumption_model,  assumption_purecore = assumption_solver.solve_limited()    
                    if (assumption_sat_result == SOLVER_UNSAT_RESULT):
                        print("Fail to find")
                        exit()
                    
                    # call assumption solver generator
                    #print('call assumption solver generator')
                    
                    #print(assumption_model)
                    total_runs +=1
                    if (assumption_sat_result == SOLVER_SAT_RESULT):
                        for assum_id in assum_var2cnf:
                            v = get_sat_value_by_id(assum_id, assum_var2cnf, assumption_model)
                            if (layerL_local.is_a_i_j_by_symbol(assum_id)):
                                layerL_local.set_a_i_j_by_symbol(assum_id, 1 if v > 0 else -1)  
                            if (layerL_local.is_r_i_j_by_symbol(assum_id)):
                                layerL_local.set_r_i_j_by_symbol(assum_id, 1 if v > 0 else 0)  
                            #print(assum_id, v,  end='  ')
                            #print(v,  end=' ')
                        #print(no_tie_acc)
                        
                        self.bnnenc.layers[-1] =layerL_local 
                        train_loss, layerL_local = self.train_network_layer(model = bnn_model, nbclasses = nbclasses, nbinputs = nbinputs,  layerL_local = layerL_local, images = images, labels = labels, labels_clone = labels_clone)
                        # block assignmnet of zeros
                        
                    
                        clause = []
                        for i in range(0, layerL_local.nb_rows):
                            for j in range(0, layerL_local.nb_cols):
                                cnf_id = assum_var2cnf[layerL_local.sym_r[i][j]]
                                clause.append(-cnf_id if layerL_local.r[i][j] >= 1 else cnf_id)                           
                                #cnf_id = assum_var2cnf[layerL_local.sym_a[i][j]]
                                #clause.append(-cnf_id if layerL_local.a[i][j] >= 1 else cnf_id)                           
            
                        clause.sort()
                        #print(clause)
                        assumption_solver.s.add_clause(clause)
                        blocking_clause.append(clause[:])
                        print(layerL_local)
            
                        #exit()
                        #print( self.bnnenc.layers[-1])
                        start = time.time()            
                        #acc, no_tie_acc = self.compute_train_accuracy()
                        #if (debug or True):
                        #    print("Compute accuracy {}".format(time.time() - start))                
                                
                        if (train_loss > acc_target):
                            ok_correct = True
                            break
                        else:
                            break
                                # we block assignment of r_ij
            
                                    #print("<<")
                                    #print(layerL_local)
                                #if (total_runs > 1):
                                #    exit()
                                #print(layerL_local)
                    

                
                
                    #exit()

                    #exit()
                    #break
                    #if (winner == true_label):
                    #    print("Error: UNSAT execution has a bug")
                    #    exit()
            
        print(layerL)    
        print(layerL_local)    
        self.bnnenc.layers[-1] =copy.deepcopy(layerL_local)
        print("Total time ", time.time() - init_start_time) 
        self.compute_train_accuracy()
        self.compute_test_accuracy()
                
    def run_learn_last_layer(self):
        self.compute_train_accuracy()
        self.compute_test_accuracy()
        #exit()
        debug = False
        blocking_clause = []
        all_correct = False
        total_runs = 0
        
        layerL = self.bnnenc.layers[-1]
        layerL_local = copy.deepcopy(self.bnnenc.layers[-1])

        print(layerL_local)                    
        cnt = 0
        thresh_reasonable_occ = len(self.sample_files)*0.01
        inputs_features =  self.generate_input_features(layerL_local, thresh_reasonable_occ) 
        
        # set assumption variables
        learnable_parameters = layerL_local.get_all_symbols()        
        # we randomly reassign layer
        for a_id in learnable_parameters:
            layerL_local.set_a_i_j_by_symbol(a_id, -1)        
        #print(learnable_parameters)
    
        #print(inputs_features)
        constrants_no_inputs = {}
        self.bnnenc.generate_last_linear_constraints(layerL_local, constrants_no_inputs, is_assum = True)        
        constraints_ordering = copy.deepcopy(self.bnnenc.constraints_ordering)
        
        # assumption generator
        assum_mapping_global_asm_to_local = {}
        assum_var2cnf = {}
        for a_id in learnable_parameters:
            get_cnf_varid(assum_var2cnf, a_id)
            assum_mapping_global_asm_to_local[self.bnnenc.var2cnf[a_id]] = get_cnf_varid(assum_var2cnf, a_id)


        assumption_solver = MinisatSolverExt(var2cnf = assum_var2cnf, nb_sat_vars = len(assum_var2cnf))        
        nb_correct = 0
        nb_target = len(inputs_features)*0.95
        while(nb_correct < nb_target):
            print("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< {}/{}, blocks = {},  {}".format( nb_correct, nb_target, len(blocking_clause), len(inputs_features)))
            all_correct = True
            nb_correct = 0
            nb_file = 0;
            
            for key in inputs_features:                
                last_layer_input  = inputs_features[key][0]
                true_label = inputs_features[key][1]
                nb_file +=1
                # we work with originally correctly classified image
                start = time.time()
                constraints = {}                
                constraints = copy.deepcopy(constrants_no_inputs)
                var2cnf = copy.deepcopy(self.bnnenc.var2cnf)
                global_counter  = -1                 
                nb_input = layerL_local.nb_cols
                
                # reset assumptions
                for a_id in assum_var2cnf:
                    v = layerL_local.get_a_i_j_by_symbol(a_id)  
                    #print(a_id,v, form_assumption_constraint_name(a_id))
                    #print(constraints[form_assumption_constraint_name(a_id)])
                    constraints[form_assumption_constraint_name(a_id)] = [a_id,  1 if v >= 0 else 0]                
                    #print(constraints[form_assumption_constraint_name(a_id)])

                #print_constraints(constraints)
                # set imputs
                for i in range(0, nb_input):
                    y_id = create_indexed_variable_name(NEURON_VAR_ID, [layerL_local.id, i]) 
                    get_cnf_varid(var2cnf, y_id)
                    constraints[form_unary_constraint_name(y_id)] = [y_id, last_layer_input[y_id]] 
                    constraints_ordering[global_counter] = form_unary_constraint_name(y_id)
                    global_counter -= 1         
                # ensure the winner
                for j in range(0, self.bnnenc.layers[-1].nb_rows):        
                    if (true_label == j):
                        continue;
                    o_id = create_indexed_variable_name(ORDER_VAR_ID, [true_label, j])  
                    constraints[form_unary_constraint_name(o_id)] = [o_id, 1]  
                    constraints_ordering[global_counter] = form_unary_constraint_name(o_id)                    
    #                 # require strict ordering

                    o_id = create_indexed_variable_name(ORDER_VAR_ID, [j, true_label])  
                    constraints[form_unary_constraint_name(o_id)] = [o_id, 0]  
                    constraints_ordering[global_counter] = form_unary_constraint_name(o_id)
                    global_counter -= 1          
                                                 

                if (debug):
                    print("Encoding total {}".format(time.time() -  start))
                #constraints_ordering = dict(sorted(constraints_ordering.items()))
                #print_constraints(constraints)
                if (debug):
                    manual_check_last_lin_layer()
                            #print(s)
                 
                if (debug):
                    print(o_dummy)
                    print("Network winner {}  vs  True winner {}".format(0 if o_dummy[0] > o_dummy[1] else 1, true_label))
                start = time.time()
                
                #print_constraints(constraints)
                solver = MinisatSolverExt(var2cnf = var2cnf, nb_sat_vars = len(var2cnf))
                if (debug):
                    print("Create solver, # high-level constraints ({})".format(len(constraints)))      
                solver.populate_solver(copy.deepcopy(constraints))
                if (debug):   
                    print("Prepare solver {}".format(time.time() - start))
                    print("Run solver")            
                start = time.time()
                sat_result, model, purecore = solver.solve_limited()                    
                if (debug):
                    print("Solve time {}".format(time.time() - start))

                if (sat_result == SOLVER_SAT_RESULT):         
                    #print("OK")    
                    nb_correct += 1  
                    continue;                      
                if (sat_result == SOLVER_UNSAT_RESULT):
                    ####################################
                    # convertion to CNF
                    ####################################
                    #print(sample_file)
                    start = time.time()
                    reuse_cnf =  False
                    for r in range(10):
                        muser_core = self.run_muser_gcnf(constraints =  copy.deepcopy(constraints), 
                                                         constraints_ordering =  copy.deepcopy(constraints_ordering),  
                                                         gcnf_file_name = SAT_GEN_FILES_DIR + ntpath.basename("muser"), 
                                                         var2cnf = var2cnf,
                                                         is_suffle_asm = True,
                                                         reuse_cnf_file_name = reuse_cnf)
                        reuse_cnf = True
                        muser_core.sort()
                        #print(muser_core)
                        clause = []
                        for a in muser_core:
                            #print(a)
                            clause.append(assum_mapping_global_asm_to_local[abs(a)] if a < 0 else -assum_mapping_global_asm_to_local[abs(a)])
                            #print(clause)
                        clause.sort()
                        if (clause not in blocking_clause):
                            blocking_clause.append(clause[:])
                    if (debug):                            
                        print("Gen cores {}".format(time.time() - start))
                    #exit()
                    
                    all_correct = False            
                    unsat_assignments = purecore
                    purecore.sort()
                    #print ("Core: ", purecore)
                    clause = []
                    #print(assum_mapping_global_asm_to_local)
                    for a in purecore:
                        clause.append(assum_mapping_global_asm_to_local[abs(a)] if a < 0 else -assum_mapping_global_asm_to_local[abs(a)])
                    #print(clause)
                    if (clause not in blocking_clause):
                        blocking_clause.append(clause[:])
                    
                    # create assumption solver
                    assumption_solver = MinisatSolverExt(var2cnf = assum_var2cnf, nb_sat_vars = len(assum_var2cnf))        
                    for clause in blocking_clause:
                        assumption_solver.s.add_clause(clause)
                        #print(clause)
    
                        
                    # call assumption solver generator
                    #print('call assumption solver generator')
                    assumption_sat_result,  assumption_model,  assumption_purecore = assumption_solver.solve_limited()
                    #print(assumption_model)
                    total_runs +=1
                    if (assumption_sat_result == SOLVER_SAT_RESULT):
                        for assum_id in assum_var2cnf:
                            v = get_sat_value_by_id(assum_id, assum_var2cnf, assumption_model)
                            layerL_local.set_a_i_j_by_symbol(assum_id, 1 if v > 0 else -1)  
                            #print(assum_id, v,  end='  ')
                        #print("<<")
                        #print(layerL_local)
                    #if (total_runs > 1):
                    #    exit()
                    if (assumption_sat_result == SOLVER_UNSAT_RESULT):
                        print("Fail to find")
                        exit()
                    #exit()
                    #break
                    #if (winner == true_label):
                    #    print("Error: UNSAT execution has a bug")
                    #    exit()
            
        print(layerL)    
        print(layerL_local)    
        self.bnnenc.layers[-1] =copy.deepcopy(layerL_local) 
        self.compute_train_accuracy()
        self.compute_test_accuracy()
            
            

            
    def run(self):
        # create input variables                
        learner_res = LEARNER_POS_RESULT
        #print(learnable_parameters)
        # encode network
        self.bnn_constraints, self.bnn_constraints_ordering = self.bnnenc.generate_network_constraints()

        
        for sample_file in self.sample_files:
            constraints = copy.deepcopy(self.bnn_constraints)
            constraints_ordering = copy.deepcopy(self.bnn_constraints_ordering)
            var2cnf = copy.deepcopy(self.var2cnf)
            
            #########################
            # Read input file
            # We assume that all inputs/matrices are 1/-1
            #########################
            print("Reading input: {}".format(self.args.data + sample_file))            
            input, true_label = parse_input(self.args.data + sample_file)
            #print_vec_as_textimage(input[:], self.bnnenc.side)       
            forward_assignments, winner = self.bnnenc.forward(input[:])
            print("winner {}".format(winner))
            #print("model outputs", forward_assignments, winner)
            #exit()

           #python test_flow.py -a BNNetLinear --lr 0.001 --load ./plots/MNIST_bin_0_05_s_0_focuslabels__0__1_/BNNetLinear/checkpoint_100.pth -s 0  --savemodeltxt True --dataset MNIST --bnnlinearbias False --focuslabels 0 1
            ############################
            # encode input, label
            ###########################
            
            global_counter  = -1                 
            # fix input
            for i in range(0, len(input)):
                x_id = create_indexed_variable_name(NEURON_VAR_ID, [self.bnnenc.layers[0].id, i]) 
                get_cnf_varid(var2cnf, x_id)
                constraints[form_unary_constraint_name(x_id)] = [x_id, 1  if input[i] >= 0 else 0] 
                constraints_ordering[global_counter] = form_unary_constraint_name(x_id)
                global_counter -= 1                 
            # ensure the winner
            for j in range(0, self.bnnenc.layers[-1].nb_rows):        
                if (true_label == j):
                    continue;
                o_id = create_indexed_variable_name(ORDER_VAR_ID, [true_label, j])  
                constraints[form_unary_constraint_name(o_id)] = [o_id, 1]  
                constraints_ordering[global_counter] = form_unary_constraint_name(o_id)
                global_counter -= 1                                       
            
            constraints_ordering = dict(sorted(constraints_ordering.items()))
            
            ######################################
            # Print all constraints (hight level)
            ######################################    
            #print_constraints(constraints)
            #forward_assignments, winner = self.bnnenc.forward(input)
            if (not self.args.gencnfs): 
                print("Network winner {}  vs  True winner {}".format(winner, true_label))
                solver = MinisatSolverExt( var2cnf = var2cnf, nb_sat_vars = len(var2cnf))
                print("Create solver, # high-level constraints ({})".format(len(constraints)))            
                solver.populate_solver(constraints)   
                print("Run solver")            
                sat_result, model, purecore = solver.solve_limited()        
            else:      
                start = time.time()                        
                ####################################
                # convertion to CNF
                ####################################
                #print(sample_file)
                cnf_file_name, assumption_file_name = self.save_cnf(constraints = constraints, constraints_ordering = constraints_ordering,  cnf_file_name = "./sat_outputs/" + sample_file, var2cnf = var2cnf) 
                ###################################
                # Reading CNF and assumptions
                ###################################
                print ("Reading CNF/assumptions  file ", cnf_file_name, assumption_file_name)
                satsolver_infile = open(cnf_file_name, 'r')
                satsolver_assump_infile = open(assumption_file_name, 'r')    
                print(len(var2cnf))
                solver = MinisatSolverExt(cnf_infile = satsolver_infile,  assump_infile = satsolver_assump_infile, nb_sat_vars = len(var2cnf))
                satsolver_infile.close()
                satsolver_assump_infile.close()
              
                print("Start solving")
                sat_result, model, purecore = solver.solve_limited()
#                 
#                 end = time.time()
#                 print(end - start)
# 
            print(sat_result)
            #######################
            # Process results
            #######################
            if (sat_result == SOLVER_SAT_RESULT):

                sat_assignments = {}
                print(1)
                for var_id in forward_assignments:
                    sat_assignments[var_id] = get_sat_value_by_id(var_id, var2cnf, model)
                if (self.args.small_test):
                    print("correct execution", forward_assignments)
                    print("sat     execution", sat_assignments)
                if (forward_assignments != sat_assignments):
                    print("Error: SAT execution has a bug")
                    for var_id in forward_assignments:
                        if(sat_assignments[var_id] != forward_assignments[var_id]):
                            print("Wrong: ",var_id, sat_assignments[var_id], forward_assignments[var_id])
 
 
                    print("Start extra checks...")
                     
                    print("Checking inputs")
                    set_vars = {}
                    for i in range(0, len(input)):
                        x_id = create_indexed_variable_name(NEURON_VAR_ID, [self.bnnenc.layers[0].id, i]) 
                        x_id_val = 1  if input[i] >= 0 else 0
 
                        set_vars[x_id] = x_id_val
 
                        sat_assignments = get_sat_value_by_id(x_id, var2cnf, model)
                        if (sat_assignments != x_id_val):
                            print("Input problem: ", x_id, "True ", x_id_val, "Comp", sat_assignments)
                            exit()
                    print("Inputs are ok")        
                     
                    print("Checking coeffs")
                    for k in range(0, self.bnnenc.nb_layers,2):
                        layerL = self.bnnenc.layers[k]                        
                        for i in range(0, layerL.nb_rows):
                            for j in range(0, layerL.nb_cols):
                                a_id = layerL.sym_a[i][j]
                                a_id_val =  1  if layerL.a[i][j] >= 0 else 0 
                                sat_assignments = get_sat_value_by_id(a_id, var2cnf, model)
                                 
                                set_vars[a_id] = a_id_val
                                  
                                if (sat_assignments != a_id_val):
                                    print("Coef problem: ", a_id, "True ", a_id_val, "Comp", sat_assignments)
                                   # exit()
                        print("Coeff are ok, layer", k)   
                     
                     
                    print("Checking the rest")
                    for i in  self.bnnenc.constraints_ordering:                        
                        con_name = self.bnnenc.constraints_ordering[i]
                        constraint = constraints[con_name]
                        print_constraint(con_name, constraint)                                   
                        if (UNARY_CON_ID in con_name): 
                            [var_id, var_val] = constraint
                            set_vars[var_id] = var_val
                        if (ASSUMPTION_CON_ID in con_name): 
                            [var_id, var_val] = constraint
                            if (var_id in set_vars):
                                assert(var_val == var_val)
                            else:    
                                set_vars[var_id] = var_val
                        if (NXOR_CON_ID  in con_name):
                            variables = constraint
                            print(variables)
                            a  = set_vars[variables[0]]
                            y  = set_vars[variables[1]]
                            q_sat_assignments = get_sat_value_by_id(variables[2], var2cnf, model)
                            print("Consider a({}) = {}, y({}) = {} sat({},{}) = {}".format(var2cnf[variables[0]], a, var2cnf[variables[1]], y,variables[2], var2cnf[variables[2]],q_sat_assignments))
                            if (a*y == 1 and q_sat_assignments == 0) or (a*y == -1 and q_sat_assignments == 1):
                                print("NXOR problem: a=", variables[0], " y=", variables[1], "True=", a*y, "Comp", q_sat_assignments)
                                exit()
                            else:
                                set_vars[variables[2]] = q_sat_assignments
                                print("OK")
                        if (XOR_CON_ID  in con_name): 
                            variables = constraint
                            print(variables)
                            a  = set_vars[variables[0]]
                            y  = set_vars[variables[1]]
                            q_sat_assignments = get_sat_value_by_id(variables[2], var2cnf, model)
                            print("Consider a={}, y={} sat ={}".format(a,y,q_sat_assignments))
                            if (a*y == 1 and q_sat_assignments == 1) or (a*y == -1 and q_sat_assignments == 0):
                                print("XOR problem: a=", variables[0], " y=", variables[1], "True=", a*y, "Comp", q_sat_assignments)
                                exit()
                            else:
                                set_vars[variables[2]] = q_sat_assignments
                                print("OK")
                            exit()            
                        if (LIN_REIFIED_CON_ID  in con_name):
                            [coeffs, vars_ids,  z_id, constterm] = constraint
                            s = 0
                            for i in range(len(vars_ids)):
                                a  = coeffs[i]
                                q  = set_vars[vars_ids[i]]
                                s = s + a*q
                             
                            s = s + constterm
                             
                            comp_y = 1 if s >= 0 else 0
                            y_next_sat_assignments = get_sat_value_by_id(z_id, var2cnf, model)
                            if (comp_y != y_next_sat_assignments):
                                print("LIN reified problem: sum a_x_i + cont > 0 ", comp_y, "Comp", y_sat_assignments)
                                exit()
                            else:
                                set_vars[z_id] = y_next_sat_assignments
                                print("OK") 
 
                else:
                     print("OK for this image")
            if (sat_result == SOLVER_UNSAT_RESULT):            
                unsat_assignments = purecore
                if (self.args.small_test):
                    print ("Core: ", purecore)
                if (winner == true_label):
                    print("Error: UNSAT execution has a bug")
                    #exit()
                if (not self.args.small_test):
                    learner_res = LEARNER_NEG_RESULT
                    #return learner_res, purecore    
        return learner_res, {}                
            
            #     for i in range(1, len(model)):
            #         var_with_pol = model[i]
            #         var_cnf_id = abs(var_with_pol)
            #         var_id = getkey_by_value(var2cnf, var_cnf_id)
            #         if (var_id in forward_assignments):
            #             print("getting [{}]  {} ".format(var_cnf_id, var_id))
            #             if (var_with_pol < 0):
            #                 sat_assignments[var_id] =0
            #             else:
            #                 sat_assignments[var_id] =1
            #         else:
            #             print("scip [{}]  {} ".format(var_cnf_id, var_id))
        
        # ################################
        # # Evaluate outputs
        # ################################
        # z = input
        # for layer in layers[:-1]:
        #     z = layer.dot(z)
        #     # print("output {}".format(z))
        #     z = np.sign(z)
        #     z[z == 0] = 1
        #     # print("bin output {}".format(z))
        # # laste layer -- no sign
        # z = layers[-1].dot(z)
        # print("Computed forward path --  output {}".format(z))
        # 
        # #########################
        # # Assume that teh following relattion between Booelan variables and -1/1 variables
        # # TODO explain this  
        # # b_i = 1  iff z_i =1  
        # # b_i = 0  iff z_i =-1  
        # #########################
        # 
        # temp_file = args.cnfdest + FILE_TEMP_EXTENTION;
        # cnf_file = open(temp_file, 'w')
        # 
        # x = input    
        # ls = len(layers)
        # varids2values = {}
        # varids2cnf_varids = {}
        # 
        # nb_constraints = 0;
        # 
        # constraints = {} 
        # o = []
        # for k in range(0, ls):
        #     layer = layers[k]
        #     rows = layer.shape[0]
        #     cols = layer.shape[1]
        #     
        #     
        #     y = layer.dot(x)
        #     z = np.sign(y)
        #     z[z == 0] = 1
        # 
        #     
        #     local_y = np.empty((0), int)
        #     local_z = np.empty((0), int)
        #     for i in range(0, rows):
        #         full_ineq = ''
        #         simplified_ineq = ''
        #         
        #         full_sum = 0
        #         simplified_sum = 0
        #         
        #         coeffs = []
        #         vars_ids = []
        #         constterm = 0
        #         
        #         for j in range(0, cols):
        #             # a[k,i,j] = 1 NXOR y[k,j] = 1 <=>  b[k,i,j] =1
        # 
        #             ############ form xnor constraint #################             
        #             # form coeff id
        #             a_id = ("{}_{}{}{}".format(LAYER_VAR_ID, k, i, j))
        #             get_cnf_varid(varids2cnf_varids, a_id)
        # 
        #             # form neuron id
        #             x_id = ("{}_{}{}".format(NEURON_VAR_ID, k, j))
        #             get_cnf_varid(varids2cnf_varids, x_id)
        # 
        #             # form output neuron id
        #             z_id = ("{}_{}{}".format(NEURON_VAR_ID, k + 1, i))
        #             get_cnf_varid(varids2cnf_varids, z_id)
        # 
        #             # form mult extar var id
        #             b_id = ("{}_{}{}{}".format(MULT_VAR_ID, k, i, j))
        #             get_cnf_varid(varids2cnf_varids, b_id)
        #             
        #             # store unary constraints for coeff
        #             constraints[form_unary_constraint_name(a_id)] = [a_id, 1  if layer[i][j] >= 0 else 0]     
        #             if (k == 0):
        #                 if form_unary_constraint_name(x_id) not in constraints.keys():
        #                     # store unary constraints for inputs    
        #                     constraints[form_unary_constraint_name(x_id)] = [x_id, 1  if input[j] >= 0 else 0] 
        #                    
        #             # store NXOR constraint 
        #             constraints[form_nxor_constraint_name(k, i, j)] = [a_id, x_id, b_id]
        #             
        #             
        #             # [4DEBUG] evalutae nxor 
        #             varids2values[a_id] = 1  if layer[i][j] >= 0 else 0
        #             varids2values[x_id] = 1  if x[j] >= 0 else 0       
        #             varids2values[b_id] = bool(varids2values[a_id]) == bool(varids2values[x_id])                       
        # 
        # 
        #             ############### form linear constraint ################
        #             coeffs = np.append(coeffs, 2)
        #             vars_ids = np.append(vars_ids, b_id)
        #             constterm = constterm - 1      
        #             
        #             # [4DEBUG] computing linear constraint .... 
        #             full_sum = full_sum + 2 * varids2values[b_id] - 1
        #             
        #         if (bool(full_sum >= 0) != bool(z[i] == 1)):
        #             print(" The following constraint is incorrect " + full_ineq)
        #             exit()
        #             
        #         # [4DEBUG] check sums    
        #         local_y = np.append(local_y, full_sum)      
        #         
        #         
        #         if (k < ls - 1):            
        #             # add reified constraint
        #             constraints[form_linear_reified_constraint_name(k, i)] = [coeffs, vars_ids, z_id, constterm]
        #             if (bool(simplified_sum + constterm >= 0) != bool(z[i] == 1)):
        #                 print(" The following constraint is incorrect ")
        #                 print_linear_reified_constraint(constraints[form_linear_reified_constraint_name(k, i)])
        #                 exit()
        #             temp = 1 if full_sum >= 0  else -1    
        #             local_z = np.append(local_z, temp)      
        #         else:    
        #             # collect linear constraint to build partial ordering of outputs
        #             constraints[form_linear_constraint_name(k, i)] = [coeffs, vars_ids, constterm]
        # 
        #     if (np.array_equal(local_y, y) != True):
        #         print("invalid forward simulation ", local_y, y)
        #         exit()   
        #     if (k < ls - 1):
        #         if (np.array_equal(local_z, z) != True):
        #             print("invalid forward simulation ", local_z, z)
        #             exit()
        #     else:
        #         # introduce order variables
        #         # o[i] == 1 iff y[label] >= y[i]
        #         # o[i] == 1 iff y[label] - y[i] >=0               
        #         for i in range(0, rows):
        #             if(i == true_label):
        #                 continue            
        #             coeff_new = constraints[form_linear_constraint_name(k, true_label)][0]
        #             vars_ids_new = constraints[form_linear_constraint_name(k, true_label)][1]
        #             constterm_new = constraints[form_linear_constraint_name(k, true_label)][2]
        # 
        #             coeff_other = -1 * constraints[form_linear_constraint_name(k, i)][0]
        #             vars_ids_other = constraints[form_linear_constraint_name(k, i)][1]
        #             constterm_other = -1 * constraints[form_linear_constraint_name(k, i)][2]            
        #     
        #             coeff_new = np.append(coeff_new, coeff_other)  
        #             vars_ids_new = np.append(vars_ids_new, vars_ids_other)
        #             constterm_new = constterm_new + constterm_other
        #             
        #             
        #             o_id = ("{}_{}".format(ORDER_VAR_ID, i))
        #             o = np.append(o, o_id)
        #             get_cnf_varid(varids2cnf_varids, o_id)            
        #             constraints[form_linear_reified_constraint_name(k, i)] = [coeff_new, vars_ids_new, o_id, constterm_new]
        # #             
        #             varids2values[o_id] = 1  if local_y[true_label] >= local_y[i] else 0
        #         
        #     x = z;
        #     
        # print("\n\nModel:")
        # for keys, values in sorted(constraints.items()):
        #     if (keys[:4] == UNARY_CON_ID): 
        #         unary_constraint4bool_var(cnf_file, varids2cnf_varids, values)            
        #         print_unary_constraint(values)
        #     if (keys[:4] == NXOR_CON_ID): 
        #         nxor_input_reified(cnf_file, varids2cnf_varids, values)            
        #         print_nxor_constraint(values)
        #     if (keys[:4] == LIN_REIFIED_CON_ID):
        #         # we divide all coffs and the rhs by 2   as we know that all coeef are equal to 2     
        #         values[0] = [x / 2 for x in values[0]]  
        #         values[3] = math.floor(values[3] / 2)      
        #         # print_linear_reified_constraint(values)
        #         # we transform constraint 
        #         seqcounters4unary_coeff_linear_reified(cnf_file, varids2cnf_varids, coeffs=values[0], vars_ids=values[1], output_var_id=values[2], constterm=values[3])
        #     # if (keys[:4] == LIN_CON_ID):
        #     #    print_linear_constraint_name(values)        
        # 
        # # ensure that the winner belongs to the true class
        # for o_id in o:
        #     add_clause(cnf_file, varids2cnf_varids, [o_id])
        #         
        # cnf_file.close()
        # 
        # add_first_line2cnf(temp_file, args.cnfdest, len(varids2cnf_varids))
        # 
        # 
        # exit()

             
        #build neurons map
  
      #                 print("We consider this file as it is classified correctly")
    #                 print("inputs to the layer ", y_input)
    #                 # assumption generator
    #                 assum_mapping_global_asm_to_local = {}
    #                 assum_var2cnf = {}
    #                 for a_id in self.bnnenc.learnable_parameters:
    #                     get_cnf_varid(assum_var2cnf, a_id)
    #                     assum_mapping_global_asm_to_local[var2cnf[a_id]] = get_cnf_varid(assum_var2cnf, a_id)
    #                 # start with a random assignmnet of a
    #                 assump = {}
    #                 counter = 0
    #                 for a_id in self.bnnenc.learnable_parameters:
    #                     if (counter < 11):
    #                         assump[a_id] = 0 #np.random.choice(a=[0, 1], size=(1))[0]
    #                     else:
    #                         assump[a_id] = 1 #np.random.choice(a=[0, 1], size=(1))[0]
    #                     counter +=1 
    #                 #print(a)
    #                 blocking_clause = []
    #                 while(True):
    #                     #reset assumptions
    #                     solver.assumptions = []                
    #                     o_dummy = []
    #                     #print("assumptions", assump)
    #                     #reset constraint
    #                     for keys, values in sorted(constraints.items()):               
    #                         if (ASSUMPTION_CON_ID in keys): 
    #                             a_id = values[0]
    #                             #print(keys, values, a_id)                            
    #                             #print(constraints[keys])
    #                             constraints[keys] = [a_id,  assump[a_id]]
    #                             #solver.assumptions.append(var2cnf[a_id] if assump[a_id] > 0 else -var2cnf[a_id])
    #                             #print(constraints[keys])            
    #  
    #                         if (LIN_REIFIED_CON_ID  in keys):
    #                             #print_constraint(keys, values)
    #                             [coeffs, vars_ids,  z_id, constterm] = constraints[keys]
    #                             s = 0
    #                             for i in range(len(vars_ids)):
    #                                 coef  = coeffs[i]
    #                                  
    #                                 id = vars_ids[i].replace('[','_').replace(']','_')
    #                                 id  = id.split('_')
    #                                 k1 = id[2]
    #                                 i1 = id[4]
    #                                 j1 = id[6]
    #                                 t_y_id = create_indexed_variable_name(NEURON_VAR_ID, [k1, j1])
    #                                 t_a_id = create_indexed_variable_name(LAYER_VAR_ID, [k1, i1, j1])
    #                                                                  
    #                                 #print(t_a_id, assump[t_a_id])
    #                                 #print(t_y_id, forward_assignments[t_y_id]) 
    #                                 q  = (2*assump[t_a_id]-1)*(2*forward_assignments[t_y_id]-1)
    #                                 s = s + coef*q
    #                                 #print(s, coef, q)
    #                             s = s + constterm
    #                             o_dummy.append(s)
    #  
    #                     print('o_dummy', o_dummy)
    #                     #print(var2cnf)
    #                     #print(solver.assumptions)
    #                      
    #                      
    #                     #print("Network winner {}  vs  True winner {}".format(int(o_dummy[0] > o_dummy[1]), true_label))
    #                     solver = MinisatSolverExt(var2cnf = var2cnf, nb_sat_vars = len(var2cnf))
    #                     #print("Create solver, # high-level constraints ({})".format(len(constraints)))      
    #                     solver.populate_solver(copy.deepcopy(constraints))   
    #                     #print("Run solver")            
    #                     sat_result, model, purecore = solver.solve_limited()        
    #                     #print_constraints(constraints)
    #                     #sat_result, model, purecore = solver.solve_limited()        
    #                     if (sat_result == SOLVER_SAT_RESULT):
    #                         print("SAT")
    #                         if (true_label == 0):
    #                             assert(o_dummy[0] > o_dummy[1])
    #                         if (true_label == 1):
    #                             assert(o_dummy[1] > o_dummy[0])
    #                             
    #                         break
    #                          
    #                     if (sat_result == SOLVER_UNSAT_RESULT):
    #                         print('wrong guess')
    #                         #form blcokign clause
    #                         clause = []
    #                         #print("purecore", purecore)
    #                         for a in purecore:
    #                             clause.append(assum_mapping_global_asm_to_local[abs(a)] if a < 0 else -assum_mapping_global_asm_to_local[abs(a)])
    #                         #print(clause)
    #                         blocking_clause.append(clause)
    #  
    #  
    #                         # create assumption solver
    #                         assumption_solver = MinisatSolverExt(var2cnf = assum_var2cnf, nb_sat_vars = len(assum_var2cnf))
    #                         for clause in blocking_clause:
    #                             assumption_solver.s.add_clause(clause)
    #                             print(clause)
    #  
    #                          
    #                         # call assumption solver generator
    #                         print('call assumption solver generator')
    #                         assumption_sat_result,  assumption_model,  assumption_purecore = assumption_solver.solve_limited()
    #                         for assum_id in assum_var2cnf:
    #                             assump[assum_id] = get_sat_value_by_id(assum_id, assum_var2cnf, assumption_model)  
    #                             print(assum_id, assump[assum_id],  end='  ')
    #                         print("<<")
    #                         print(assumption_model)
    #  
    #                         #exit()
    #                                 
    #                     
                   