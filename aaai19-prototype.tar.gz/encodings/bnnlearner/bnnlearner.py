from __future__ import print_function, division
import numpy as np
import json
import math 
import string
from parser import *
from con2cnf import *
from utils import *
from bnnencoder import *
from bnnlearner import *
from satsolver import *
from pyminisolvers import minisolvers
import copy

class BNNLearner(object):
    """A encoding of BNN to CNFs:
    
    Attributes:
        config file: network structure
    """

    def __init__(self, args, network_definition):
        self.args  = args
        self.sample_files = [name for name in os.listdir(args.data) if os.path.isfile(os.path.join(args.data, name))]
        self.nb_images = len([name for name in os.listdir(args.data) if os.path.isfile(os.path.join(args.data, name))])
        
        # init network
        self.var2cnf = {}
        #print("reading network {}".format(args.definenetwork))
        self.bnnenc = BNNEncoder4Learner(network_definition, self.var2cnf) 
            
        # get parameters
        self.learnable_parameters = self.bnnenc.get_learnable_vars_symbol_as_dict()
        #print(learnable_parameters)
    def get_learnable_parameters(self):
        return self.learnable_parameters   
    
    def save_cnf(self, constraints, cnf_file_name, var2cnf):     
        cnf_file_name = cnf_file_name + CNF_FILE_TEMP_EXTENTION 
        assumption_file_name = cnf_file_name + ASSUMPTIONS_FILE_TEMP_EXTENTION
        temp_file = cnf_file_name + FILE_TEMP_EXTENTION;
        cnf_file = open(temp_file, 'w')
        assump_cnf_file = open(assumption_file_name, 'w')
        l = len(constraints)
        printProgressBar(0, l, prefix = 'Progress:', suffix = 'Complete', length = 50 ) 
        cnt_prefix = 0
        for keys, values in sorted(constraints.items()):    
            con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + str(cnt_prefix) + "_"
            if (UNARY_CON_ID in keys): 
                unary_constraint4bool_var([CNF_DESTINATION, cnf_file],var2cnf, x=values[0], value=values[1])            
            if (ASSUMPTION_CON_ID in keys): 
                assumption_constraint4bool_var([CNF_DESTINATION, assump_cnf_file], var2cnf, x=values[0], value=values[1])            
            if (NXOR_CON_ID  in keys): 
                nxor_input_reified([CNF_DESTINATION, cnf_file], var2cnf, x=values[0], y=values[1], z=values[2], constraint_prefix=con_prefix)            
            if (LIN_REIFIED_CON_ID  in keys):
                seqcounters4unary_coeff_linear_reified([CNF_DESTINATION, cnf_file], var2cnf, coeffs=values[0], vars_ids=values[1], output_var_id=values[2], constterm=values[3], constraint_prefix=con_prefix)
            printProgressBar(cnt_prefix, l, prefix = 'Progress:', suffix = 'Complete', length = 50)
            cnt_prefix += 1     
         
             
        cnf_file.close()
        assump_cnf_file.close()
        add_first_line2cnf(temp_file, cnf_file_name, len(var2cnf))    
        return cnf_file_name, assumption_file_name  
            
    def run(self, matrix_a):

        learner_res = LEARNER_POS_RESULT
        #print(learnable_parameters)
        # set values of learnable
        self.bnnenc.set_learnable_vars_asignment_from_dict(matrix_a)
        
        # encode network
        self.bnn_constraints = self.bnnenc.generate_network_constraints()

        for sample_file in self.sample_files:
            constraints = copy.deepcopy(self.bnn_constraints)
            var2cnf = copy.deepcopy(self.var2cnf)
        
            #########################
            # Read input file
            # We assume that all inputs/matrices are 1/-1
            #########################
            print("Reading input: {}".format(self.args.data + sample_file))            
            input, true_label = parse_input(self.args.data + sample_file)
            #print(input)
            
        
            
            ############################
            # encode input, label
            ###########################
            
            # fix input
            for i in range(0, len(input)):
                x_id = create_indexed_variable_name(NEURON_VAR_ID, [self.bnnenc.layers[0].id, i]) 
                get_cnf_varid(var2cnf, x_id)
                constraints[form_unary_constraint_name(x_id)] = [x_id, 1  if input[i] >= 0 else 0] 
            
            # ensure the winner
            for j in range(0, self.bnnenc.layers[-1].nb_rows):        
                if (true_label == j):
                    continue;
                o_id = create_indexed_variable_name(ORDER_VAR_ID, [true_label, j])  
                constraints[form_unary_constraint_name(o_id)] = [o_id, 1]  
                                    
            ######################################
            # Print all constraints (hight level)
            ######################################    
            #print_constraints(constraints)
            forward_assignments, winner = self.bnnenc.forward(input)
            if (not self.args.gencnfs): 
                print("Network winner {}  vs  True winner {}".format(winner, true_label))
                solver = MinisatSolverExt( var2cnf = var2cnf)
                print("Create solver, # high-level constraints ({})".format(len(constraints)))            
                solver.populate_solver(constraints)   
                print("Run solver")            
                sat_result, model, purecore = solver.solve_limited()        
            else:      
                start = time.time()                        
                ####################################
                # convertion to CNF
                ####################################
                #print(sample_file)
                cnf_file_name, assumption_file_name = self.save_cnf(constraints = constraints, cnf_file_name = "./sat_outputs/" + sample_file, var2cnf = var2cnf) 
                ###################################
                # Reading CNF and assumptions
                ###################################
                print ("Reading CNF/assumptions  file ", cnf_file_name, assumption_file_name)
                satsolver_infile = open(cnf_file_name, 'r')
                satsolver_assump_infile = open(assumption_file_name, 'r')    
                solver = MinisatSolverExt(cnf_infile = satsolver_infile,  assump_infile = satsolver_assump_infile)
                satsolver_infile.close()
             
                sat_result, model, purecore = solver.solve_limited()
                
                end = time.time()
                print(end - start)

            print(sat_result)
            #######################
            # Process results
            #######################
            if (sat_result == SOLVER_SAT_RESULT):
                sat_assignments = {}
                for var_id in forward_assignments:
                    cnd_id = var2cnf[var_id]
                    var_with_pol = model[cnd_id]
                    var_cnf_id = abs(var_with_pol)
                    #print("getting [{}]  {} ".format(var_cnf_id, var_id))
                    if (var_with_pol <= 0):
                        sat_assignments[var_id] = 0
                    else:
                        sat_assignments[var_id] = 1
                if (self.args.small_test):
                    print("correct execution", forward_assignments)
                    print("sat     execution", sat_assignments)
                if (forward_assignments != sat_assignments):
                    print("Error: SAT execution has a bug")
                    exit()
                
            
            if (sat_result == SOLVER_UNSAT_RESULT):
                unsat_assignments = purecore
                if (self.args.small_test):
                    print ("Core: ", purecore)
                if (winner == true_label):
                    print("Error: UNSAT execution has a bug")
                    exit()
                if (not self.args.small_test):
                    learner_res = LEARNER_NEG_RESULT
                    return learner_res, purecore    
                
        
        return learner_res, {}                
            
            #     for i in range(1, len(model)):
            #         var_with_pol = model[i]
            #         var_cnf_id = abs(var_with_pol)
            #         var_id = getkey_by_value(var2cnf, var_cnf_id)
            #         if (var_id in forward_assignments):
            #             print("getting [{}]  {} ".format(var_cnf_id, var_id))
            #             if (var_with_pol < 0):
            #                 sat_assignments[var_id] =0
            #             else:
            #                 sat_assignments[var_id] =1
            #         else:
            #             print("scip [{}]  {} ".format(var_cnf_id, var_id))
        
        # ################################
        # # Evaluate outputs
        # ################################
        # z = input
        # for layer in layers[:-1]:
        #     z = layer.dot(z)
        #     # print("output {}".format(z))
        #     z = np.sign(z)
        #     z[z == 0] = 1
        #     # print("bin output {}".format(z))
        # # laste layer -- no sign
        # z = layers[-1].dot(z)
        # print("Computed forward path --  output {}".format(z))
        # 
        # #########################
        # # Assume that teh following relattion between Booelan variables and -1/1 variables
        # # TODO explain this  
        # # b_i = 1  iff z_i =1  
        # # b_i = 0  iff z_i =-1  
        # #########################
        # 
        # temp_file = args.cnfdest + FILE_TEMP_EXTENTION;
        # cnf_file = open(temp_file, 'w')
        # 
        # x = input    
        # ls = len(layers)
        # varids2values = {}
        # varids2cnf_varids = {}
        # 
        # nb_constraints = 0;
        # 
        # constraints = {} 
        # o = []
        # for k in range(0, ls):
        #     layer = layers[k]
        #     rows = layer.shape[0]
        #     cols = layer.shape[1]
        #     
        #     
        #     y = layer.dot(x)
        #     z = np.sign(y)
        #     z[z == 0] = 1
        # 
        #     
        #     local_y = np.empty((0), int)
        #     local_z = np.empty((0), int)
        #     for i in range(0, rows):
        #         full_ineq = ''
        #         simplified_ineq = ''
        #         
        #         full_sum = 0
        #         simplified_sum = 0
        #         
        #         coeffs = []
        #         vars_ids = []
        #         constterm = 0
        #         
        #         for j in range(0, cols):
        #             # a[k,i,j] = 1 NXOR y[k,j] = 1 <=>  b[k,i,j] =1
        # 
        #             ############ form xnor constraint #################             
        #             # form coeff id
        #             a_id = ("{}_{}{}{}".format(LAYER_VAR_ID, k, i, j))
        #             get_cnf_varid(varids2cnf_varids, a_id)
        # 
        #             # form neuron id
        #             x_id = ("{}_{}{}".format(NEURON_VAR_ID, k, j))
        #             get_cnf_varid(varids2cnf_varids, x_id)
        # 
        #             # form output neuron id
        #             z_id = ("{}_{}{}".format(NEURON_VAR_ID, k + 1, i))
        #             get_cnf_varid(varids2cnf_varids, z_id)
        # 
        #             # form mult extar var id
        #             b_id = ("{}_{}{}{}".format(MULT_VAR_ID, k, i, j))
        #             get_cnf_varid(varids2cnf_varids, b_id)
        #             
        #             # store unary constraints for coeff
        #             constraints[form_unary_constraint_name(a_id)] = [a_id, 1  if layer[i][j] >= 0 else 0]     
        #             if (k == 0):
        #                 if form_unary_constraint_name(x_id) not in constraints.keys():
        #                     # store unary constraints for inputs    
        #                     constraints[form_unary_constraint_name(x_id)] = [x_id, 1  if input[j] >= 0 else 0] 
        #                    
        #             # store NXOR constraint 
        #             constraints[form_nxor_constraint_name(k, i, j)] = [a_id, x_id, b_id]
        #             
        #             
        #             # [4DEBUG] evalutae nxor 
        #             varids2values[a_id] = 1  if layer[i][j] >= 0 else 0
        #             varids2values[x_id] = 1  if x[j] >= 0 else 0       
        #             varids2values[b_id] = bool(varids2values[a_id]) == bool(varids2values[x_id])                       
        # 
        # 
        #             ############### form linear constraint ################
        #             coeffs = np.append(coeffs, 2)
        #             vars_ids = np.append(vars_ids, b_id)
        #             constterm = constterm - 1      
        #             
        #             # [4DEBUG] computing linear constraint .... 
        #             full_sum = full_sum + 2 * varids2values[b_id] - 1
        #             
        #         if (bool(full_sum >= 0) != bool(z[i] == 1)):
        #             print(" The following constraint is incorrect " + full_ineq)
        #             exit()
        #             
        #         # [4DEBUG] check sums    
        #         local_y = np.append(local_y, full_sum)      
        #         
        #         
        #         if (k < ls - 1):            
        #             # add reified constraint
        #             constraints[form_linear_reified_constraint_name(k, i)] = [coeffs, vars_ids, z_id, constterm]
        #             if (bool(simplified_sum + constterm >= 0) != bool(z[i] == 1)):
        #                 print(" The following constraint is incorrect ")
        #                 print_linear_reified_constraint(constraints[form_linear_reified_constraint_name(k, i)])
        #                 exit()
        #             temp = 1 if full_sum >= 0  else -1    
        #             local_z = np.append(local_z, temp)      
        #         else:    
        #             # collect linear constraint to build partial ordering of outputs
        #             constraints[form_linear_constraint_name(k, i)] = [coeffs, vars_ids, constterm]
        # 
        #     if (np.array_equal(local_y, y) != True):
        #         print("invalid forward simulation ", local_y, y)
        #         exit()   
        #     if (k < ls - 1):
        #         if (np.array_equal(local_z, z) != True):
        #             print("invalid forward simulation ", local_z, z)
        #             exit()
        #     else:
        #         # introduce order variables
        #         # o[i] == 1 iff y[label] >= y[i]
        #         # o[i] == 1 iff y[label] - y[i] >=0               
        #         for i in range(0, rows):
        #             if(i == true_label):
        #                 continue            
        #             coeff_new = constraints[form_linear_constraint_name(k, true_label)][0]
        #             vars_ids_new = constraints[form_linear_constraint_name(k, true_label)][1]
        #             constterm_new = constraints[form_linear_constraint_name(k, true_label)][2]
        # 
        #             coeff_other = -1 * constraints[form_linear_constraint_name(k, i)][0]
        #             vars_ids_other = constraints[form_linear_constraint_name(k, i)][1]
        #             constterm_other = -1 * constraints[form_linear_constraint_name(k, i)][2]            
        #     
        #             coeff_new = np.append(coeff_new, coeff_other)  
        #             vars_ids_new = np.append(vars_ids_new, vars_ids_other)
        #             constterm_new = constterm_new + constterm_other
        #             
        #             
        #             o_id = ("{}_{}".format(ORDER_VAR_ID, i))
        #             o = np.append(o, o_id)
        #             get_cnf_varid(varids2cnf_varids, o_id)            
        #             constraints[form_linear_reified_constraint_name(k, i)] = [coeff_new, vars_ids_new, o_id, constterm_new]
        # #             
        #             varids2values[o_id] = 1  if local_y[true_label] >= local_y[i] else 0
        #         
        #     x = z;
        #     
        # print("\n\nModel:")
        # for keys, values in sorted(constraints.items()):
        #     if (keys[:4] == UNARY_CON_ID): 
        #         unary_constraint4bool_var(cnf_file, varids2cnf_varids, values)            
        #         print_unary_constraint(values)
        #     if (keys[:4] == NXOR_CON_ID): 
        #         nxor_input_reified(cnf_file, varids2cnf_varids, values)            
        #         print_nxor_constraint(values)
        #     if (keys[:4] == LIN_REIFIED_CON_ID):
        #         # we divide all coffs and the rhs by 2   as we know that all coeef are equal to 2     
        #         values[0] = [x / 2 for x in values[0]]  
        #         values[3] = math.floor(values[3] / 2)      
        #         # print_linear_reified_constraint(values)
        #         # we transform constraint 
        #         seqcounters4unary_coeff_linear_reified(cnf_file, varids2cnf_varids, coeffs=values[0], vars_ids=values[1], output_var_id=values[2], constterm=values[3])
        #     # if (keys[:4] == LIN_CON_ID):
        #     #    print_linear_constraint_name(values)        
        # 
        # # ensure that the winner belongs to the true class
        # for o_id in o:
        #     add_clause(cnf_file, varids2cnf_varids, [o_id])
        #         
        # cnf_file.close()
        # 
        # add_first_line2cnf(temp_file, args.cnfdest, len(varids2cnf_varids))
        # 
        # 
        # exit()

             
        #build neurons map
  