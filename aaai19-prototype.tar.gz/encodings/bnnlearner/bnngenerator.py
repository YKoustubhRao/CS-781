from __future__ import print_function, division
import scipy.misc
import numpy as np
import json
import math 
import string
from parser import *
from con2cnf import *
from con2ilp import *
from utils import *
from bnnencoder import *
from bnnlearner import *
from satsolver import *
from ilpsolver import *
from pyminisolvers import minisolvers
import copy
import ntpath
import pprint
try:
    from cplex import *
except:
    print(" no cplex")

class BNNGenerator(object):
    """A encoding of BNN to CNFs:
    
    Attributes:
        config file: network structure
    """

    def __init__(self, args, network_definition):
        self.args  = args
        self.sample_test_files = [] 
        path  = args.data_test 
        print(path)
        for name in os.listdir(path):
            if os.path.isfile(os.path.join(path, name)):
                self.sample_test_files.append(path + name)
        

        self.sample_files = [] 
        path  = args.data_train
        for name in os.listdir(path):
            if os.path.isfile(os.path.join(path, name)):
                self.sample_files.append(path + name)
        
        self.nb_images = len( self.sample_files)
        # init network
        self.var2cnf = {}
        #print("reading network {}".format(args.definenetwork))
        self.bnnenc = BNNEncoder4Generator(network_definition, self.var2cnf) 
                
    def create_ilp(self, constraints, constraints_ordering, solver, var2cnf):     
        l = len(constraints)
        #printProgressBar(0, l, prefix = 'Progress:', suffix = 'Complete', length = 50 ) 
        cnt_prefix = 0
        for i,keys in constraints_ordering.items():
            values = constraints[keys]
            print(i)    
            con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + str(cnt_prefix) + "_"           
            if (LIN_REIFIED_CON_ID in keys):
                linear_inequality_constraint_reified_ilp([ILP_SOLVER_DESTINATION, solver], var2cnf, coeffs=values[0], vars_ids=values[1], output_var_id=values[2], constterm=values[3], constraint_prefix=con_prefix)

            if (LIN_EQUALITY_CON_ID in keys):
                linear_equlaity_constraint_reified_ilp([ILP_SOLVER_DESTINATION, solver], var2cnf, coeffs=values[0], vars_ids=values[1], coeff_output_var_id=values[2], output_var_id=values[3], constterm=values[4], constraint_prefix=con_prefix)

            #printProgressBar(cnt_prefix, l, prefix = 'Progress:', suffix = 'Complete', length = 50)
            cnt_prefix += 1     
            #if (cnt_prefix > 0):
            #    break
         
             
        #solver.s.write("example1.lp")
        #solver.s.solve()
        
        # And print the solutions
        #print(solver.s.solution.get_values())
        #print(solver.s.variables.get_names())
        return ""  
    
    def check_network_encoding_manually(self, run_ilp = None, solver = None):
        #######################################
        # check that encoding is correct
        ########################################
        for sample_file in self.sample_files:
            constraints = copy.deepcopy(self.bnn_constraints)
            constraints_ordering = copy.deepcopy(self.bnn_constraints_ordering)
            var2cnf = copy.deepcopy(self.var2cnf)
            
            #########################
            # Read input file
            # We assume that all inputs/matrices are 1/-1
            #########################
            print(sample_file)
            print("Reading input: {}".format(sample_file))            
            input, true_label = parse_input( sample_file)
            #print_vec_as_textimage(input[:], self.bnnenc.side)       
            forward_assignments, winner = self.bnnenc.forward(input[:])
            print("winner {}".format(winner))
            #print("forward_assignments", forward_assignments)

            if (run_ilp is True):
                for i in range(0, len(input)):
                    x_id = create_indexed_variable_name(NEURON_VAR_ID, [self.bnnenc.layers[0].id, i]) 
                    x_id_value =  1  if input[i] >= 0 else 0 
                    constraint_name = x_id + "_set_test"
                    constraint_names = solver.s.linear_constraints.get_names()
                    if (constraint_name in constraint_names): 
                        solver.s.linear_constraints.delete(constraint_name)
                    indices = solver.s.linear_constraints.add(
                                    rhs = [x_id_value],
                                    senses = ['E'],
                                    lin_expr = [[[x_id],[1]]],
                                    names = [constraint_name])
                solver.s.write("example2.lp")
                solver.s.solve()
                sol_vars_value = solver.s.solution.get_values()
                sol_vars_names = solver.s.variables.get_names()
                ilp_assignments = {}
                for i in range(len(sol_vars_value)): 
                    ilp_assignments[sol_vars_names[i]] = sol_vars_value[i]
                    #print(sol_vars_names[i], sol_vars_value[i])
                
            ############################
            # encode input, label
            ###########################
            
            global_counter  = -1                 
            # fix input
            for i in range(0, len(input)):
                x_id = create_indexed_variable_name(NEURON_VAR_ID, [self.bnnenc.layers[0].id, i]) 
                get_cnf_varid(var2cnf, x_id)
                constraints[form_unary_constraint_name(x_id)] = [x_id, 1  if input[i] >= 0 else 0] 
                constraints_ordering[global_counter] = form_unary_constraint_name(x_id)
                global_counter -= 1                 
            constraints_ordering = dict(sorted(constraints_ordering.items()))
            
            
            print("Checking inputs")
            set_vars = {}
            for i in range(0, len(input)):
                x_id = create_indexed_variable_name(NEURON_VAR_ID, [self.bnnenc.layers[0].id, i]) 
                x_id_val = 1  if input[i] >= 0 else 0
                set_vars[x_id] = x_id_val
                x_network_assignments = forward_assignments[x_id]
                if (x_network_assignments != x_id_val):
                    print("Input problem: ", x_id, "True ", x_id_val, "Comp", x_network_assignments)
                    exit()                        
                if (run_ilp is True):
                    x_ilp_assignments = ilp_assignments[x_id]
                    if (x_ilp_assignments != x_id_val):
                        print("ILP:   Input problem: ", x_id, "True ", x_id_val, "Comp", x_network_assignments)
                        exit()     

            print("Inputs are ok")        
         
            for i in  self.bnnenc.constraints_ordering:                        
                con_name = self.bnnenc.constraints_ordering[i]
                constraint = constraints[con_name]
                print_constraint(con_name, constraint)                                   
                if (LIN_REIFIED_CON_ID  in con_name):
                    [coeffs, vars_ids,  z_id, constterm] = constraint
                    s = 0
                    for i in range(len(vars_ids)):
                        a  = coeffs[i]
                        y  = set_vars[vars_ids[i]]
                        s = s + a*y              
                        #print(vars_ids[i], y, end =" \n")               
                    s = s + constterm
                    #y_id_test  = "test_" + z_id
                    #print("y_id_test",y_id_test, forward_assignments[y_id_test])
                    
                    comp_y = 1 if s >= 0 else 0
                    y_next_network_assignments = forward_assignments[z_id]
                    #print(y_next_network_assignments)                        
                    if (comp_y != y_next_network_assignments):
                        print("LIN reified problem: sum a_x_i + cont > 0 ", comp_y, "Comp", y_next_network_assignments)
                        print(coeffs, vars_ids,  z_id, constterm)
                        exit()
                        
                    if (run_ilp is True):
                        z_id_test  = TEST_VAR_PREF_ID + z_id                        
                        z_test_next_network_assignments = forward_assignments[z_id_test]
                        #z_test_next_ilp_assignments = ilp_assignments[z_id_test]
                        
                        #if(s != z_test_next_ilp_assignments):
                        #    print("ILP:    LIN reified problem: sum a_x_i = ", s, "ilp = ", z_test_next_ilp_assignments)
                        #    exit()     
                        z_ilp_assignments = ilp_assignments[z_id]
                        print("---> ", z_id, s, z_test_next_ilp_assignments)
                        if (z_ilp_assignments != comp_y):
                            print("ILP:    LIN reified problem: sum a_x_i + cont > 0 ", comp_y, "Comp", z_ilp_assignments)
                            exit()     
                    
                    set_vars[z_id] = y_next_network_assignments
                    print("OK") 
                    
                if (LIN_EQUALITY_CON_ID  in con_name):
                    [coeffs, vars_ids, coeff_z_id,  z_id, constterm] = constraint
                    print( [coeffs, vars_ids, coeff_z_id,  z_id, constterm])
                    s = 0
                    for i in range(len(vars_ids)):
                        a  = coeffs[i]
                        y  = set_vars[vars_ids[i]]
                        s = s + a*y              
                        #print(vars_ids[i], y, end =" \n")               
                    s = s + constterm
                    
          
                    comp_y = s/coeff_z_id
                    #y_id_test  = "test_" + z_id
                    #print("y_id_test",y_id_test, forward_assignments[y_id_test])
                    y_next_network_assignments = forward_assignments[z_id]
                    #print(y_next_network_assignments, comp_y)
                    #exit()
                    #print(y_next_network_assignments)                        
                    if (comp_y != y_next_network_assignments):
                        print("LIN reified problem: sum a_x_i + cont  = coeff*z", comp_y, "Comp", y_next_network_assignments)
                        print(coeffs, vars_ids,  z_id, constterm)
                        exit()

                    if (run_ilp is True):
                        z_ilp_assignments = ilp_assignments[z_id]
                        print(" out ", z_ilp_assignments, comp_y)
                        if (z_ilp_assignments != comp_y):
                            print("ILP:   LIN reified problem: sum a_x_i + cont  = coeff*z", comp_y, "Comp", y_next_network_assignments)
                            exit()     
                    
                    set_vars[z_id] = y_next_network_assignments
                    print("OK") 
                    #exit()    
                
            print("OK for this image")
            
    def append_right_neighb(self, vars, coeffs, colors_sym, c, i, j, n, coeff):
        if (j < n - 1):        
            vars.append(colors_sym[c][i][j+1])
            coeffs.append(coeff)

    def append_left_neighb(self, vars, coeffs, colors_sym, c, i, j, n, coeff):
        if (j > 0 ):        
            vars.append(colors_sym[c][i][j-1])
            coeffs.append(coeff)

    
    def append_down_neighb(self, vars, coeffs, colors_sym, c, i, j, n, coeff):
        if (i < n - 1):        
            vars.append(colors_sym[c][i+1][j])
            coeffs.append(coeff)
    def append_up_neighb(self, vars, coeffs, colors_sym, c, i, j, n, coeff):
        if (i >  0):        
            vars.append(colors_sym[c][i-1][j])
            coeffs.append(coeff)
            
    def encode_left_up_corner(self, solver, c, ci, cj, colors_sym, n):
        #Left upper rectangle, $i \in [0,i_c^k), j \in [0,j_c^k)$. Relevant neighbors are right and down  
        #x_{i,j}^k \Rightarrow (x_{i,j+1}^k \vee x_{i+1,j}^k),
        rhs = 1
        for i in range(ci):
            for j in range(cj):                    
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_left_upper_" + colors_sym[c][i][j]
                indicator_id = colors_sym[c][i][j]
                neighbour_ids = []
                neighbour_coeff = []
                self.append_right_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                self.append_down_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                solver.s.indicator_constraints.add(indvar = indicator_id,
                                   complemented = 0,
                                   rhs = rhs,
                                   sense = "G",
                                   lin_expr = [neighbour_ids, neighbour_coeff],
                                   name = con_prefix)    

    def encode_right_up_corner(self, solver, c, ci, cj, colors_sym, n):
        #Right upper rectangle, $i \in [0,i_c^k), j \in (j_c^k,n]$. Relevant neighbors are left and down  
        #x_{i,j}^k \Rightarrow (x_{i,j-1}^k \vee x_{i+1,j}^k),         rhs = 1
        rhs = 1
        for i in range(ci):
            for j in range(cj+1,n):                    
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_right_upper_" + colors_sym[c][i][j]
                indicator_id = colors_sym[c][i][j]
                neighbour_ids = []
                neighbour_coeff = []
                self.append_left_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                self.append_down_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                solver.s.indicator_constraints.add(indvar = indicator_id,
                                   complemented = 0,
                                   rhs = rhs,
                                   sense = "G",
                                   lin_expr = [neighbour_ids, neighbour_coeff],
                                   name = con_prefix)            

    def encode_left_down_corner(self, solver, c, ci, cj, colors_sym, n):
        #Left lower rectangle, $i \in (i_c^k,n], j \in [0,j_c^k)$. Relevant neighbors are right and up  
        #x_{i,j}^k \Rightarrow (x_{i,j+1}^k \vee x_{i-1,j}^k),
        rhs = 1
        for i in range(ci+1,n):
            for j in range(cj):                    
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_left_down_" + colors_sym[c][i][j]
                indicator_id = colors_sym[c][i][j]
                neighbour_ids = []
                neighbour_coeff = []
                self.append_right_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                self.append_up_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                solver.s.indicator_constraints.add(indvar = indicator_id,
                                   complemented = 0,
                                   rhs = rhs,
                                   sense = "G",
                                   lin_expr = [neighbour_ids, neighbour_coeff],
                                   name = con_prefix)    
                
    def encode_right_down_corner(self, solver, c, ci, cj, colors_sym, n):
        # Right lower rectangle, $i \in (i_c^k,n], j \in (j_c^k,n]$. Relevant neighbors are left and up  
        #x_{i,j}^k \Rightarrow (x_{i,j-1}^k \vee x_{i-1,j}^k), 
        rhs = 1
        for i in range(ci+1,n):
            for j in range(cj+1,n):                    
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_right_down_" + colors_sym[c][i][j]
                indicator_id = colors_sym[c][i][j]
                neighbour_ids = []
                neighbour_coeff = []
                self.append_left_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                self.append_up_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                solver.s.indicator_constraints.add(indvar = indicator_id,
                                   complemented = 0,
                                   rhs = rhs,
                                   sense = "G",
                                   lin_expr = [neighbour_ids, neighbour_coeff],
                                   name = con_prefix)    
    def encode_up_tunnel(self, solver, c, ci, cj, colors_sym, n):
        #\item Up tunnel, $i \in [0,i_c^k), j \in [j_c^k]$. Relevant neighbor is down 
        #x_{i,j}^k \Rightarrow (x_{i+1,j}^k), 
        rhs = 1
        for i in range(ci):
            for j in range(cj,cj+1):                    
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_up_tunnel_" + colors_sym[c][i][j]
                indicator_id = colors_sym[c][i][j]
                neighbour_ids = []
                neighbour_coeff = []
                self.append_down_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                solver.s.indicator_constraints.add(indvar = indicator_id,
                                   complemented = 0,
                                   rhs = rhs,
                                   sense = "G",
                                   lin_expr = [neighbour_ids, neighbour_coeff],
                                   name = con_prefix)         
    def encode_down_tunnel(self, solver, c, ci, cj, colors_sym, n):
        #\item Down tunnel, $i \in (i_c^k,n], j \in [j_c^k]$. Relevant neighbor is up
        #x_{i,j}^k \Rightarrow (x_{i-1,j}^k),
        rhs = 1
        for i in range(ci+1,n):
            for j in range(cj,cj+1):                    
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_down_tunnel_" + colors_sym[c][i][j]
                indicator_id = colors_sym[c][i][j]
                neighbour_ids = []
                neighbour_coeff = []
                self.append_up_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                solver.s.indicator_constraints.add(indvar = indicator_id,
                                   complemented = 0,
                                   rhs = rhs,
                                   sense = "G",
                                   lin_expr = [neighbour_ids, neighbour_coeff],
                                   name = con_prefix)         
    def encode_left_tunnel(self, solver, c, ci, cj, colors_sym, n):
        #\item Left tunnel, $i \in [i_c^k], j \in [0, j_c^k)$.  Relevant neighbor is right
        #x_{i,j}^k \Rightarrow (x_{i,j+1}^k), 
        rhs = 1
        for i in range(ci,ci+1):
            for j in range(cj):                    
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_left_tunnel" + colors_sym[c][i][j]
                indicator_id = colors_sym[c][i][j]
                neighbour_ids = []
                neighbour_coeff = []
                self.append_right_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                solver.s.indicator_constraints.add(indvar = indicator_id,
                                   complemented = 0,
                                   rhs = rhs,
                                   sense = "G",
                                   lin_expr = [neighbour_ids, neighbour_coeff],
                                   name = con_prefix)         

    def encode_right_tunnel(self, solver, c, ci, cj, colors_sym, n):
        #\item Right tunnel, $i \in [i_c^k], j \in (j_c^k,n]$.  Relevant neighbor is left
        #x_{i,j}^k \Rightarrow (x_{i,j-1}^k), 
        rhs = 1
        for i in range(ci,ci+1):
            for j in range(cj+1,n):                    
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_right_tunnel" + colors_sym[c][i][j]
                indicator_id = colors_sym[c][i][j]
                neighbour_ids = []
                neighbour_coeff = []
                self.append_left_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = c, i = i , j = j , n = n, coeff = 1)
                solver.s.indicator_constraints.add(indvar = indicator_id,
                                   complemented = 0,
                                   rhs = rhs,
                                   sense = "G",
                                   lin_expr = [neighbour_ids, neighbour_coeff],
                                   name = con_prefix)         

    def encode_central_point(self, solver, c, ci, cj, colors_sym, n):
        #\item Right tunnel, $i \in [i_c^k], j \in (j_c^k,n]$.  Relevant neighbor is left
        #x_{i,j}^k \Rightarrow (x_{i,j-1}^k), 
        rhs = 1
        for i in range(ci,ci+1):
            for j in range(cj,cj+1):                    
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_central" + colors_sym[c][i][j]
                solver.s.linear_constraints.add(rhs = [rhs],
                                            senses = ['E'],
                                           lin_expr = [[[ colors_sym[c][i][j]], [1]]],
                                            names = [con_prefix])  
                
    def encode_non_overlap_up(self, solver, colors_sym, c, p, i, j, n, coeff):
        # x_{i,j}^c \Rightarrow x_{i-1,j}^p
        if (i == 0):
            return
        con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_between_grains_" + str(c) + "_" + str(p) + "_up"
        indicator_id = colors_sym[c][i][j]
        neighbour_ids = []
        neighbour_coeff = []
        rhs = 0
        self.append_up_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = p, i = i , j = j , n = n, coeff = 1)
        solver.s.indicator_constraints.add(indvar = indicator_id,
                       complemented = 0,
                       rhs = rhs,
                       sense = "E",
                       lin_expr = [neighbour_ids, neighbour_coeff],
                       name = con_prefix)    

    def encode_non_overlap_down(self, solver, colors_sym, c, p, i, j, n, coeff):
        # x_{i,j}^c \Rightarrow x_{i+1,j}^p 
        if (i == n-1):
            return
        con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_between_grains_" + str(c) + "_" + str(p) + "_down"
        indicator_id = colors_sym[c][i][j]
        neighbour_ids = []
        neighbour_coeff = []
        rhs = 0
        self.append_down_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = p, i = i , j = j , n = n, coeff = 1)
        solver.s.indicator_constraints.add(indvar = indicator_id,
                       complemented = 0,
                       rhs = rhs,
                       sense = "E",
                       lin_expr = [neighbour_ids, neighbour_coeff],
                       name = con_prefix)    

    def encode_non_overlap_left(self, solver, colors_sym, c, p, i, j, n, coeff):
        # x_{i,j}^c \Rightarrow x_{i,j-1}^p 
        if (j == 0):
            return
        con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_between_grains_" + str(c) + "_" + str(p) + "_left"
        indicator_id = colors_sym[c][i][j]
        neighbour_ids = []
        neighbour_coeff = []
        rhs = 0
        self.append_left_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = p, i = i , j = j , n = n, coeff = 1)
        solver.s.indicator_constraints.add(indvar = indicator_id,
                       complemented = 0,
                       rhs = rhs,
                       sense = "E",
                       lin_expr = [neighbour_ids, neighbour_coeff],
                       name = con_prefix)    
    def encode_non_overlap_right(self, solver, colors_sym, c, p, i, j, n, coeff):
        # x_{i,j}^c \Rightarrow (x_{i,j+1}^p = 0        
        if (j == n-1):
            return
        con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_between_grains_" + str(c) + "_" + str(p) + "_right"
        indicator_id = colors_sym[c][i][j]
        neighbour_ids = []
        neighbour_coeff = []
        rhs = 0
        self.append_right_neighb(vars = neighbour_ids, coeffs = neighbour_coeff, colors_sym = colors_sym, c = p, i = i , j = j , n = n, coeff = 1)
        solver.s.indicator_constraints.add(indvar = indicator_id,
                       complemented = 0,
                       rhs = rhs,
                       sense = "E",
                       lin_expr = [neighbour_ids, neighbour_coeff],
                       name = con_prefix)    
    
    def encode_roundness_one_point(self, solver, colors_sym, p, c, prev_cir):
        # x_{i,j}^c \Rightarrow sum_{x_{i,j+1}^c \in prev circle} x_{i,j}^c = |prev_cir|        

        con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_between_point_" + str(p) + "_circle" + str(prev_cir)
        indicator_id = colors_sym[c][p[0]][p[1]]
        neighbour_ids = []
        neighbour_coeff = []
        rhs = len(prev_cir)
        coeff = 1
        for q in prev_cir:
            neighbour_ids.append(colors_sym[c][q[0]][q[1]])
            neighbour_coeff.append(coeff)
        solver.s.indicator_constraints.add(indvar = indicator_id,
                       complemented = 0,
                       rhs = rhs,
                       sense = "E",
                       lin_expr = [neighbour_ids, neighbour_coeff],
                       name = con_prefix)    
    def append_row_part(self, vec, i, left_j, right_j, n):
        # we take into account the boundary is always void so the first element is 1 and the last element is at n - 2        
        if (i < 1):
            return

        if (i >= n-1):
            return
        left_j = max(left_j, 1)
        # we take into account the boundary is always void so the first element is 1 and the last element is at n - 2        
        right_j = min(right_j, n - 2)
        
        
        for j in range(left_j, right_j+1):
                c = [i,j]
                if (c not in vec):
                    vec.append(c)
        

    def append_column_part(self, vec, j, up_i, down_i, n):
        # we take into account the boundary is always void so the first element is 1 and the last element is at n - 2        
        if (j < 1):
            return

        if (j >= n-1):
            return

        up_i = max(up_i, 1)
        down_i = min(down_i, n - 2)
        
        for i in range(up_i, down_i+1):
                c = [i,j]
                if (c not in vec):
                    vec.append(c)
        
    def gen_circles(self, ci, cj , n):
        C = {}
        for d in range(n):
            C[d] = []
            #get four points (up, left,down, right( from the central
            up_i = ci - d 
            left_j = cj - d  
            down_i = ci + d 
            right_j = cj + d
            # top row
            self.append_row_part(C[d], i = up_i, left_j = left_j , right_j = right_j, n = n)
            #bottom row                
            self.append_row_part(C[d], i = down_i, left_j = left_j , right_j = right_j, n = n)
            #left column 
            self.append_column_part(C[d], j = left_j, up_i = up_i, down_i = down_i, n = n)
            #right column 
            self.append_column_part(C[d], j = right_j, up_i = up_i, down_i = down_i, n = n)
            #print("C[{}]".format(d), C[d])
        return C
    
    def encode_set_to_true(self, solver, colors_sym, c, i, j):
        con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_set_true_" + str(c) + "_" + str(i) + "_" +str(j)
        colors_ids = [colors_sym[c][i][j]]
        colors_coeff = [1]
        rhs = [1]
        solver.s.linear_constraints.add(rhs = rhs,
                                    senses = ['E'],
                                    lin_expr = [[colors_ids, colors_coeff]],
                                    names = [con_prefix])
    def run(self):
        self.bnn_constraints, self.bnn_constraints_ordering = self.bnnenc.generate_network_constraints()
        print_constraints(self.bnn_constraints, self.bnn_constraints_ordering)
        
        constraints = copy.deepcopy(self.bnn_constraints)
        constraints_ordering = copy.deepcopy(self.bnn_constraints_ordering)
        var2cnf = copy.deepcopy(self.var2cnf)
        solver = CplexSolverExt(var2cnf = var2cnf)
        self.create_ilp(constraints, constraints_ordering, solver, var2cnf)

        #self.check_network_encoding_manually(run_ilp = True, solver = solver)
        
        nb_inputs = self.bnnenc.layers[0].nb_cols        
        side = math.floor(math.sqrt(nb_inputs))

        solver.s.parameters.randomseed.set(self.args.seed)
        solver.s.parameters.timelimit.set(self.args.timelim)

        colors = range(self.args.gen_nb_grains)
        if (len(self.args.gen_central_points_i) == 0):
            colors_c_i = [3,  side-3, math.floor(side/2)]
        else:
            colors_c_i = self.args.gen_central_points_i
        
        if (len(self.args.gen_central_points_j) == 0):
            colors_c_j = [3, side-3, math.floor(side/2)]
        else:
            colors_c_j = self.args.gen_central_points_j
            
        print(colors_c_i, colors_c_j)
        
        # form circles
        circles = {}
        for c in  colors[:]:
            # central point
            ci = colors_c_i[c]
            cj = colors_c_j[c]
            circles[c] = self.gen_circles(ci = ci,cj =cj, n = side)
        print(circles[1])

        
        inputs2colors = {}
        objective = [0]
        lower_bounds = [colors[0]]
        upper_bounds = [colors[-1]]
        types = [solver.s.variables.type.integer]
        
        # we introduce variables per pixel        
        nb_color = len(colors)
        colors_sym = [[[0 for i in range(side)] for j in range(side)] for c in range(nb_color)] 
        for i in range(side):
            for j in range(side):
                for c in colors:
                    x_id_c  = create_indexed_variable_name(COLORS_VAR_ID,[c, i, j])
                    #print(c,i,j)
                    colors_sym[c][i][j] = x_id_c
                    #print(x_id_c)
                    solver.s.variables.add(
                            obj = objective,
                            lb = lower_bounds,
                            ub = upper_bounds,
                            types  = types,
                            names = [x_id_c])
        
        

        # ont one color is possible
        for i in range(side):
            for j in range(side):
                colors_ids = []
                colors_coeff = []
                for c in colors:
                    colors_ids.append(colors_sym[c][i][j])
                    colors_coeff.append(1)
                rhs = [1]
                con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_color_one_" + str(i*side+j)
                #print( [[colors_ids, colors_coeff]], rhs, [con_prefix])
                solver.s.linear_constraints.add(rhs = rhs,
                                    senses = ['E'],
                                    lin_expr = [[colors_ids, colors_coeff]],
                                    names = [con_prefix])
        
        # inside grain
        for c in  colors[:]:
            # central point
            ci = colors_c_i[c]
            cj = colors_c_j[c]
            self.encode_left_up_corner(solver = solver, c = c, ci = ci, cj = cj, colors_sym = colors_sym, n = side)
            self.encode_right_up_corner(solver = solver, c = c, ci = ci, cj = cj, colors_sym = colors_sym, n = side)
            self.encode_left_down_corner(solver = solver, c = c, ci = ci, cj = cj, colors_sym = colors_sym, n = side)
            self.encode_right_down_corner(solver = solver, c = c, ci = ci, cj = cj, colors_sym = colors_sym, n = side)
            self.encode_up_tunnel(solver = solver, c = c, ci = ci, cj = cj, colors_sym = colors_sym, n = side)
            self.encode_down_tunnel(solver = solver, c = c, ci = ci, cj = cj, colors_sym = colors_sym, n = side)
            self.encode_left_tunnel(solver = solver, c = c, ci = ci, cj = cj, colors_sym = colors_sym, n = side)
            self.encode_right_tunnel(solver = solver, c = c, ci = ci, cj = cj, colors_sym = colors_sym, n = side)
            self.encode_central_point(solver = solver, c = c, ci = ci, cj = cj, colors_sym = colors_sym, n = side)

        # roundness 
        for c in  colors[:-1]:
            # central point
            ci = colors_c_i[c]
            cj = colors_c_j[c]
            cirs = circles[c]
            for i in range(self.args.prev_circle[c],len(cirs)):
                prev_cir = cirs[i-self.args.prev_circle[c]]
                cir = cirs[i]
                for p in cir:
                    self.encode_roundness_one_point(solver, colors_sym = colors_sym, p = p, c = c, prev_cir = prev_cir)
                
        # boundary are void
        for i in [0,side-1]:
            for j in range(side):
                c= colors[-1]
                self.encode_set_to_true(solver = solver, c = c, i = i, j = j, colors_sym = colors_sym)
        for j in [0,side-1]:
            for i in range(side):
                c= colors[-1]
                self.encode_set_to_true(solver = solver, c = c, i = i, j = j, colors_sym = colors_sym)
                
            

        # grains do nto touch
        for c in  colors[:-1]:            
            for p in  colors[:-1]:
                if (c == p):
                    continue                
                for i in range(side):
                    for j in range(side):                    
                        self.encode_non_overlap_up(solver = solver,  colors_sym = colors_sym, c = c, p = p, i = i, j = j , n = side, coeff = 1)
                        self.encode_non_overlap_down(solver = solver,  colors_sym = colors_sym, c = c, p = p, i = i, j = j , n = side, coeff = 1)
                        self.encode_non_overlap_left(solver = solver,  colors_sym = colors_sym, c = c, p = p, i = i, j = j , n = side, coeff = 1)
                        self.encode_non_overlap_right(solver = solver,  colors_sym = colors_sym, c = c, p = p, i = i, j = j , n = side, coeff = 1)
    

        # cardinality constraints
        #\sum x_{i,j}^k \leq 5, k \in \{0,1\}
        if (len(self.args.card_min) == 0):
            rhs_min_all = [4, 2, 1]
        else: 
            rhs_min_all = self.args.card_min

        if (len(self.args.card_max) == 0):
            rhs_max_all = [4, 300, 300]
        else: 
            rhs_max_all = self.args.card_max
        
        for c in  colors:
            colors_ids = []
            colors_coeff = []
            for i in range(side):
                for j in range(side):                    
                    colors_ids.append(colors_sym[c][i][j])
                    colors_coeff.append(1)
    
            rhs_min = [rhs_min_all[c]]
            rhs_max = [rhs_max_all[c]]
            con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_cardinality_of_color_" +str(c) +"_" + str(i*side+j)
            print( [[colors_ids, colors_coeff]], rhs, [con_prefix])
            solver.s.linear_constraints.add(rhs = rhs_max,
                                     senses = ['L'],
                                     lin_expr = [[colors_ids, colors_coeff]],
                                     names = [con_prefix])
 
            solver.s.linear_constraints.add(rhs = rhs_min,
                                     senses = ['G'],
                                     lin_expr = [[colors_ids, colors_coeff]],
                                     names = [con_prefix])        #exit()
            
             


        #set output     
        k = self.bnnenc.layers[-1].next_lin_id
        o_id  = create_indexed_variable_name(NEURON_VAR_ID,[k, 0])
        o_rhs_min = [self.args.gen_output_min]
        o_rhs_max = [self.args.gen_output_max]
        solver.s.linear_constraints.add(rhs = o_rhs_min,
                                    senses = ['G'],
                                   lin_expr = [[[o_id], [1]]],
                                    names = ["force"])
        solver.s.linear_constraints.add(rhs = o_rhs_max,
                                    senses = ['L'],
                                   lin_expr = [[[o_id], [1]]],
                                    names = ["force"]) 
                  
        #connect with inputs        
        for i in range(side):
            for j in range(side):                                    
                for c in  colors:
                    indicator_id = colors_sym[c][i][j]                    
                    if (c < colors[-1]):
                        rhs = 0
                    else:
                        rhs = 1     
                    con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "connect_to_inputs" + str(c) + "_" + str(i*side+j)                    
                    y_id = create_indexed_variable_name(NEURON_VAR_ID,[0, i*side + j])
                    solver.s.indicator_constraints.add(indvar = indicator_id,
                                           complemented = 0,
                                           rhs = rhs,
                                           sense = "E",
                                           lin_expr = [[y_id], [1]],
                                           name = con_prefix)    
             
        solver.s.write("example3.lp")
        solver.s.solve()
        sol_vars_value = solver.s.solution.get_values()
        sol_vars_names = solver.s.variables.get_names()
        ilp_assignments = {}
        for i in range(len(sol_vars_value)): 
            ilp_assignments[sol_vars_names[i]] = sol_vars_value[i]
            #print(sol_vars_names[i],  sol_vars_value[i])
        
        
        y_output = [[-1 for j in range(side)] for i in range(side)] 
        image = [[-1 for j in range(side)] for i in range(side)] 

        for c in  colors:
            for i in range(side):
                for j in range(side):                    
                    pixel_val = ilp_assignments[colors_sym[c][i][j]]
                    if (pixel_val > 0):
                        assert(y_output[i][j] == -1)
                        if (c < 2):
                            y_output[i][j] = -1
                            image[i][j] = 0
                        if (c == 2):
                            y_output[i][j] = 1
                            image[i][j] =256

        for i in range(side):
            for j in range(side):     
                print(str(image[i][j]).rjust(4), end = " ")
            print("")   
        
        #file_name = "image_centeri_{}_centerj_{}_bounds_{}_{}_o_{}_seed_{}".format(colors_c_i, colors_c_j, o_rhs_min, o_rhs_max, ilp_assignments[o_id], self.args.seed)
        file_name = "image_o_{}_seed_{}_ci_{}_cj_{}_d_{}_card_min_{}_card_max_{}".format(int(ilp_assignments[o_id]), self.args.seed, colors_c_i, colors_c_j, self.args.prev_circle, self.args.card_min,self.args.card_max)
        file_name =file_name.replace("[","")
        file_name =file_name.replace("]","")
        file_name =file_name.replace(", ","_")
        dir = self.args.saveimages + "/" + str(self.args.gen_output_min) + "/"
        createdir(dir)
        scipy.misc.toimage(image, cmin=0.0, cmax=256).save( dir + file_name+'_card.png')
        
        
        
        y_vec = np.reshape(y_output, (side*side))

        forward_assignments, winner = self.bnnenc.forward(y_vec)
        print("winner {}".format(winner))
        return                 
            
            #     for i in range(1, len(model)):
            #         var_with_pol = model[i]
            #         var_cnf_id = abs(var_with_pol)
            #         var_id = getkey_by_value(var2cnf, var_cnf_id)
            #         if (var_id in forward_assignments):
            #             print("getting [{}]  {} ".format(var_cnf_id, var_id))
            #             if (var_with_pol < 0):
            #                 sat_assignments[var_id] =0
            #             else:
            #                 sat_assignments[var_id] =1
            #         else:
            #             print("scip [{}]  {} ".format(var_cnf_id, var_id))
        
        # ################################
        # # Evaluate outputs
        # ################################
        # z = input
        # for layer in layers[:-1]:
        #     z = layer.dot(z)
        #     # print("output {}".format(z))
        #     z = np.sign(z)
        #     z[z == 0] = 1
        #     # print("bin output {}".format(z))
        # # laste layer -- no sign
        # z = layers[-1].dot(z)
        # print("Computed forward path --  output {}".format(z))
        # 
        # #########################
        # # Assume that teh following relattion between Booelan variables and -1/1 variables
        # # TODO explain this  
        # # b_i = 1  iff z_i =1  
        # # b_i = 0  iff z_i =-1  
        # #########################
        # 
        # temp_file = args.cnfdest + FILE_TEMP_EXTENTION;
        # cnf_file = open(temp_file, 'w')
        # 
        # x = input    
        # ls = len(layers)
        # varids2values = {}
        # varids2cnf_varids = {}
        # 
        # nb_constraints = 0;
        # 
        # constraints = {} 
        # o = []
        # for k in range(0, ls):
        #     layer = layers[k]
        #     rows = layer.shape[0]
        #     cols = layer.shape[1]
        #     
        #     
        #     y = layer.dot(x)
        #     z = np.sign(y)
        #     z[z == 0] = 1
        # 
        #     
        #     local_y = np.empty((0), int)
        #     local_z = np.empty((0), int)
        #     for i in range(0, rows):
        #         full_ineq = ''
        #         simplified_ineq = ''
        #         
        #         full_sum = 0
        #         simplified_sum = 0
        #         
        #         coeffs = []
        #         vars_ids = []
        #         constterm = 0
        #         
        #         for j in range(0, cols):
        #             # a[k,i,j] = 1 NXOR y[k,j] = 1 <=>  b[k,i,j] =1
        # 
        #             ############ form xnor constraint #################             
        #             # form coeff id
        #             a_id = ("{}_{}{}{}".format(LAYER_VAR_ID, k, i, j))
        #             get_cnf_varid(varids2cnf_varids, a_id)
        # 
        #             # form neuron id
        #             x_id = ("{}_{}{}".format(NEURON_VAR_ID, k, j))
        #             get_cnf_varid(varids2cnf_varids, x_id)
        # 
        #             # form output neuron id
        #             z_id = ("{}_{}{}".format(NEURON_VAR_ID, k + 1, i))
        #             get_cnf_varid(varids2cnf_varids, z_id)
        # 
        #             # form mult extar var id
        #             b_id = ("{}_{}{}{}".format(MULT_VAR_ID, k, i, j))
        #             get_cnf_varid(varids2cnf_varids, b_id)
        #             
        #             # store unary constraints for coeff
        #             constraints[form_unary_constraint_name(a_id)] = [a_id, 1  if layer[i][j] >= 0 else 0]     
        #             if (k == 0):
        #                 if form_unary_constraint_name(x_id) not in constraints.keys():
        #                     # store unary constraints for inputs    
        #                     constraints[form_unary_constraint_name(x_id)] = [x_id, 1  if input[j] >= 0 else 0] 
        #                    
        #             # store NXOR constraint 
        #             constraints[form_nxor_constraint_name(k, i, j)] = [a_id, x_id, b_id]
        #             
        #             
        #             # [4DEBUG] evalutae nxor 
        #             varids2values[a_id] = 1  if layer[i][j] >= 0 else 0
        #             varids2values[x_id] = 1  if x[j] >= 0 else 0       
        #             varids2values[b_id] = bool(varids2values[a_id]) == bool(varids2values[x_id])                       
        # 
        # 
        #             ############### form linear constraint ################
        #             coeffs = np.append(coeffs, 2)
        #             vars_ids = np.append(vars_ids, b_id)
        #             constterm = constterm - 1      
        #             
        #             # [4DEBUG] computing linear constraint .... 
        #             full_sum = full_sum + 2 * varids2values[b_id] - 1
        #             
        #         if (bool(full_sum >= 0) != bool(z[i] == 1)):
        #             print(" The following constraint is incorrect " + full_ineq)
        #             exit()
        #             
        #         # [4DEBUG] check sums    
        #         local_y = np.append(local_y, full_sum)      
        #         
        #         
        #         if (k < ls - 1):            
        #             # add reified constraint
        #             constraints[form_linear_reified_constraint_name(k, i)] = [coeffs, vars_ids, z_id, constterm]
        #             if (bool(simplified_sum + constterm >= 0) != bool(z[i] == 1)):
        #                 print(" The following constraint is incorrect ")
        #                 print_linear_reified_constraint(constraints[form_linear_reified_constraint_name(k, i)])
        #                 exit()
        #             temp = 1 if full_sum >= 0  else -1    
        #             local_z = np.append(local_z, temp)      
        #         else:    
        #             # collect linear constraint to build partial ordering of outputs
        #             constraints[form_linear_constraint_name(k, i)] = [coeffs, vars_ids, constterm]
        # 
        #     if (np.array_equal(local_y, y) != True):
        #         print("invalid forward simulation ", local_y, y)
        #         exit()   
        #     if (k < ls - 1):
        #         if (np.array_equal(local_z, z) != True):
        #             print("invalid forward simulation ", local_z, z)
        #             exit()
        #     else:
        #         # introduce order variables
        #         # o[i] == 1 iff y[label] >= y[i]
        #         # o[i] == 1 iff y[label] - y[i] >=0               
        #         for i in range(0, rows):
        #             if(i == true_label):
        #                 continue            
        #             coeff_new = constraints[form_linear_constraint_name(k, true_label)][0]
        #             vars_ids_new = constraints[form_linear_constraint_name(k, true_label)][1]
        #             constterm_new = constraints[form_linear_constraint_name(k, true_label)][2]
        # 
        #             coeff_other = -1 * constraints[form_linear_constraint_name(k, i)][0]
        #             vars_ids_other = constraints[form_linear_constraint_name(k, i)][1]
        #             constterm_other = -1 * constraints[form_linear_constraint_name(k, i)][2]            
        #     
        #             coeff_new = np.append(coeff_new, coeff_other)  
        #             vars_ids_new = np.append(vars_ids_new, vars_ids_other)
        #             constterm_new = constterm_new + constterm_other
        #             
        #             
        #             o_id = ("{}_{}".format(ORDER_VAR_ID, i))
        #             o = np.append(o, o_id)
        #             get_cnf_varid(varids2cnf_varids, o_id)            
        #             constraints[form_linear_reified_constraint_name(k, i)] = [coeff_new, vars_ids_new, o_id, constterm_new]
        # #             
        #             varids2values[o_id] = 1  if local_y[true_label] >= local_y[i] else 0
        #         
        #     x = z;
        #     
        # print("\n\nModel:")
        # for keys, values in sorted(constraints.items()):
        #     if (keys[:4] == UNARY_CON_ID): 
        #         unary_constraint4bool_var(cnf_file, varids2cnf_varids, values)            
        #         print_unary_constraint(values)
        #     if (keys[:4] == NXOR_CON_ID): 
        #         nxor_input_reified(cnf_file, varids2cnf_varids, values)            
        #         print_nxor_constraint(values)
        #     if (keys[:4] == LIN_REIFIED_CON_ID):
        #         # we divide all coffs and the rhs by 2   as we know that all coeef are equal to 2     
        #         values[0] = [x / 2 for x in values[0]]  
        #         values[3] = math.floor(values[3] / 2)      
        #         # print_linear_reified_constraint(values)
        #         # we transform constraint 
        #         seqcounters4unary_coeff_linear_reified(cnf_file, varids2cnf_varids, coeffs=values[0], vars_ids=values[1], output_var_id=values[2], constterm=values[3])
        #     # if (keys[:4] == LIN_CON_ID):
        #     #    print_linear_constraint_name(values)        
        # 
        # # ensure that the winner belongs to the true class
        # for o_id in o:
        #     add_clause(cnf_file, varids2cnf_varids, [o_id])
        #         
        # cnf_file.close()
        # 
        # add_first_line2cnf(temp_file, args.cnfdest, len(varids2cnf_varids))
        # 
        # 
        # exit()

             
        #build neurons map
  
      #                 print("We consider this file as it is classified correctly")
    #                 print("inputs to the layer ", y_input)
    #                 # assumption generator
    #                 assum_mapping_global_asm_to_local = {}
    #                 assum_var2cnf = {}
    #                 for a_id in self.bnnenc.learnable_parameters:
    #                     get_cnf_varid(assum_var2cnf, a_id)
    #                     assum_mapping_global_asm_to_local[var2cnf[a_id]] = get_cnf_varid(assum_var2cnf, a_id)
    #                 # start with a random assignmnet of a
    #                 assump = {}
    #                 counter = 0
    #                 for a_id in self.bnnenc.learnable_parameters:
    #                     if (counter < 11):
    #                         assump[a_id] = 0 #np.random.choice(a=[0, 1], size=(1))[0]
    #                     else:
    #                         assump[a_id] = 1 #np.random.choice(a=[0, 1], size=(1))[0]
    #                     counter +=1 
    #                 #print(a)
    #                 blocking_clause = []
    #                 while(True):
    #                     #reset assumptions
    #                     solver.assumptions = []                
    #                     o_dummy = []
    #                     #print("assumptions", assump)
    #                     #reset constraint
    #                     for keys, values in sorted(constraints.items()):               
    #                         if (ASSUMPTION_CON_ID in keys): 
    #                             a_id = values[0]
    #                             #print(keys, values, a_id)                            
    #                             #print(constraints[keys])
    #                             constraints[keys] = [a_id,  assump[a_id]]
    #                             #solver.assumptions.append(var2cnf[a_id] if assump[a_id] > 0 else -var2cnf[a_id])
    #                             #print(constraints[keys])            
    #  
    #                         if (LIN_REIFIED_CON_ID  in keys):
    #                             #print_constraint(keys, values)
    #                             [coeffs, vars_ids,  z_id, constterm] = constraints[keys]
    #                             s = 0
    #                             for i in range(len(vars_ids)):
    #                                 coef  = coeffs[i]
    #                                  
    #                                 id = vars_ids[i].replace('[','_').replace(']','_')
    #                                 id  = id.split('_')
    #                                 k1 = id[2]
    #                                 i1 = id[4]
    #                                 j1 = id[6]
    #                                 t_y_id = create_indexed_variable_name(NEURON_VAR_ID, [k1, j1])
    #                                 t_a_id = create_indexed_variable_name(LAYER_VAR_ID, [k1, i1, j1])
    #                                                                  
    #                                 #print(t_a_id, assump[t_a_id])
    #                                 #print(t_y_id, forward_assignments[t_y_id]) 
    #                                 q  = (2*assump[t_a_id]-1)*(2*forward_assignments[t_y_id]-1)
    #                                 s = s + coef*q
    #                                 #print(s, coef, q)
    #                             s = s + constterm
    #                             o_dummy.append(s)
    #  
    #                     print('o_dummy', o_dummy)
    #                     #print(var2cnf)
    #                     #print(solver.assumptions)
    #                      
    #                      
    #                     #print("Network winner {}  vs  True winner {}".format(int(o_dummy[0] > o_dummy[1]), true_label))
    #                     solver = MinisatSolverExt(var2cnf = var2cnf, nb_sat_vars = len(var2cnf))
    #                     #print("Create solver, # high-level constraints ({})".format(len(constraints)))      
    #                     solver.populate_solver(copy.deepcopy(constraints))   
    #                     #print("Run solver")            
    #                     sat_result, model, purecore = solver.solve_limited()        
    #                     #print_constraints(constraints)
    #                     #sat_result, model, purecore = solver.solve_limited()        
    #                     if (sat_result == SOLVER_SAT_RESULT):
    #                         print("SAT")
    #                         if (true_label == 0):
    #                             assert(o_dummy[0] > o_dummy[1])
    #                         if (true_label == 1):
    #                             assert(o_dummy[1] > o_dummy[0])
    #                             
    #                         break
    #                          
    #                     if (sat_result == SOLVER_UNSAT_RESULT):
    #                         print('wrong guess')
    #                         #form blcokign clause
    #                         clause = []
    #                         #print("purecore", purecore)
    #                         for a in purecore:
    #                             clause.append(assum_mapping_global_asm_to_local[abs(a)] if a < 0 else -assum_mapping_global_asm_to_local[abs(a)])
    #                         #print(clause)
    #                         blocking_clause.append(clause)
    #  
    #  
    #                         # create assumption solver
    #                         assumption_solver = MinisatSolverExt(var2cnf = assum_var2cnf, nb_sat_vars = len(assum_var2cnf))
    #                         for clause in blocking_clause:
    #                             assumption_solver.s.add_clause(clause)
    #                             print(clause)
    #  
    #                          
    #                         # call assumption solver generator
    #                         print('call assumption solver generator')
    #                         assumption_sat_result,  assumption_model,  assumption_purecore = assumption_solver.solve_limited()
    #                         for assum_id in assum_var2cnf:
    #                             assump[assum_id] = get_sat_value_by_id(assum_id, assum_var2cnf, assumption_model)  
    #                             print(assum_id, assump[assum_id],  end='  ')
    #                         print("<<")
    #                         print(assumption_model)
    #  
    #                         #exit()
    #                                 
    #                     
                   
                   
        # inside grain
#         #x_{i,j}^k \Rightarrow (x_{i,j+1}^k + x_{i,j-1}^k + x_{i+1,j}^k + x_{i-1,j}^k >= 1)
#         for c in  colors:
#             for i in range(side):
#                 for j in range(side):                    
#                     indicator_id = colors_sym[c][i][j]
#                     neighbour_ids = []
#                     neighbour_coeff = []
#                     
#                     if i > 0: # up
#                         neighbour_ids.append(colors_sym[c][i-1][j])
#                         neighbour_coeff.append(1)
#                     if i <  side - 1: # down
#                         neighbour_ids.append(colors_sym[c][i+1][j])
#                         neighbour_coeff.append(1)
# 
#                     if j > 0: # left
#                         neighbour_ids.append(colors_sym[c][i][j-1])
#                         neighbour_coeff.append(1)
#                     
#                     if j < side - 1: # right
#                         neighbour_ids.append(colors_sym[c][i][j+1])
#                         neighbour_coeff.append(1)
#                     
#                     rhs = 1
#                     con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_inter_grain_" + str(i*side+j)
#                     #print( [[neighbour_ids, neighbour_coeff]], rhs, [con_prefix])
#                     
#                     solver.s.indicator_constraints.add(indvar = indicator_id,
#                                        complemented = 0,
#                                        rhs = rhs,
#                                        sense = "G",
#                                        lin_expr = [neighbour_ids, neighbour_coeff],
#                                        name = con_prefix)    
                   
#         #\sum x_{i,j}^k \geq 1, k \in \{0,1\} 
#         for c in  colors:
#             colors_ids = []
#             colors_coeff = []
#             for i in range(side):
#                 for j in range(side):                    
#                     colors_ids.append(colors_sym[c][i][j])
#                     colors_coeff.append(1)
#   
#             rhs = [1]
#             con_prefix = str(CONSTRAINT_TEMP_VAR_PREFIX) + "_existence_of_color_" +str(c) +"_" + str(i*side+j)
#             #print( [[colors_ids, colors_coeff]], rhs, [con_prefix])
#             solver.s.linear_constraints.add(rhs = rhs,
#                                     senses = ['G'],
#                                     lin_expr = [[colors_ids, colors_coeff]],
#                                     names = [con_prefix])

                   