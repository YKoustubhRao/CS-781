#!/usr/bin/env python
#-*- coding:utf-8 -*-
##
## explain.py
##
##  Created on: Aug 1, 2018
##      Author: Alexey S. Ignatiev
##      E-mail: aignatiev@ciencias.ulisboa.pt
##

#
#==============================================================================
from __future__ import print_function
import cplex
import getopt
import math
import matplotlib.image as mpimg
import matplotlib.cm as mpcm
import numpy as np
import os
from pysat.examples.hitman import Hitman
# from hitman import HitMinimum
from pysmt.smtlib.parser import SmtLibParser
from pysmt.shortcuts import Solver
from pysmt.shortcuts import And, BOOL, Implies, Not, Or, Symbol
from pysmt.shortcuts import Equals, GT, Int, Real
import resource
from six.moves import range
import sys

try:  # for Python2
    from cStringIO import StringIO
except ImportError:  # for Python3
    from io import StringIO


#
#==============================================================================
def parse_smt2file(fname):
    """
        Get SMT2 formula as well as inputs and outputs of the network.
    """

    with open(fname, 'r') as fp:
        file_content = fp.readlines()

    data = []

    for line in file_content:
        if line[0] != ';':
            break
        elif line.startswith('; data:'):
            data.append(line[7:].strip())
        elif line.startswith('; inputs:'):
            inputs = line[10:].strip().split(', ')
        elif line.startswith('; outputs:'):
            outputs = line[11:].strip().split(', ')

    parser = SmtLibParser()
    script = parser.get_script(StringIO(''.join(file_content)))

    formula = script.get_last_formula()
    allvars = formula.get_free_variables()

    # set of input variable names and their ids
    seti = set(inputs)
    ivid = {v: i for i, v in enumerate(inputs)}

    # set of output variable names and their ids
    seto = set(outputs)
    ovid = {v: i for i, v in enumerate(outputs)}

    ivs = []
    ovs = []
    for v in allvars:
        if v.symbol_name() in seto:
            ovs.append(v)
        elif v.symbol_name() in seti:
            ivs.append(v)

    # returning formula, input and output variables as objects of PySMT
    return formula, sorted(ivs, key=lambda v: ivid[v.symbol_name()]), \
            sorted(ovs, key=lambda v: ovid[v.symbol_name()]), data


#
#==============================================================================
def parse_lpfile(fname):
    """
        Parse LP file and extract LP constraints as well as variable names and
        the original dataset.
    """

    with open(fname, 'r') as fp:
        file_content = fp.readlines()

    data = []

    for line in file_content:
        if line[0] != '\\':
            break
        elif line.startswith('\\ data:'):
            data.append(line[7:].strip())
        elif line.startswith('\\ inputs:'):
            inputs = line[10:].strip().split(', ')
        elif line.startswith('\\ outputs:'):
            outputs = line[11:].strip().split(', ')

    ilp = cplex.Cplex()
    ilp.read(fname)

    return ilp, inputs, outputs, data


#
#==============================================================================
class SMTExplainer(object):
    """
        An SMT-inspired minimal explanation extractor for neural networks
        based on ReLUs.
    """

    def __init__(self, formula, inputs, outputs, names, solver, verbose=0):
        """
            Constructor.
        """

        self.verbose = verbose
        self.oracle = Solver(name=solver)

        # theory
        self.oracle.add_assertion(formula)

        # feature and class names (for verbosity)
        self.fnames = {}
        self.values = {}
        self.inputs = inputs

        # relaxed hypotheses
        self.rhypos = []

        for i, inp in enumerate(inputs, 1):
            selv = Symbol('selv_f{0}'.format(i))

            hypo = Implies(selv, Equals(inp[0], Real(inp[1])))
            self.oracle.add_assertion(hypo)

            self.rhypos.append(selv)
            self.fnames[selv] = names[i - 1]
            self.values[selv] = inp[1]

        # getting the true observation
        # (not the expected one as specified in the dataset)
        if self.oracle.solve(self.rhypos):
            model = self.oracle.get_model()
        else:
            assert 0, 'Formula is unsatisfiable under given assumptions'

        # choosing the maximum
        outvals = [float(model.get_py_value(o)) for o in outputs]
        maxoval = max(zip(outvals, range(len(outvals))))

        # correct class id (corresponds to the maximum computed)
        true_output = maxoval[1]
        self.output = '{0} = {1}'.format(names[-1], true_output)

        # observation
        # (forcing it to be wrong)
        disj = []
        for i in range(len(outputs)):
            if i != true_output:
                disj.append(GT(outputs[i], outputs[true_output]))
        self.oracle.add_assertion(Or(disj))

        if self.verbose:
            print('  explaining:  "IF {0} THEN {1}"'.format(' AND '.join(['{0} = {1}'.format(f, v[1]) for f, v in zip(names[:-1], inputs)]), self.output))

    def explain(self, smallest):
        """
            Hypotheses minimization.
        """

        self.time = resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime + \
                resource.getrusage(resource.RUSAGE_SELF).ru_utime

        # if satisfiable, then the observation is not implied by the hypotheses
        if self.oracle.solve(self.rhypos):
            print('  no implication!')
            print(self.oracle.get_model())
            sys.exit(1)

        if not smallest:
            self.compute_minimal()
        else:
            self.compute_smallest()

        if self.verbose:
            print('  explanation: "IF {0} THEN {1}"'.format(' AND '.join(['{0} = {1}'.format(self.fnames[v], self.values[v]) for v in self.rhypos]), self.output))

        print('  # hypos left:', len(self.rhypos))

        self.time = resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime + \
                resource.getrusage(resource.RUSAGE_SELF).ru_utime - self.time
        print('  time: {0:.2f}'.format(self.time))

    def compute_minimal(self):
        """
            Compute any subset-minimal explanation.
        """

        i = 0

        # simple deletion-based linear search
        while i < len(self.rhypos):
            to_test = self.rhypos[:i] + self.rhypos[(i + 1):]

            if self.oracle.solve(to_test):
                i += 1
            else:
                self.rhypos = to_test

    def compute_smallest(self):
        """
            Compute a cardinality-minimal explanation.
        """

        # result
        rhypos = []

        # with HitMinimum() as hitman:
        with Hitman(bootstrap_with=[list(range(len(self.rhypos)))]) as hitman:
            # computing unit-size MCSes
            for i, hypo in enumerate(self.rhypos):
                if self.oracle.solve(self.rhypos[:i] + self.rhypos[(i + 1):]):
                    hitman.hit([i])

            # main loop
            iters = 0
            while True:
                hset = hitman.get()
                iters += 1

                if self.verbose > 1:
                    print('iter:', iters)
                    print('cand:', hset)

                if self.oracle.solve([self.rhypos[i] for i in hset]):
                    to_hit = []
                    satisfied, unsatisfied = [], []

                    removed = list(set(range(len(self.rhypos))).difference(set(hset)))

                    model = self.oracle.get_model()
                    for h in removed:
                        # feature variable and its expected value
                        var, exp = self.inputs[h]

                        # true value
                        true_val = float(model.get_py_value(var))

                        if not exp - 0.001 <= true_val <= exp + 0.001:
                            unsatisfied.append(h)
                        else:
                            hset.append(h)

                    # computing an MCS (expensive)
                    for h in unsatisfied:
                        if self.oracle.solve([self.rhypos[i] for i in hset] + [self.rhypos[h]]):
                            hset.append(h)
                        else:
                            to_hit.append(h)

                    if self.verbose > 1:
                        print('coex:', to_hit)

                    hitman.hit(to_hit)
                else:
                    self.rhypos = [self.rhypos[i] for i in hset]
                    break

#
#==============================================================================
class ILPExplainer(object):
    """
        An ILP-inspired minimal explanation extractor for neural networks
        based on ReLUs.
    """

    def __init__(self, oracle, inputs, outputs, names, verbose=0):
        """
            Constructor.
        """

        self.verbose = verbose
        self.oracle = oracle

        # turning logger off
        self.oracle.set_log_stream(None)
        self.oracle.set_error_stream(None)
        self.oracle.set_results_stream(None)
        self.oracle.set_warning_stream(None)

        # feature and class names (for verbosity)
        self.fnames = names

        # hypotheses
        self.hypos = []

        # adding indicators for correct and wrong outputs
        self.oracle.variables.add(names=['c_{0}'.format(i) for i in range(len(outputs))], types='B' * len(outputs))
        for i in range(len(outputs)):
            ivar = 'c_{0}'.format(i)
            wrong = ['wc_{0}_{1}'.format(i, j) for j in range(len(outputs)) if i != j]
            self.oracle.variables.add(names=wrong, types='B' * len(wrong))

            # ivar implies at least one wrong class
            self.oracle.indicator_constraints.add(indvar=ivar, lin_expr=[wrong,
                [1] * len(wrong)], sense='G', rhs=1)

            for j in range(len(outputs)):
                if i != j:
                    # iv => (o_j - o_i >= 0.0000001)

                    iv = 'wc_{0}_{1}'.format(i, j)
                    ov, oc = [outputs[j], outputs[i]], [1, -1]
                    self.oracle.indicator_constraints.add(indvar=iv,
                            lin_expr=[ov, oc], sense='G', rhs=0.0000001)

        # linear constraints activating a specific class
        # will be added for each sample individually
        # e.g. self.oracle.linear_constraints.add(lin_expr=[['c_0'], [1]], senses=['G'], rhs=[1])

    def add_sample(self, sample):
        """
            Add constraints for a concrete data sample.
        """

        self.values = sample

        self.hypos = []
        for i, v in enumerate(inputs, 1):
            eql = [[v], [1.0]]
            rhs = [float(sample[i - 1])]

            cnames = ['hypo_{0}'.format(i)]
            senses = ['E']
            constr = [eql]

            assump = self.oracle.linear_constraints.add(lin_expr=constr,
                    senses=senses, rhs=rhs, names=cnames)

            # adding a constraint to the list of hypotheses
            self.hypos.append(tuple([cnames[0], constr, rhs, senses, i - 1]))

        # getting the true observation
        # (not the expected one as specified in the dataset)
        self.oracle.solve()
        if self.oracle.solution.is_primal_feasible():
            model = self.oracle.solution
        else:
            assert 0, 'Formula is unsatisfiable under given assumptions'

        # choosing the maximum
        outvals = [float(model.get_values(o)) for o in outputs]
        maxoval = max(zip(outvals, range(len(outvals))))

        # correct class id (corresponds to the maximum computed)
        true_output = maxoval[1]
        self.output = '{0} = {1}'.format(names[-1], true_output)

        # observation (forcing it to be wrong)
        self.oracle.linear_constraints.add(lin_expr=[[['c_{0}'.format(true_output)], [1]]],
                senses='E', rhs=[1], names=['forced_output'])

        if self.verbose:
            print('  explaining:  "IF {0} THEN {1}"'.format(' AND '.join(['{0} = {1}'.format(f, v) for f, v in zip(names[:-1], self.values)]), self.output))

    def explain(self, sample, index, smallest, traverse='simple'):
        """
            Hypotheses minimization.
        """

        self.time = resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime + \
                resource.getrusage(resource.RUSAGE_SELF).ru_utime

        # add constraints corresponding to the current sample
        self.add_sample(sample)

        # if satisfiable, then the observation is not implied by the hypotheses
        self.oracle.solve()
        if self.oracle.solution.is_primal_feasible():
            print('  no implication!')
            sys.exit(1)

        if index:  # working with MNIST images
            sz = int(math.sqrt(len(sample)))
            assert len(sample) == sz ** 2, 'data seems to be not a square image'

            vmin, vmax = min(sample), max(sample)
            sample = list(map(lambda v: int((v - vmin) * 255 / (vmax - vmin)), sample))

            self.sort_sample(sample, sz, traverse)

        if not smallest:
            rhypos = self.compute_minimal()
        else:  # get a smallest explanation
            rhypos = self.compute_smallest()

        if self.verbose:
            print('  explanation: "IF {0} THEN {1}"'.format(' AND '.join(['{0} = {1}'.format(self.fnames[h[0]], self.values[h[0]]) for h in rhypos]), self.output))

        if index:
            self.save_image(sample, sz, index, set([h[0] for h in rhypos]), traverse)

        expl_sz = len(rhypos)
        print('  # hypos left:', expl_sz)

        # removing hypotheses related to the current sample
        for hypo in rhypos:
            self.oracle.linear_constraints.delete(hypo[1])

        # removing the output forced to be wrong
        self.oracle.linear_constraints.delete('forced_output')

        self.time = resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime + \
                resource.getrusage(resource.RUSAGE_SELF).ru_utime - self.time

        print('  time: {0:.2f}'.format(self.time))

        return expl_sz

    def sort_sample(self, sample, sz, way):
        """
            This procedure defines the order in which the features/pixels will
            be traversed.
        """

        if way in ('light', 'l'):
            # sorting pixels based on the darkness
            # (dark pixels are removed first)
            self.hypos.sort(key=lambda h: sample[h[4]])
        elif way in ('center', 'c'):
            # sorting pixels based on the distance from the center
            # distant pixels are removed first
            sz = int(math.sqrt(len(sample)))
            assert len(sample) == sz ** 2, 'data seems to be not a square image'

            # coordinates of the center
            c = (sz / 2 - 1, sz / 2 - 1)

            # maximal distance
            r = 2 * float((sz / 2) ** 2)

            self.hypos.sort(key=lambda h: r - ((h[4] / sz - c[0]) ** 2 + (h[4] % sz - c[1]) ** 2))
        elif way in ('lc', 'cl'):
            # sorting based on both criteria combined
            sz = int(math.sqrt(len(sample)))
            assert len(sample) == sz ** 2, 'data seems to be not a square image'

            # coordinates of the center
            c = (sz / 2 - 1, sz / 2 - 1)

            # maximal radius
            r = 2 * float((sz / 2) ** 2)

            if way == 'lc':
                self.hypos.sort(key=lambda h: (sample[h[4]] + 1) * r + (r - (h[4] / sz - c[0]) ** 2 + (h[4] % sz - c[1]) ** 2))
            else:  # 'cl'
                self.hypos.sort(key=lambda h: sample[h[4]] + 256 * (1 + r - (h[4] / sz - c[0]) ** 2 + (h[4] % sz - c[1]) ** 2))
        else:  # do nothing in case of 'simple' traverse
            pass

    def compute_minimal(self):
        """
            Compute any subset-minimal explanation.
        """

        # result
        rhypos = []

        # simple deletion-based linear search
        for hypo in self.hypos:
            self.oracle.linear_constraints.delete(hypo[0])

            self.oracle.solve()
            if self.oracle.solution.is_primal_feasible():
                # this hypothesis is needed
                # adding it back to the list
                self.oracle.linear_constraints.add(lin_expr=hypo[1],
                        senses=hypo[3], rhs=hypo[2], names=[hypo[0]])

                rhypos.append(tuple([hypo[4], hypo[0]]))

        return rhypos

    def compute_smallest(self):
        """
            Compute a cardinality-minimal explanation.
        """

        # result
        rhypos = []

        # with HitMinimum() as hitman:
        with Hitman(bootstrap_with=[list(range(len(self.hypos)))]) as hitman:
            # computing unit-size MCSes
            for i, hypo in enumerate(self.hypos):
                self.oracle.linear_constraints.delete(hypo[0])

                self.oracle.solve()
                if self.oracle.solution.is_primal_feasible():
                    hitman.hit([i])

                self.oracle.linear_constraints.add(lin_expr=hypo[1],
                        senses=hypo[3], rhs=hypo[2], names=[hypo[0]])

            # main loop
            iters = 0
            while True:
                hset = hitman.get()
                iters += 1

                to_remove = set(range(len(self.hypos))).difference(set(hset))
                for i in to_remove:
                    self.oracle.linear_constraints.delete(self.hypos[i][0])

                if self.verbose > 1:
                    print('iter:', iters)
                    print('cand:', hset)

                self.oracle.solve()
                if self.oracle.solution.is_primal_feasible():
                    to_hit = []
                    satisfied, unsatisfied = [], []

                    model = self.oracle.solution
                    for h in to_remove:
                        # feature variable and its expected value
                        var, exp = self.hypos[h][1][0][0], self.hypos[h][2][0]

                        # true value
                        true_val = model.get_values(var)[0]
                        if exp - 0.001 <= true_val <= exp + 0.001:
                            satisfied.append(h)
                        else:
                            unsatisfied.append(h)

                    for i in satisfied:
                            hypo = self.hypos[i]
                            self.oracle.linear_constraints.add(lin_expr=hypo[1],
                                    senses=hypo[3], rhs=hypo[2], names=[hypo[0]])

                    # computing an MCS (expensive)
                    for i in unsatisfied:
                        hypo = self.hypos[i]
                        self.oracle.linear_constraints.add(lin_expr=hypo[1],
                                senses=hypo[3], rhs=hypo[2], names=[hypo[0]])

                        self.oracle.solve()
                        if not self.oracle.solution.is_primal_feasible():
                            self.oracle.linear_constraints.delete(hypo[0])
                            to_hit.append(i)

                    if self.verbose > 1:
                        print('coex:', to_hit)

                    hitman.hit(to_hit)

                    for i in to_hit:
                        hypo = self.hypos[i]
                        self.oracle.linear_constraints.add(lin_expr=hypo[1],
                                senses=hypo[3], rhs=hypo[2], names=[hypo[0]])
                else:
                    rhypos = list([tuple([h, self.hypos[h][0]]) for h in hset])
                    break

        return rhypos

    def save_image(self, sample, sz, index, expl, way):
        """
            Create an image file containing the resulting image with the
            explanation highlighted.
        """

        pixels = []  # this will contain an array of masked pixels
        for i in range(sz):
            row = []
            for j, v in enumerate(sample[(i * sz):(i + 1) * sz]):
                if i * sz + j in expl:
                    row.append(tuple([255 - v if abs(v - 127) > 20 else 255, v, v]))
                else:
                    row.append(tuple([v, v, v]))
            pixels.append(row)

        pixels = np.asarray(pixels, dtype=np.uint8)
        mpimg.imsave('sample-image{0}-{1}.svg'.format(index, way), pixels,
                cmap=mpcm.gray, dpi=5)

        # pixels = []  # this will contain an array of masked pixels
        # for i in range(sz):
        #     row = []
        #     for j, v in enumerate(sample[(i * sz):(i + 1) * sz]):
        #         row.append(tuple([v, v, v]))
        #     pixels.append(row)

        # pixels = np.asarray(pixels, dtype=np.uint8)
        # mpimg.imsave('sample-digit{0}-{1}.svg'.format(index, way), pixels,
        #         cmap=mpcm.gray, dpi=5)

        # pixels = []  # this will contain an array of masked pixels
        # for i in range(sz):
        #     row = []
        #     for j, v in enumerate(sample[(i * sz):(i + 1) * sz]):
        #         if i * sz + j in expl:
        #             row.append(tuple([255, 255, 255]))
        #         else:
        #             row.append(tuple([0, 0, 0]))
        #     pixels.append(row)

        # pixels = np.asarray(pixels, dtype=np.uint8)
        # mpimg.imsave('sample-expl{0}-{1}.svg'.format(index, way), pixels,
        #         cmap=mpcm.gray, dpi=5)


#
#==============================================================================
def parse_options():
    """
        Parses command-line options:
    """

    try:
        opts, args = getopt.getopt(sys.argv[1:],
                                   'a:hms:t:v',
                                   ['attempts=',
                                    'minsize',
                                    'solver=',
                                    'save',
                                    'traverse=',
                                    'help',
                                    'verb'])
    except getopt.GetoptError as err:
        sys.stderr.write(str(err).capitalize())
        usage()
        sys.exit(1)

    attempts = 1
    smallest = False
    solver = 'z3'
    save = False
    traverse = 'simple'
    verb = 0

    for opt, arg in opts:
        if opt in ('-a', '--attempts'):
            attempts = str(arg)
        elif opt in ('-h', '--help'):
            usage()
            sys.exit(0)
        elif opt in ('-m', '--minsize'):
            smallest = True
        elif opt in ('-s', '--solver'):
            solver = str(arg)
        elif opt == ('--save'):
            save = True
        elif opt in ('-t', '--traverse'):
            traverse = str(arg)
        elif opt in ('-v', '--verb'):
            verb += 1
        else:
            assert False, 'Unhandled option: {0} {1}'.format(opt, arg)

    return attempts, solver, save, smallest, traverse, verb, args


#
#==============================================================================
def usage():
    """
        Prints usage message.
    """

    print('Usage:', os.path.basename(sys.argv[0]), '[options] smt2-file')
    print('Options:')
    print('        -a, --attempts=<int>       Number of samples to explain')
    print('                                   Available values: [1 .. INT_MAX] (default: 1)')
    print('        -h, --help')
    print('        -m, --minsize              Compute a smallest size explanation')
    print('        -s, --solver=<string>      SMT solver to use')
    print('                                   Available values: cplex, cvc4, msat, z3, yices (default: z3)')
    print('        --save                     Save the resulting image')
    print('        -t, --traverse=<string>    Traverse pixels based on this preference')
    print('                                   Available values: center, combined, light, simple (default: simple)')
    print('        -v, --verb                 Be verbose')


#
#==============================================================================
if __name__ == '__main__':
    # parse command-line options
    attempts, solver, save, smallest, traverse, verb, files = parse_options()

    if files:
        if solver in ('cvc4', 'msat', 'z3', 'yices'):
            formula, inputs, outputs, data = parse_smt2file(files[0])

            # feature names
            names = data[0].split(',')

            # translating 'all' attempts to the correct number
            attempts = int(attempts) if attempts != 'all' else len(data) - 1

            xlen = []
            time = []
            for i in range(min(attempts, len(data) - 1)):
                print('sample {0}:'.format(i + 1))
                feats = [float(f) for f in data[i + 1].split(',')]

                x = SMTExplainer(formula, zip(inputs, feats), outputs, names,
                        solver, verb)

                x.explain(smallest)
                xlen.append(len(x.rhypos))
                time.append(x.time)

            print('\nxlen: {0} avg; {1} min; {2} max;'.format(sum(xlen) / float(len(xlen)),
                min(xlen), max(xlen)))

            print('\ntime: {0:.2f} avg; {1:.2f} min; {2:.2f} max;'.format(sum(time) / float(len(time)),
                min(time), max(time)))

        else:  # cplex
            ilp, inputs, outputs, data = parse_lpfile(files[0])

            # feature names
            names = data[0].split(',')

            # translating 'all' attempts to the correct number
            attempts = int(attempts) if attempts != 'all' else len(data) - 1

            # ILP-based explainer
            x = ILPExplainer(ilp, inputs, outputs, names, verb)

            xlen = []
            time = []
            for i in range(min(attempts, len(data) - 1)):
                print('sample {0}:'.format(i + 1))
                feats = [float(f) for f in data[i + 1].split(',')]

                xlen.append(x.explain(feats, i + 1 if save else 0, smallest, traverse))
                time.append(x.time)

            print('\nxlen: {0} avg; {1} min; {2} max;'.format(sum(xlen) / float(len(xlen)),
                min(xlen), max(xlen)))

            print('\ntime: {0:.2f} avg; {1:.2f} min; {2:.2f} max;'.format(sum(time) / float(len(time)),
                min(time), max(time)))
