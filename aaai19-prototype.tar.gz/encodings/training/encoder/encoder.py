import numpy as np
import torch
from base import BaseEncoder
from utils import *
from smt import *
from pysmt.shortcuts import Symbol, LE, GE, TRUE, Real, Bool, Int, And, Equals, Plus, Solver, Times, Equals, Implies, Not, is_sat, get_model, to_smtlib,write_smtlib
from pysmt.typing import INT, REAL, BOOL
from pysmt.shortcuts import Solver
from pysmt.logics import AUTO, QF_LRA
import cplex
from cplex.exceptions import CplexError
from ilp import *

class Encoder(BaseEncoder, object):
    """
    Trainer class

    Note:
        Inherited from BaseTrainer.
        self.optimizer is by default handled by BaseTrainer based on config.
    """
    def __init__(self, model, loss, metrics, resume, config,
                 data_loader, valid_data_loader=None, train_logger=None):
        super(Encoder, self).__init__(model, loss, metrics, resume, config, train_logger)
        self.config = config
        self.batch_size = data_loader.batch_size
        self.data_loader = data_loader
        self.valid_data_loader = valid_data_loader
        self.valid = True if self.valid_data_loader is not None else False
        self.log_step = int(np.sqrt(self.batch_size))

    def _to_tensor(self, data, target):
        data, target = torch.FloatTensor(data), torch.LongTensor(target)
        if self.with_cuda:
            data, target = data.to(self.gpu), target.to(self.gpu)
        return data, target


    def _smt_encode(self, smtfile):#, pick_sample_info = None):
        print("Starting SMT encoding of NN")
        #print(self.model)
        smt = SMTEncoding()

        max_input_value = np.max(self.data_loader.x, axis=0)
        min_input_value = np.min(self.data_loader.x, axis=0)


        if(self.config['data_loader']['quantize'] is True):
            # to CHANGE  pysmt.exceptions.PysmtTypeError: The formula '(x_0_0_ * -1524799/134217728)' is not well-formed

            input_type = TYPE_SMT_INT #TYPE_SMT_REAL ## should be INT?
            self.model.smt_encode(smt, input_type, min_input_value, max_input_value)
        else:
            max_input_value = np.max(self.data_loader.x, axis=0)+0.0001
            min_input_value = np.min(self.data_loader.x, axis=0)-0.0001
            input_type = TYPE_SMT_REAL

            self.model.smt_encode(smt, input_type, min_input_value, max_input_value)    
        #print(self.config['smt']['set_interval_domain'] )
        if(self.config['domains']['set_interval_domain'] is True):
            print("Encoding of interval domains")
            # encode domains
            inputs = smt.inputs
            #print(self.data_loader.x_values,  inputs)
            if (len(self.data_loader.x_values) == len(inputs)):
                for i, var in enumerate(inputs):
                    #print(var)
                    e = self.config['domains']['epsilon']
                    smt.add_set_intreval_domain(var, self.data_loader.x_values[i], e)


        print("Saving SMT encoding of NN to " + smtfile )
        write_smtlib(smt.formula, smtfile)
        self._verifier_smt(smt)


        return smt.formula, smt.inputs, smt.outputs

    def _ilp_encode(self, ilpfile):#, pick_sample_info = None):
        print("Starting ILP encoding of NN")
        #print(self.model)
        max_input_value = np.max(self.data_loader.x, axis=0)
        min_input_value = np.min(self.data_loader.x, axis=0)


        ilpsolver =  ILPSolver(ilpfile)
        
        if(self.config['data_loader']['quantize'] is True):
            self.model.ilp_encode(ilpsolver, 
                                  input_type = ilpsolver.solver.variables.type.integer,
                                  min_input_value = min_input_value, 
                                  max_input_value = max_input_value)     
        else:
            max_input_value = np.max(self.data_loader.x, axis=0)+0.0001
            min_input_value = np.min(self.data_loader.x, axis=0)-0.0001

            self.model.ilp_encode(ilpsolver, 
                                  input_type = ilpsolver.solver.variables.type.continuous,
                                  min_input_value = min_input_value, 
                                  max_input_value = max_input_value)     
        #print(self.config['smt']['set_interval_domain'] )
        if(self.config['domains']['set_interval_domain'] is True):

           
            # encode domains
            inputs = ilpsolver.inputs
            #print(self.data_loader.x_values,  inputs)
            if (len(self.data_loader.x_values) == len(inputs)):
                vars_sz = len(inputs)
                
                bd_names = ilpsolver.add_variables(label = SMT_LABELED_BIN_DOMAIN_VARS + str(0),
                                            ids = [0],
                                            obj = 0,
                                            lb = 0,
                                            ub = 1,
                                            type = ilpsolver.solver.variables.type.binary,
                                            sz = vars_sz)
                ilpsolver.store_ilp_var_info(self.model.ilp_vars_info, SMT_LABELED_BIN_DOMAIN_VARS + str(0), bd_names, BIN_DOMAIN_VARS_TAG)
                
                for i, var in enumerate(inputs):
                    #print(var)                   
                    binary_values = self.data_loader.x_values[i]                                    
                    if (len(binary_values) > 2):
                        print("We only support binary domain")
                        print("Current binary domain are \n" + str(binary_values))
                        exit()
            
                    
                    e = self.config['domains']['epsilon']                   
                    ilpsolver.add_set_intreval_domain(var, i, binary_values, e, bd_names[i])

        #################################
        self._verifier_ilp(ilpsolver)
        
        
        ################################
        # Fxiing inputs 
        ################################
#         if not (pick_sample_info is None):
#             for i, v in enumerate(ilpsolver.inputs):
#                 if i in pick_sample_info["free"]:
#                     #print("skipping x[", i,"]")
#                     continue             
#                 #else:
#                     #print("fixing x[", i, "] = ", pick_sample_info["x"][i])
#                 #print(i, v, pick_sample_info["x"][i] )
#                 constraint_names = ["pick_c1_"+str(i), "pick_c2_"+str(i)]
#                 first_constraint = [[v], [1.0]]
#                 second_constraint = [[v], [1.0]]
#                 rhs = [float(pick_sample_info["x"][i]), float(pick_sample_info["x"][i] )]
#                 constraint_senses = [ "G", "L" ]
#                 constraints = [ first_constraint, second_constraint ]
# 
#                 #print(first_constraint, second_constraint, rhs, constraint_senses)
#                 ilpsolver.solver.linear_constraints.add(lin_expr = constraints,
#                            senses = constraint_senses,
#                            rhs = rhs,
#                            names = constraint_names)
                
            

        print("Saving ILP encoding of NN to " + ilpfile )
        ilpsolver.solver.write(ilpsolver.save_file_name, "lp")
        
        
        return ilpsolver, ilpsolver.inputs, ilpsolver.outputs


    def _verifier_smt(self, smt, nb_samples = 10):
        nb_samples_i = 0
        data_all, target_all = self.data_loader.__get_all__()
        for data, target in zip(data_all, target_all):
            #print(data, target)
            data, target = self._to_tensor([data], [target])
            output, all_outputs = self.model.forward_no_soft_max(data)
            #print(data, output)

            output_np = output.detach().cpu().numpy()
            for k, d in  enumerate(data):
                #print(nb_samples_i)
                nb_samples_i =  nb_samples_i + 1
                if (nb_samples_i > nb_samples):
                    print("> SMT encoding is tested on " + str(nb_samples_i) + " samples<")
                    return

                assumptions_formula = TRUE()
                for i, v in enumerate(smt.inputs):
                    #print(i, v, d[i])
                    x = smt.variables[v]
                    assumptions_formula = And(assumptions_formula, Equals(ToReal(x), Real(float(d[i]))))


                #print("start smt call")
                new_formula = And(smt.formula, assumptions_formula)
                #write_smtlib(new_formula, '1.txt')
                #print(to_smtlib(new_formula, False))
                #print(smt.smt_dict[SMT_LABELED_X_VARS + str(0)])
                #print(smt.smt_dict[SMT_LABELED_X_VARS + str(1)])
                #print(smt.smt_dict[SMT_LABELED_X_VARS + str(2)])
                #print(smt.smt_dict[SMT_LABELED_X_VARS + str(3)])
                model = get_model(new_formula, solver_name='z3')
                #print("finish smt call")

                if(model):
                    #x = float(model.get_py_value(smt.variables[smt.outputs[0]]))
                    #class_id = np.argmax(output_np)
                    #assert(abs(x - class_id) < 0.001)
                    #print(nb_samples_i, class_id, x)

                    for p, v in enumerate(smt.outputs):
                        x = float(model.get_py_value(smt.variables[v]))
                        #print("%s = %s" %(v, x))
                        #print(output[p])
                        assert(abs(x - output[p]) < 0.001)

#

                else:
                    print("batch ",  data, output)
                    print("No solution found")
                    exit()

    def _verifier_ilp(self, ilp, nb_samples = 100):
        nb_samples_i = 0
        data_all, target_all = self.data_loader.__get_all__()

        ilp.solver.set_log_stream(None)
        ilp.solver.set_error_stream(None)
        ilp.solver.set_warning_stream(None)
        ilp.solver.set_results_stream(None)

        for data, target in zip(data_all, target_all):
            #print(data, target)
            data, target = self._to_tensor([data], [target])
            output, all_outputs = self.model.forward_no_soft_max(data)
            #print(data, output)

            output_np = output.detach().cpu().numpy()
            for k, d in  enumerate(data):
                #print(nb_samples_i)
                nb_samples_i =  nb_samples_i + 1
                if (nb_samples_i > nb_samples):
                    print(">ILP encoding is tested on " + str(nb_samples_i) + " samples<")
                    return


                constraints_ind = []
                for i, v in enumerate(ilp.inputs):
                    #print(i, v, d[i])
                    constraint_names = ["c1_"+str(i), "c2_"+str(i)]
                    first_constraint = [[v], [1.0]]
                    second_constraint = [[v], [1.0]]
                    rhs = [float(d[i]), float(d[i])]
                    constraint_senses = [ "G", "L" ]
                    constraints = [ first_constraint, second_constraint ]

                    #print(first_constraint, second_constraint, rhs, constraint_senses)
                    assumptions = ilp.solver.linear_constraints.add(lin_expr = constraints,
                               senses = constraint_senses,
                               rhs = rhs,
                               names = constraint_names)
                    for c in assumptions:
                        constraints_ind.append(c)
                ilp.solver.write(ilp.save_file_name+"test", "lp")
                ilp.solver.solve()
                sol = ilp.solver.solution
                #print("Solution status = ", sol.get_status(), ":", end=' ')
                #print(sol.status[sol.get_status()])
                if(sol.is_primal_feasible()):
                    #print("--",target )
#           
#                     for p, v in enumerate(ilp.inputs):
#                         x = float(sol.get_values(v))
#                         bin = float(sol.get_values(ilp.bin_domains[p]))
#                         print(x, bin)
                        
                    for p, v in enumerate(ilp.outputs):
                        x = float(sol.get_values(v))
                        #print("%s = %s" %(v, x))
                        #print(output[p])
                        #print(x, output[p])
                        assert(abs(x - output[p]) < 0.001)
                    ilp.solver.linear_constraints.delete(constraints_ind[0], constraints_ind[-1])
                    #ilp.solver.write("v_2.lp")

                else:
                    print("batch ",  data, output)
                    print("No solution found")
                    exit()

