#!/usr/bin/env python
#-*- coding:utf-8 -*-

import os
import json
import logging
import argparse
import torch
from model.model import *
from model.loss import *
from model.metric import *

from data_loader import  MnistDataLoader,  BiasedConsistentDataLoader
from trainer import Trainer
from encoder import Encoder
from logger import Logger
from time import gmtime, strftime
from utils import *
from pysmt.shortcuts import Symbol, LE, GE, TRUE, Real, Bool, Int, And, Equals, Plus, Solver, Times, Equals, Implies, Not, is_sat, get_model, to_smtlib,write_smtlib
from ilp import *
import cplex
from cplex.exceptions import CplexError


logging.basicConfig(level=logging.INFO, format='')


def nn_process(config, encode, outfile, setinteval, type_encoding):#, pick_sample = None, pick_patch = None):
    train_logger = Logger()

    if encode is not None:
        config['data_loader']['batch_size'] = 1
        config['data_loader']['shuffle'] = False
        config['validation']['shuffle'] = False
        if (setinteval == 0):
            config['domains']['set_interval_domain'] = False
        elif (setinteval == 1):
            config['domains']['set_interval_domain'] = True



    if config['id'] in {
                        'appendicitis',
                        'heart-statlog',
                        'glass',
                        'glass2',
                        'diabetes',
                        'australian',
                        'auto',
                        'backache',
                         'balance',
                         'biomed',
                         'breast-cancer',
                         'bupa',
                         'cars',
                         'cleve',
                         'cleveland',
                         'house-votes',
                         'cloud',
                         'spect'}:
        data_loader = BiasedConsistentDataLoader(config)
    elif config['id'] == 'mnist':
        data_loader = MnistDataLoader(config)
    else:
        print("unknown dataset")
        exit()



    valid_data_loader =  data_loader.split_validation()
    

    model = eval(config['arch'])(config)
    model.summary()

    loss = eval(config['loss'])
    metrics = [eval(metric) for metric in config['metrics']]


    smt_formula = None
    smt_inputs = None
    smt_outputs = None

    if encode is None:
        trainer = Trainer(model, loss, metrics,
                          resume=encode,
                          config=config,
                          data_loader=data_loader,
                          valid_data_loader=valid_data_loader,
                          train_logger=train_logger)
        trainer.train()
    else:
        encoder = Encoder(model, loss, metrics,
                      resume=encode,
                      config=config,
                      data_loader=data_loader,
                      valid_data_loader=valid_data_loader,
                      train_logger=train_logger)


#        pick_sample_info = None
#         if not (pick_sample is None):
#             pick_sample_info = {}
#             pick_sample_info["x"] = data_loader.x[pick_sample]
#             pick_sample_info["y"] = data_loader.y[pick_sample]
#             pick_sample_info["free"] = [0,1,2,3,4,5]                  
#             if not (pick_patch is None):
#                 pick_sample_info["free"] =  [int(i) for i in pick_patch.split(",")] 
                
            
        if (type_encoding == ARG_ENCODING_ILP):
            ilp_formula, ilp_inputs, ilp_outputs = encoder.ilp_encode(outfile)#, pick_sample_info = pick_sample_info)            
            return  ilp_formula, ilp_inputs, ilp_outputs, data_loader.x, data_loader.y, data_loader.x_header, data_loader.y_header
        if (type_encoding == ARG_ENCODING_SMT):
            smt_formula, smt_inputs, smt_outputs = encoder.smt_encode(outfile)#, pick_sample_info = pick_sample_info)
            return  smt_formula, smt_inputs, smt_outputs, data_loader.x, data_loader.y, data_loader.x_header, data_loader.y_header

    return None, None, None,data_loader.x, data_loader.y, data_loader.x_header, data_loader.y_header

if __name__ == '__main__':
    logger = logging.getLogger()

    parser = argparse.ArgumentParser(description='PyTorch Template')
    parser.add_argument('-c', '--config', default=None, type=str,
                        help='config file path (default: None)')
    parser.add_argument('-e', '--encode', default=None, type=str,
                        help='path to latest checkpoint (default: None)')
    parser.add_argument('-f', '--outfile', default="smt.txt", type=str,
                        help='outfile name (default: smt.txt)')
    parser.add_argument('-t', '--type_encoding', default= ARG_ENCODING_SMT, type=str,
                        help='encoding (default: ' + ARG_ENCODING_SMT + ')')
    parser.add_argument('-i', '--setinteval', default=None, type= int,
                        help='toggle set interval encoding')
    parser.add_argument('-s', '--sample', default=None, type=int,
                        help='sample id')
    parser.add_argument('-p', '--patch', default=None, type=str,
                        help='pixels')
    args = parser.parse_args()

    config = None
    if args.encode is not None:
        if args.config is not None:
            logger.warning('Warning: --config overridden by --resume')
        config = torch.load(args.encode)['config']
    elif args.config is not None:
        config = json.load(open(args.config))
        config['name'] = config['name'] + strftime("__%Y_%m_%d_%H_%M_%S", gmtime())
        path = os.path.join(config['trainer']['save_dir'], config['name'])
        assert not os.path.exists(path), "Path {} already exists!".format(path)
    assert config is not None

    try:
        out_formula, out_inputs, out_outputs, x, y, x_header, y_header = nn_process(config,
                                                                                   args.encode,
                                                                                   args.outfile,
                                                                                   args.setinteval,
                                                                                   args.type_encoding
                                                                                   )
    except CplexError as exc:
        print(exc)

    #print(x_header, y_header)
    #exit()
    if (args.encode is not None):
        if ((args.type_encoding == ARG_ENCODING_SMT)):
            print(to_smtlib(out_formula, False))



        print("inputs: ", out_inputs)
        print("outputs: ", out_outputs)

        # appending additional information
        with open(args.outfile, 'r') as fp:
            contents = fp.readlines()

        # comment symbol is ';' for SMTLIB and '\' for LP
        csymb = ';' if args.type_encoding == ARG_ENCODING_SMT else '\\'

        # comments
        comments = ['{1} inputs: {0}\n'.format(', '.join(str(v) for v in out_inputs), csymb),
                '{1} outputs: {0}\n'.format(', '.join(str(v) for v in out_outputs), csymb),
                '{1} patch: {0}\n'.format(args.patch, csymb)
                ]

        # reading feature names from the dataset file
        dfile = os.path.join(config['data_loader']['data_dir'],
                config['data_loader']['file_name'])
        with open(dfile, 'r') as fp:
            preamble = fp.readline()
            preamble = preamble.strip()

        # training samples
        samples = ['{1} data: {0}\n'.format(','.join([f for f in preamble.split(',')]), csymb)]
        for s in x:
            samples.append('{1} data: {0}\n'.format(','.join([str(v) for v in s]), csymb))

        contents = comments + samples + contents
        with open(args.outfile, 'w') as fp:
            fp.writelines(contents)

