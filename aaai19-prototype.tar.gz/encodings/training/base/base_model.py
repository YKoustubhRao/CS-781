#!/usr/bin/env python
#-*- coding:utf-8 -*-

import logging
import torch.nn as nn
import numpy as np


class BaseModel(nn.Module, object):
    """
    Base class for all models
    """
    def __init__(self, config):
        super(BaseModel, self).__init__()
        self.config = config
        self.logger = logging.getLogger(self.__class__.__name__)

    def forward(self, *input):
        """
        Forward pass logic

        :return: Model output
        """
        raise NotImplementedError

    def summary(self):
        """
        Model summary
        """
        model_parameters = filter(lambda p: p.requires_grad, self.parameters())
        params = sum([np.prod(p.size()) for p in model_parameters])
        self.logger.info('Trainable parameters: {}'.format(params))
        self.logger.info(self)

    def encode_linear_layer(self, singlelayer, solver, x, y, tag = ""):

        bias = singlelayer.bias.clone()
        bias = bias.data.cpu().numpy()

        weight = singlelayer.weight.clone()
        weight = weight.data.cpu().numpy()

        for i in range(singlelayer.weight.shape[0]):
            #sum a_ij x_i + b_j = y
            #sum a_ij x_i - y = -b_j
            vars = np.append(x, [y[i]])
            rhs = [float(-bias[i])]
            coef = np.append(weight[i], [-1])
            tag_con = tag + "_"+ str(i)

            solver.add_linear_constraint( rhs = rhs,
                                             senses = 'E',
                                             vars = vars,
                                             coefs = coef,
                                             tag = tag_con)


    def encode_linear_relu_layer(self, singlelayer, solver, x, y, s, z, tag = ""):

        bias = singlelayer.bias.clone()
        bias = bias.data.cpu().numpy()

        weight = singlelayer.weight.clone()
        weight = weight.data.cpu().numpy()

        for i in range(singlelayer.weight.shape[0]):
            #sum a_ij x_i + b_j = y - s
            #sum a_ij x_i - y + s   = - b_j
            vars = np.append(x, [y[i], s[i]])
            rhs = [float(-bias[i])]
            coef = np.append(weight[i], [-1, 1])
            tag_con = tag + "_"+ str(i)

            solver.add_linear_constraint( rhs = rhs,
                                             senses = 'E',
                                             vars = vars,
                                             coefs = coef,
                                             tag = tag_con)

#
        for i in range(singlelayer.weight.shape[0]):
            #z = 1 → y ≤ 0
            ind_vars = z[i]
            vars = [y[i]]
            rhs = 0
            coefs = [1]
            tag_con = tag + "_ind_1_"+ str(i)
            solver.add_indicator_constraint_simple(
                                               indicator_vars = ind_vars,
                                               vars = vars,
                                               coefs = coefs,
                                               rhs = rhs,
                                               senses = 'L',
                                               complemented = 0,
                                               tag = tag_con)
#
        for i in range(singlelayer.weight.shape[0]):
            #z = 0 → s ≤ 0
            ind_vars = z[i]
            vars = [s[i]]
            rhs = 0
            coefs = [1]
            tag_con = tag + "_ind_2_"+ str(i)

            solver.add_indicator_constraint_simple(
                                               indicator_vars = ind_vars,
                                               vars = vars,
                                               coefs = coefs,
                                               rhs = rhs,
                                               senses = 'L',
                                               complemented = 1,
                                               tag = tag_con)
