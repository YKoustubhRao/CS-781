import torch
import random
from collections import Counter
import numpy as np
from torchvision import datasets, transforms
from base import BaseDataLoader
import pandas as pd
import torchvision.utils as vutils

class MnistDataLoader(BaseDataLoader, object):
    def __init__(self, config):
        super(MnistDataLoader, self).__init__(config)
        create_data_set = config['data_loader']['generate_data']
        self.image_side = config['data_loader']['side']
        if(create_data_set):
            self.data_dir = config['data_loader']['data_dir']
            data_loader = torch.utils.data.DataLoader(
                datasets.MNIST(self.data_dir, train=True, download=True,
                               transform=transforms.Compose([
                                   transforms.Resize(self.image_side),
                                   transforms.ToTensor(),
                                   #transforms.Normalize((0.1307,), (0.3081,))
                               ])), batch_size=256, shuffle=False)
            self.x = []
            self.x_o = []
            self.y = []
            for data, target in data_loader:
                for i, _ in enumerate(data):
                    #print(target[i][0])
                    if (target[i].item()  in config['data_loader']["classes"]):
                        instance = data[i]
                        self.x_o +=[i for i in (instance).view(1,-1).numpy()]            

                        if (config['data_loader']["binarize"] is True):
                            instance[instance < config['data_loader']["binarize_thresh"]] = config['data_loader']["binarize_values"][0] 
                            instance[instance >= config['data_loader']["binarize_thresh"]] = config['data_loader']["binarize_values"][1]
                        if (config['data_loader']["quantize"] is True):
                            quantize_interval = config['data_loader']["quantize_interval"]
                            if (quantize_interval < 1):
                                instance[instance > quantize_interval] = 1
                                instance[instance <= quantize_interval] = 0
                            else:
                                instance = ((instance *255 )/quantize_interval).int()         
                        self.x +=[i for i in instance.view(1,-1).numpy()]
                        self.y += [target[i].numpy()]
                
                            
            self.x = np.array(self.x)
            self.y = np.array(self.y)

            self.x_o = np.array(self.x_o)
            
            self.len = self.x.shape[0]

            columns = []
            for i in  range(self.x.shape[1]):
                columns.append("p" + str(i))
            columns.append(config['data_loader']['target'])
            df = pd.DataFrame(columns=columns)
            for i in  range(self.x.shape[1]):
                df[columns[i]] = self.x[:,i]
                print("Processing ", columns[i])
            df[columns[-1]] = self.y
            fname = self.data_dir  + config['data_loader']['file_name']
            
            if (config['data_loader']["quantize"] is True):
                fname = self.data_dir  + "quantized_" + str(config['data_loader']["quantize_interval"])  + "_" + config['data_loader']['base_file_name']
            
            df.to_csv(fname, sep=',', index=False)
            print("create ", fname)
            for k in range(0,10):
                print(self.x[k,:])
                print(self.x_o[k,:])
                vutils.save_image(torch.tensor(self.x[k,:]).view(self.image_side,self.image_side), str(k)+"image.png", normalize = True)
                vutils.save_image(torch.tensor(self.x_o[k,:]).view(self.image_side,self.image_side), str(k)+"image_o.png", normalize = True)
            
            exit()


        self.data_dir = config['data_loader']['data_dir']
        xy = pd.read_csv(self.data_dir  + config['data_loader']['file_name'],
                        sep=',')

        self.len = xy.shape[0]
        self.x = torch.from_numpy(xy.drop(config['data_loader']['target'], axis=1).values).float()
        self.x_header = list(xy.drop(config['data_loader']['target'], axis=1).axes[1])

        y = xy[config['data_loader']['target']].values
        self.y_header = [(xy.axes[1][-1])]
        #print(y)
        #print(self.x_header, self.y_header)
        #exit()
#        print(type(y[0]))
        if (np.issubdtype(type(y[0]), int)):
            y_str = y + 1000 #we need to rename  targets to make them consequtive
        else:
            y_str = y + "1000" #we need to rename  targets to make them consequtive
        values_y = np.unique(y_str)
        values_y.sort()
        #print(y_str)
        #print(values_y)

        #exit()
        for i in range(len(values_y)):
            #print(i)
            for j in range(self.len):
                #print(y_str[j], values_y[i])
                if y_str[j] == values_y[i]:
                    y[j] =  int(i)
#         print(values_y)
#         #print(self.x.shape)
#         print(y)
#         exit()
        #print(y)
        #print(type(y))
        #exit()
        self.y = torch.from_numpy(y.astype(int))
        self.y_header = [(xy.axes[1][-1])]

        self.x_values = []
        all_values = np.unique(self.x)
        for i in range(self.x.shape[1]):
            #print(all_values)
            self.x_values.append(all_values)

# 
#         i = 0
#         for xx in self.x:
#             z = xx.view(self.image_side,self.image_side)
#             print(z)
#             #print(z*0.3081+0.1307)
#  
#             vutils.save_image(xx.view(self.image_side,self.image_side), str(i)+"image.png", normalize = True)
#             i+=1
#             if (i > 20):
#                exit()
        self.x = np.array(self.x)
        self.y = np.array(self.y)

    def __next__(self):
        batch = super(MnistDataLoader, self).__next__()
        batch = [np.array(sample) for sample in batch]
        return batch

    def next(self):
        return self.__next__()

    def _pack_data(self):
        packed = list(zip(self.x, self.y))
        return packed

    def _unpack_data(self, packed):
        unpacked = list(zip(*packed))
        unpacked = [list(item) for item in unpacked]
        return unpacked

    def _update_data(self, unpacked):
        self.x, self.y = unpacked

    def _n_samples(self):
        return len(self.x)

class DiabetesDataset(BaseDataLoader, object):
    def __init__(self, config):
        super(DiabetesDataset, self).__init__(config)
        self.data_dir = config['data_loader']['data_dir']

        xy = np.loadtxt(self.data_dir  + 'diabetes.csv.gz',
                        delimiter=',', dtype=np.float32)
        self.len = xy.shape[0]

        self.x = torch.from_numpy(xy[:, 0:-1])
        for i in range(self.x.shape[1]):
            col = self.x[:,i]
            self.x[:,i] = (col - col.mean())/col.std()


        self.y = torch.from_numpy(xy[:, [-1]])
        self.y =  self.y.reshape(self.y.shape[0])
        y = self.y.clone().numpy()
        self.real_stats = Counter(y)
        self.stats = {}
        self.nb_classes = len(self.real_stats)
        cnt = 0
        sum = 0
        for key, value in  self.real_stats.items():
            #print(key, value)
            if (cnt  == self.nb_classes - 1):
                self.stats[key] = self.batch_size - sum
            else:
                self.stats[key] = round(1/self.nb_classes *self.batch_size)
                sum = sum + self.stats[key]
            cnt  = cnt + 1

        self.x = np.array(self.x)
        self.y = np.array(self.y)


    #def __next__(self):
    #    batch = super(DiabetesDataset, self).__next__()
    #    batch = [np.array(sample) for sample in batch]
    #    return batch

    def next(self):
        return self.__next__()

    def __next__(self):
        if self.batch_idx >= self.__len__():
             raise StopIteration
        batch = self.__biased_next__()
        self.batch_idx = self.batch_idx + 1
        #batch = super(AppendicitisDataset, self).__next__()
        #print(batch)
        batch = [np.array(sample) for sample in batch]
        return batch

    def __biased_next__(self):
        """
        :return: Next batch
        """
        packed = self._pack_data()
        inds = []
        x = []
        y = []
        for key, value in  self.stats.items():
            cnt = 0
            #print( key, value)
            while(True):
                id = random.randint(0, self.len-1)
                if(self.y[id] == key):
                    inds.append(id)
                    x.append(self.x[id])
                    y.append(self.y[id])
                    cnt = cnt + 1

                if(cnt >= value):
                    break

        #print(inds)
        return [x,y]

    def _pack_data(self):
        packed = list(zip(self.x, self.y))
        return packed

    def _unpack_data(self, packed):
        unpacked = list(zip(*packed))
        unpacked = [list(item) for item in unpacked]
        return unpacked

    def _update_data(self, unpacked):
        self.x, self.y = unpacked

    def _n_samples(self):
        return len(self.x)


class YeastDataset(BaseDataLoader, object):
    def __init__(self, config):
        super(YeastDataset, self).__init__(config)
        self.data_dir = config['data_loader']['data_dir']

        xy = pd.read_csv(self.data_dir  + 'yeast.tsv.gz',
                        sep='\t', compression='gzip')
        self.len = xy.shape[0]

        self.x = torch.from_numpy(xy.drop('target', axis=1).values)
        for i in range(self.x.shape[1]):
            col = self.x[:,i]
            self.x[:,i] = (col - col.mean())/col.std()

        self.y = torch.from_numpy(xy['target'].values)
        self.y =  self.y.reshape(self.y.shape[0])

        self.x = np.array(self.x)
        self.y = np.array(self.y)

    def __next__(self):
        batch = super(YeastDataset, self).__next__()
        batch = [np.array(sample) for sample in batch]
        return batch

    def _pack_data(self):
        packed = list(zip(self.x, self.y))
        return packed

    def _unpack_data(self, packed):
        unpacked = list(zip(*packed))
        unpacked = [list(item) for item in unpacked]
        return unpacked

    def _update_data(self, unpacked):
        self.x, self.y = unpacked

    def _n_samples(self):
        return len(self.x)



class BiasedConsistentDataLoader(BaseDataLoader, object):
    def __init__(self, config):
        super(BiasedConsistentDataLoader, self).__init__(config)
        self.data_dir = config['data_loader']['data_dir']

        xy = pd.read_csv(self.data_dir  + config['data_loader']['file_name'],
                        sep=',')

        self.len = xy.shape[0]
        self.x = torch.from_numpy(xy.drop(config['data_loader']['target'], axis=1).values).float()
        self.x_header = list(xy.drop(config['data_loader']['target'], axis=1).axes[1])

        #print(self.x_values)
        #exit()
        #print(self.x_header)
        #exit()
        #print(self.x)
        np.set_printoptions(precision=3)
        self.x_values = []
        self.x_values_orig = []
        for i in range(self.x.shape[1]):
            col = self.x[:,i]
            #print(col, col.mean(), col.std())
            self.x_values_orig.append(np.unique(col))
            self.x[:,i] = (col - col.mean())/col.std() # col/col.max() #
            self.x_values.append(np.unique(self.x[:,i]))
            #print(self.x[:,i])
        #exit()
        #print(self.x_values_orig[0].len())
        #print(self.x_values[0])
        #exit()


        y = xy[config['data_loader']['target']].values
        self.y_header = [(xy.axes[1][-1])]
        #print(self.x_header, self.y_header)
        #exit()
#        print(type(y[0]))
        if (np.issubdtype(type(y[0]), int)):
            y_str = y + 1000 #we need to rename  targets to make them consequtive
        else:
            y_str = y + "1000" #we need to rename  targets to make them consequtive
        values_y = np.unique(y_str)
        values_y.sort()
        #print(y_str)
        #print(values_y)

        #exit()
        for i in range(len(values_y)):
            #print(i)
            for j in range(self.len):
                #print(y_str[j], values_y[i])
                if y_str[j] == values_y[i]:
                    y[j] =  int(i)
#         print(values_y)
#         #print(self.x.shape)
#         print(y)
#         exit()
        #print(y)
        #print(type(y))
        #exit()
        self.y = torch.from_numpy(y.astype(int))
        self.real_stats = Counter(y)
        self.stats = {}
        self.nb_classes = len(self.real_stats)
        ## Replace class labels
        #!!!
        cnt = 0
        sum = 0
        for key, value in  self.real_stats.items():
            #print(key, value)
            if (cnt  == self.nb_classes - 1):
                self.stats[key] = self.batch_size - sum
            else:
                self.stats[key] = round(1/self.nb_classes *self.batch_size)
                sum = sum + self.stats[key]
            cnt  = cnt + 1



        #print(self.real_stats)
        #print(self.stats)

        #print(self.len, self.x)
        #print(self.len, self.y)
        #exit()

        self.x = np.array(self.x)
        self.y = np.array(self.y)

    def next(self):
        return self.__next__()

    def __next__(self):
        if self.batch_idx >= self.__len__():
             raise StopIteration
        batch = self.__biased_next__()
        self.batch_idx = self.batch_idx + 1
        #batch = super(BiasedConsistentDataLoader, self).__next__()
        #print(batch)
        batch = [np.array(sample) for sample in batch]
        return batch

    def __biased_next__(self):
        """
        :return: Next batch
        """
        packed = self._pack_data()
        inds = []
        x = []
        y = []
        for key, value in  self.stats.items():
            cnt = 0
            #print( key, value)
            while(True):
                id = random.randint(0, self.len-1)
                if(self.y[id] == key):
                    inds.append(id)
                    x.append(self.x[id])
                    y.append(self.y[id])
                    cnt = cnt + 1

                if(cnt >= value):
                    break

        #print(inds)
        return [x,y]

    def _pack_data(self):
        packed = list(zip(self.x, self.y))
        return packed

    def _unpack_data(self, packed):
        unpacked = list(zip(*packed))
        unpacked = [list(item) for item in unpacked]
        return unpacked

    def _update_data(self, unpacked):
        self.x, self.y = unpacked

    def _n_samples(self):
        return len(self.x)
