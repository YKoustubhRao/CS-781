#!/usr/bin/env python
#-*- coding:utf-8 -*-
##
## explain.py
##
##  Created on: Aug 1, 2018
##      Author: Alexey S. Ignatiev
##      E-mail: aignatiev@ciencias.ulisboa.pt
##

#
#==============================================================================
from __future__ import print_function
import cplex
import getopt
import math
import matplotlib.image as mpimg
import matplotlib.cm as mpcm
import matplotlib.pyplot as mpplt
import numpy as np
import os
from pysat.card import CardEnc, EncType
from pysat.examples.hitman import Hitman
from pysat.formula import CNF, IDPool
from pysmt.smtlib.parser import SmtLibParser
from pysmt.shortcuts import Solver
from pysmt.shortcuts import And, BOOL, Implies, Not, Or, Symbol
from pysmt.shortcuts import Equals, GT, Int, Real
import resource
from six.moves import range
import sys

try:  # for Python2
    from cStringIO import StringIO
except ImportError:  # for Python3
    from io import StringIO


#
#==============================================================================
def parse_smt2file(fname):
    """
        Get SMT2 formula as well as inputs and outputs of the network.
    """

    with open(fname, 'r') as fp:
        file_content = fp.readlines()

    data = []

    for line in file_content:
        if line[0] != ';':
            break
        elif line.startswith('; data:'):
            data.append(line[7:].strip())
        elif line.startswith('; inputs:'):
            inputs = line[10:].strip().split(', ')
        elif line.startswith('; outputs:'):
            outputs = line[11:].strip().split(', ')

    parser = SmtLibParser()
    script = parser.get_script(StringIO(''.join(file_content)))

    formula = script.get_last_formula()
    allvars = formula.get_free_variables()

    # set of input variable names and their ids
    seti = set(inputs)
    ivid = {v: i for i, v in enumerate(inputs)}

    # set of output variable names and their ids
    seto = set(outputs)
    ovid = {v: i for i, v in enumerate(outputs)}

    ivs = []
    ovs = []
    for v in allvars:
        if v.symbol_name() in seto:
            ovs.append(v)
        elif v.symbol_name() in seti:
            ivs.append(v)

    # returning formula, input and output variables as objects of PySMT
    return formula, sorted(ivs, key=lambda v: ivid[v.symbol_name()]), \
            sorted(ovs, key=lambda v: ovid[v.symbol_name()]), data


#
#==============================================================================
def parse_lpfile(fname):
    """
        Parse LP file and extract LP constraints as well as variable names and
        the original dataset.
    """

    with open(fname, 'r') as fp:
        file_content = fp.readlines()

    data = []

    for line in file_content:
        if line[0] != '\\':
            break
        elif line.startswith('\\ data:'):
            data.append(line[7:].strip())
        elif line.startswith('\\ inputs:'):
            inputs = list(line[10:].strip().split(', '))
        elif line.startswith('\\ outputs:'):
            outputs = list(line[11:].strip().split(', '))

    ilp = cplex.Cplex()
    ilp.read(fname)

    return ilp, inputs, outputs, data


#
#==============================================================================
def prepare_hitman(pixels, inputs, intervals, htype):
    """
        Initialize a hitting set enumerator.
    """

    if not pixels:
        pixels = sorted(range(len(inputs)))

    # new Hitman object
    h = Hitman(htype=htype)

    # first variables should be related with the elements of the sets to hit
    # that is why we are adding soft clauses first
    for p in pixels:
        for v in range(intervals):
            var = h.idpool.id(tuple([inputs[p], v]))
            h.oracle.add_clause([-var], 1)

    # at most one value per pixel can be selected
    for p in pixels:
        lits = [h.idpool.id(tuple([inputs[p], v])) for v in range(intervals)]
        cnf = CardEnc.atmost(lits, encoding=EncType.pairwise)

        for cl in cnf.clauses:
            h.oracle.add_clause(cl)

    return h


#
#==============================================================================
def compile_classifier(h, x, inputs, pmap, intervals, verb):
    """
        Compile the classifier using ILP.
    """

    expls, coexs = [], []
    hset = []

    while True:
        if hset:
            print('hset', ', '.join(['(p{0}, {1})'.format(pmap[l[0]], l[1]) for l in hset]))
        else:
            print('hset -')

        coex = x.get_counterexample(assumptions=hset)
        if coex:
            # the opposite class
            # an explanation needs to be extracted
            expl = x.explain(coex)
            coexs.append(expl)

            hit_counterexample(coex, expl, h, inputs, intervals)

            print('coex', ', '.join(['(p{0}, {1})'.format(pmap[inputs[l[0]]], int(coex[l[0]])) for l in expl]))
        else:
            # if the class is 0 then no reduction is needed
            # the hitting set should be a subset-minimal explanation
            h.block(hset)
            expls.append(hset)

            print('expl', ', '.join(['(p{0}, {1})'.format(pmap[l[0]], l[1]) for l in hset]))

        hset = h.get()
        if hset == None:
            break

        hset = list(filter(lambda x: len(x) == 2, hset))
        print('')

    return expls, coexs


#
#==============================================================================
def hit_counterexample(coex, expl, h, inputs, intervals):
    """
        Encode the negation of the counterexample so that it will be hit next
        time.
    """

    encoded = []

    for l in expl:
        pix, val = inputs[l[0]], int(coex[l[0]])
        lobj = tuple([pix, val, '-'])

        if lobj not in h.idpool.obj2id:
            v = h.idpool.id(lobj)  # new variable identifier
            # print(lobj, '<->', v)

            # pixel cannot take value v and not v simultaneously
            h.oracle.add_clause([-v, -h.idpool.id(tuple([pix, val]))])

            # print(-v, -h.idpool.id(tuple([pix, val])))

            # v implies that some other value must be chosen for this pixel
            cl = []
            for i in set(range(intervals)).difference(set([val])):
                v2 = h.idpool.id(tuple([inputs[l[0]], i]))
                # print(tuple([inputs[l[0]], i]), '<->', v2)
                cl.append(v2)

                # this clause is optional
                h.oracle.add_clause([-v2, v])

            # print('cl', [-v] + cl)
            h.oracle.add_clause([-v] + cl)
        else:
            v = h.idpool.id(lobj)
            # print(lobj, '<->', v)

        encoded.append(v)

    # print('hit_', encoded)
    h.oracle.add_clause(encoded)


#
#==============================================================================
class SMTExplainer(object):
    """
        An SMT-inspired minimal explanation extractor for neural networks
        based on ReLUs.
    """

    def __init__(self, formula, inputs, outputs, names, solver, verbose=0):
        """
            Constructor.
        """

        self.verbose = verbose
        self.oracle = Solver(name=solver)

        # theory
        self.oracle.add_assertion(formula)

        # feature and class names (for verbosity)
        self.fnames = {}
        self.values = {}
        self.inputs = inputs

        # relaxed hypotheses
        self.rhypos = []

        for i, inp in enumerate(inputs, 1):
            selv = Symbol('selv_f{0}'.format(i))

            hypo = Implies(selv, Equals(inp[0], Real(inp[1])))
            self.oracle.add_assertion(hypo)

            self.rhypos.append(selv)
            self.fnames[selv] = names[i - 1]
            self.values[selv] = inp[1]

        # getting the true observation
        # (not the expected one as specified in the dataset)
        if self.oracle.solve(self.rhypos):
            model = self.oracle.get_model()
        else:
            assert 0, 'Formula is unsatisfiable under given assumptions'

        # choosing the maximum
        outvals = [float(model.get_py_value(o)) for o in outputs]
        maxoval = max(zip(outvals, range(len(outvals))))

        # correct class id (corresponds to the maximum computed)
        true_output = maxoval[1]
        self.output = '{0} = {1}'.format(names[-1], true_output)

        # observation
        # (forcing it to be wrong)
        disj = []
        for i in range(len(outputs)):
            if i != true_output:
                disj.append(GT(outputs[i], outputs[true_output]))
        self.oracle.add_assertion(Or(disj))

        if self.verbose:
            print('  explaining:  "IF {0} THEN {1}"'.format(' AND '.join(['{0} = {1}'.format(f, v[1]) for f, v in zip(names[:-1], inputs)]), self.output))

    def explain(self, smallest, free):
        """
            Hypotheses minimization.
        """

        self.time = resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime + \
                resource.getrusage(resource.RUSAGE_SELF).ru_utime

        # if satisfiable, then the observation is not implied by the hypotheses
        if self.oracle.solve(self.rhypos):
            print('  no implication!')
            print(self.oracle.get_model())
            sys.exit(1)

        if not smallest:
            self.compute_minimal()
        else:
            self.compute_smallest()

        if self.verbose:
            print('  explanation: "IF {0} THEN {1}"'.format(' AND '.join(['{0} = {1}'.format(self.fnames[v], self.values[v]) for v in self.rhypos]), self.output))

        print('  # hypos left:', len(self.rhypos))

        self.time = resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime + \
                resource.getrusage(resource.RUSAGE_SELF).ru_utime - self.time
        print('  time: {0:.2f}'.format(self.time))

    def compute_minimal(self):
        """
            Compute any subset-minimal explanation.
        """

        i = 0

        # simple deletion-based linear search
        while i < len(self.rhypos):
            to_test = self.rhypos[:i] + self.rhypos[(i + 1):]

            if self.oracle.solve(to_test):
                i += 1
            else:
                self.rhypos = to_test

    def compute_smallest(self):
        """
            Compute a cardinality-minimal explanation.
        """

        # result
        rhypos = []

        # with HitMinimum() as hitman:
        with Hitman(bootstrap_with=[list(range(len(self.rhypos)))]) as hitman:
            # computing unit-size MCSes
            for i, hypo in enumerate(self.rhypos):
                if self.oracle.solve(self.rhypos[:i] + self.rhypos[(i + 1):]):
                    hitman.hit([i])

            # main loop
            iters = 0
            while True:
                hset = hitman.get()
                iters += 1

                if self.verbose > 1:
                    print('iter:', iters)
                    print('cand:', hset)

                if self.oracle.solve([self.rhypos[i] for i in hset]):
                    to_hit = []
                    satisfied, unsatisfied = [], []

                    removed = list(set(range(len(self.rhypos))).difference(set(hset)))

                    model = self.oracle.get_model()
                    for h in removed:
                        # feature variable and its expected value
                        var, exp = self.inputs[h]

                        # true value
                        true_val = float(model.get_py_value(var))

                        if not exp - 0.001 <= true_val <= exp + 0.001:
                            unsatisfied.append(h)
                        else:
                            hset.append(h)

                    # computing an MCS (expensive)
                    for h in unsatisfied:
                        if self.oracle.solve([self.rhypos[i] for i in hset] + [self.rhypos[h]]):
                            hset.append(h)
                        else:
                            to_hit.append(h)

                    if self.verbose > 1:
                        print('coex:', to_hit)

                    hitman.hit(to_hit)
                else:
                    self.rhypos = [self.rhypos[i] for i in hset]
                    break

#
#==============================================================================
class ILPExplainer(object):
    """
        An ILP-inspired minimal explanation extractor for neural networks
        based on ReLUs.
    """

    def __init__(self, oracle, inputs, outputs, names, datainst, free,
            compile_, verbose=0):
        """
            Constructor.
        """

        self.verbose = verbose
        self.oracle = oracle

        # turning logger off
        self.oracle.set_log_stream(None)
        self.oracle.set_error_stream(None)
        self.oracle.set_results_stream(None)
        self.oracle.set_warning_stream(None)

        # feature and class names (for verbosity)
        self.fnames = names

        # internal input variable names
        self.inputs = inputs

        # output variable names
        self.outputs = outputs

        # true class of the counterexample
        self.coex_class = None

        # free inputs (by default, include all inputs)
        if free:
            self.free = set(free)
        else:
            self.free = set(range(len(self.inputs)))

        # now, we need to freeze the non-free inputs
        if len(self.free) < len(inputs):
            for i, (var, val) in enumerate(zip(inputs, datainst)):
                if i in self.free:
                    continue

                eql, rhs = [[var], [1]], [val]

                cnames = ['freezed_{0}'.format(i)]
                senses = ['E']
                constr = [eql]

                self.oracle.linear_constraints.add(lin_expr=constr,
                        senses=senses, rhs=rhs, names=cnames)

        # hypotheses
        self.hypos = []

        # adding indicators for correct and wrong outputs
        self.oracle.variables.add(names=['c_{0}'.format(i) for i in range(len(outputs))], types='B' * len(outputs))
        for i in range(len(outputs)):
            ivar = 'c_{0}'.format(i)
            wrong = ['wc_{0}_{1}'.format(i, j) for j in range(len(outputs)) if i != j]
            self.oracle.variables.add(names=wrong, types='B' * len(wrong))

            # ivar implies at least one wrong class
            self.oracle.indicator_constraints.add(indvar=ivar, lin_expr=[wrong,
                [1] * len(wrong)], sense='G', rhs=1)

            for j in range(len(outputs)):
                if i != j:
                    # iv => (o_j - o_i >= 0.0000001)

                    iv = 'wc_{0}_{1}'.format(i, j)
                    ov, oc = [outputs[j], outputs[i]], [1, -1]
                    self.oracle.indicator_constraints.add(indvar=iv,
                            lin_expr=[ov, oc], sense='G', rhs=0.0001)

        # class to compile
        if compile_[0].isdigit():
            self.compile = int(compile_)
        else:
            hypos = []
            # determine the true class for the given instance
            for i, (var, val) in enumerate(zip(inputs, datainst)):
                if i in self.free:
                    eql, rhs = [[var], [1]], [val]

                    cnames = ['hypo_{0}'.format(i)]
                    senses = ['E']
                    constr = [eql]

                    assump = self.oracle.linear_constraints.add(lin_expr=constr,
                            senses=senses, rhs=rhs, names=cnames)

                    # adding a constraint to the list of hypotheses
                    hypos.append([cnames[0]])

            self.oracle.solve()
            if self.oracle.solution.is_primal_feasible():
                model = self.oracle.solution

                outvals = [float(model.get_values(o)) for o in self.outputs]
                maxoval = max(zip(outvals, range(len(outvals))))

                # correct class id (corresponds to the maximum computed)
                if compile_ == 'true':
                    self.compile = maxoval[1]
                else:
                    self.compile = int(not maxoval[1])
            else:
                assert 0, 'unsatisfiable instance!'

            # removing the hypotheses
            for hypo in hypos:
                self.oracle.linear_constraints.delete(hypo)

        # linear constraints activating a specific class
        # will be added for each sample individually
        # e.g. self.oracle.linear_constraints.add(lin_expr=[['c_0'], [1]], senses=['G'], rhs=[1])

    def get_counterexample(self, assumptions=[]):
        """
            Extract a (complete) sample corresponding to the given list of
            assumptions.
        """

        assumps = []
        for i, assump in enumerate(assumptions, 1):
            var, val = assump
            eql = [[var], [1]]
            rhs = [int(val)]

            cnames = ['assump_{0}'.format(i)]
            senses = ['E']
            constr = [eql]

            assump = self.oracle.linear_constraints.add(lin_expr=constr,
                    senses=senses, rhs=rhs, names=cnames)

            # adding a constraint to the list of hypotheses
            assumps.append(cnames[0])

        # forcing a wrong class
        self.oracle.linear_constraints.add(lin_expr=[[['c_{0}'.format(self.compile)], [1]]],
                senses='E', rhs=[1], names=['forced_output'])

        # getting the true observation
        # (not the expected one as specified in the dataset)
        self.oracle.solve()
        if self.oracle.solution.is_primal_feasible():
            self.coex_model = self.oracle.solution

            # obtaining input (sample) values
            sample = [round(self.coex_model.get_values(i)) for i in self.inputs]

            outvals = [float(self.coex_model.get_values(o)) for o in self.outputs]
            maxoval = max(zip(outvals, range(len(outvals))))

            # correct class id (corresponds to the maximum computed)
            self.coex_class = maxoval[1]
        else:
            sample = None

        # deleting assumptions
        for assump in assumps:
            self.oracle.linear_constraints.delete(assump)

        # deleting the output enforced
        self.oracle.linear_constraints.delete('forced_output')

        return sample

    def add_sample(self, sample):
        """
            Add constraints for a concrete data sample.
        """

        self.values = sample

        self.hypos = []
        for i, v in enumerate(self.inputs, 1):
            eql = [[v], [1]]
            rhs = [int(sample[i - 1])]

            cnames = ['hypo_{0}'.format(i)]
            senses = ['E']
            constr = [eql]

            if i - 1 in self.free:
                assump = self.oracle.linear_constraints.add(lin_expr=constr,
                        senses=senses, rhs=rhs, names=cnames)

            # adding a constraint to the list of hypotheses
            self.hypos.append(tuple([cnames[0], constr, rhs, senses, i - 1]))

        # observation (forcing it to be wrong)
        self.oracle.linear_constraints.add(lin_expr=[[['c_{0}'.format(self.coex_class)], [1]]],
                senses='E', rhs=[1], names=['forced_output'])

        # if self.verbose:
        #     print('  explaining:  "IF {0} THEN {1}"'.format(' AND '.join(['{0} = {1}'.format(f, v) for f, v in zip(names[:-1], self.values)]), self.output))

    def explain(self, sample):
        """
            Hypotheses minimization.
        """

        self.time = resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime + \
                resource.getrusage(resource.RUSAGE_SELF).ru_utime

        # add constraints corresponding to the current sample
        self.add_sample(sample)

        # if satisfiable, then the observation is not implied by the hypotheses
        self.oracle.solve()
        if self.oracle.solution.is_primal_feasible():
            print('  no implication!')
            model = self.oracle.solution
            print('coex  sample:', [self.coex_model.get_values(i) for i in self.inputs])
            print('coex  rounded:', [round(self.coex_model.get_values(i)) for i in self.inputs])
            print('coex classes:', [self.coex_model.get_values(o) for o in self.outputs])
            print('wrong sample:', [model.get_values(i) for i in self.inputs])
            print('wrong rounded:', [round(model.get_values(i)) for i in self.inputs])
            print('wrong classes:', [model.get_values(o) for o in self.outputs])

            sys.exit(1)

        if not smallest:
            rhypos = self.compute_minimal()
        else:  # get a smallest explanation
            rhypos = self.compute_smallest()

        # if self.verbose:
        #     print('  explanation: "IF {0} THEN {1}"'.format(' AND '.join(['{0} = {1}'.format(self.fnames[h[0]], self.values[h[0]]) for h in rhypos]), self.output))

        expl_sz = len(rhypos)
        if self.verbose:
            print('  # hypos left:', expl_sz)

        # removing hypotheses related to the current sample
        for hypo in rhypos:
            self.oracle.linear_constraints.delete(hypo[1])

        # removing the output forced to be wrong
        self.oracle.linear_constraints.delete('forced_output')

        self.time = resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime + \
                resource.getrusage(resource.RUSAGE_SELF).ru_utime - self.time

        if self.verbose:
            print('  time: {0:.2f}'.format(self.time))

        return rhypos

    # def sort_sample(self, sample, sz, way):
    #     """
    #         This procedure defines the order in which the features/pixels will
    #         be traversed.
    #     """

    #     if way in ('light', 'l'):
    #         # sorting pixels based on the darkness
    #         # (dark pixels are removed first)
    #         self.hypos.sort(key=lambda h: sample[h[4]])
    #     elif way in ('center', 'c'):
    #         # sorting pixels based on the distance from the center
    #         # distant pixels are removed first
    #         sz = int(math.sqrt(len(sample)))
    #         assert len(sample) == sz ** 2, 'data seems to be not a square image'

    #         # coordinates of the center
    #         c = (sz / 2 - 1, sz / 2 - 1)

    #         # maximal distance
    #         r = 2 * float((sz / 2) ** 2)

    #         self.hypos.sort(key=lambda h: r - ((h[4] / sz - c[0]) ** 2 + (h[4] % sz - c[1]) ** 2))
    #     elif way in ('lc', 'cl'):
    #         # sorting based on both criteria combined
    #         sz = int(math.sqrt(len(sample)))
    #         assert len(sample) == sz ** 2, 'data seems to be not a square image'

    #         # coordinates of the center
    #         c = (sz / 2 - 1, sz / 2 - 1)

    #         # maximal radius
    #         r = 2 * float((sz / 2) ** 2)

    #         if way == 'lc':
    #             self.hypos.sort(key=lambda h: (sample[h[4]] + 1) * r + (r - (h[4] / sz - c[0]) ** 2 + (h[4] % sz - c[1]) ** 2))
    #         else:  # 'cl'
    #             self.hypos.sort(key=lambda h: sample[h[4]] + 256 * (1 + r - (h[4] / sz - c[0]) ** 2 + (h[4] % sz - c[1]) ** 2))
    #     else:  # do nothing in case of 'simple' traverse
    #         pass

    def compute_minimal(self):
        """
            Compute any subset-minimal explanation.
        """

        # result
        rhypos = []

        # simple deletion-based linear search
        for i, hypo in enumerate(self.hypos):
            if i not in self.free:
                continue

            self.oracle.linear_constraints.delete(hypo[0])

            self.oracle.solve()
            if self.oracle.solution.is_primal_feasible():
                # this hypothesis is needed
                # adding it back to the list
                self.oracle.linear_constraints.add(lin_expr=hypo[1],
                        senses=hypo[3], rhs=hypo[2], names=[hypo[0]])

                rhypos.append(tuple([hypo[4], hypo[0]]))

        return rhypos

    def compute_smallest(self):
        """
            Compute a cardinality-minimal explanation.
        """

        # result
        rhypos = []

        # with HitMinimum() as hitman:
        with Hitman(bootstrap_with=[list(range(len(self.hypos)))]) as hitman:
            # computing unit-size MCSes
            for i, hypo in enumerate(self.hypos):
                self.oracle.linear_constraints.delete(hypo[0])

                self.oracle.solve()
                if self.oracle.solution.is_primal_feasible():
                    hitman.hit([i])

                self.oracle.linear_constraints.add(lin_expr=hypo[1],
                        senses=hypo[3], rhs=hypo[2], names=[hypo[0]])

            # main loop
            iters = 0
            while True:
                hset = hitman.get()
                iters += 1

                to_remove = set(range(len(self.hypos))).difference(set(hset))
                for i in to_remove:
                    self.oracle.linear_constraints.delete(self.hypos[i][0])

                if self.verbose > 1:
                    print('iter:', iters)
                    print('cand:', hset)

                self.oracle.solve()
                if self.oracle.solution.is_primal_feasible():
                    to_hit = []
                    satisfied, unsatisfied = [], []

                    model = self.oracle.solution
                    for h in to_remove:
                        # feature variable and its expected value
                        var, exp = self.hypos[h][1][0][0], self.hypos[h][2][0]

                        # true value
                        true_val = model.get_values(var)[0]
                        if exp - 0.001 <= true_val <= exp + 0.001:
                            satisfied.append(h)
                        else:
                            unsatisfied.append(h)

                    for i in satisfied:
                            hypo = self.hypos[i]
                            self.oracle.linear_constraints.add(lin_expr=hypo[1],
                                    senses=hypo[3], rhs=hypo[2], names=[hypo[0]])

                    # computing an MCS (expensive)
                    for i in unsatisfied:
                        hypo = self.hypos[i]
                        self.oracle.linear_constraints.add(lin_expr=hypo[1],
                                senses=hypo[3], rhs=hypo[2], names=[hypo[0]])

                        self.oracle.solve()
                        if not self.oracle.solution.is_primal_feasible():
                            self.oracle.linear_constraints.delete(hypo[0])
                            to_hit.append(i)

                    if self.verbose > 1:
                        print('coex:', to_hit)

                    hitman.hit(to_hit)

                    for i in to_hit:
                        hypo = self.hypos[i]
                        self.oracle.linear_constraints.add(lin_expr=hypo[1],
                                senses=hypo[3], rhs=hypo[2], names=[hypo[0]])
                else:
                    rhypos = list([tuple([h, self.hypos[h][0]]) for h in hset])
                    break

        return rhypos

    def save_image(self, sample, expls, pmap, free, minsz, dataid, compile_):
        """
            Create an image file containing the resulting image with the
            explanations highlighted.
        """

        # image size
        sz = int(math.sqrt(len(sample)))

        # original image
        pixels1, pixels2 = [], []  # this will contain an array of masked pixels
        for i in range(sz):
            row1, row2 = [], []
            for j, v in enumerate(sample[(i * sz):(i + 1) * sz]):
                if v == 1:
                    if i * sz + j in free:
                        row1.append(tuple([0, 255, 255, 230.0]))
                    else:
                        row1.append(tuple([255, 255, 255, 255.0]))

                    row2.append(tuple([255, 255, 255, 255.0]))
                else:
                    if i * sz + j in free:
                        row1.append(tuple([255, 255, 0, 200.0]))
                    else:
                        row1.append(tuple([0, 0, 0, 255.0]))

                    row2.append(tuple([0, 0, 0, 255.0]))

            pixels1.append(row1)
            pixels2.append(row2)

        pixels1 = np.asarray(pixels1, dtype=np.uint8)
        pixels2 = np.asarray(pixels2, dtype=np.uint8)
        mpimg.imsave('sample{0}-free.png'.format(dataid), pixels1, cmap=mpcm.gray, dpi=5)
        mpimg.imsave('sample{0}-orig.png'.format(dataid), pixels2, cmap=mpcm.gray, dpi=5)

        # frequency of appearing in an explanation for each pixel
        freqs_all = [0.0 for v in range(len(sample))]
        freqs_min = [0.0 for v in range(len(sample))]

        for e in expls:
            if len(e) > minsz:
                for i in e:
                    freqs_all[pmap[i[0]]] += 1
                continue

            for i in e:
                freqs_min[pmap[i[0]]] += 1

        freqs_all = [a + m for a, m in zip(freqs_all, freqs_min)]

        freqs_all = list(map(lambda x: x * 200 / max(freqs_all), freqs_all))
        freqs_min = list(map(lambda x: x * 200 / max(freqs_min), freqs_min))

        # most frequent polarity
        polarity = [[0.0, 0.0] for v in range(len(sample))]
        for e in expls:
            for i in e:
                if i[1] == 1:
                    polarity[pmap[i[0]]][1] += 255.0 / len(expls)
                else:
                    polarity[pmap[i[0]]][0] += 255.0 / len(expls)

        pixels1, pixels2, pixels3, pixels4, pixels5 = [], [], [], [], []
        for i in range(sz):
            row1, row2, row3, row4, row5 = [], [], [], [], []
            for j, v in enumerate(sample[(i * sz):(i + 1) * sz]):
                k = i * sz + j
                row1.append(tuple([255, 0, 0, freqs_all[k]]))
                row2.append(tuple([255, 0, 0, freqs_min[k]]))

                if polarity[k][0] == polarity[k][1]:
                    row3.append(tuple([255, 255, 255, 255]))
                elif polarity[k][0] < polarity[k][1]:
                    row3.append(tuple([255, 0, 0, 255]))
                else:
                    row3.append(tuple([0, 0, 255, 255]))

                row4.append(tuple([255, 0, 0, polarity[k][1]]))
                row5.append(tuple([0, 0, 255, polarity[k][0]]))

            pixels1.append(row1)
            pixels2.append(row2)
            pixels3.append(row3)
            pixels4.append(row4)
            pixels5.append(row5)

        pixels1 = np.asarray(pixels1, dtype=np.uint8)
        pixels2 = np.asarray(pixels2, dtype=np.uint8)
        pixels3 = np.asarray(pixels3, dtype=np.uint8)
        pixels4 = np.asarray(pixels4, dtype=np.uint8)
        pixels5 = np.asarray(pixels5, dtype=np.uint8)
        mpimg.imsave('sample{0}-{1}-freqs-all.png'.format(dataid, compile_),
                pixels1, cmap=mpcm.gray, dpi=5)
        mpimg.imsave('sample{0}-{1}-freqs-min.png'.format(dataid, compile_),
                pixels2, cmap=mpcm.gray, dpi=5)
        mpimg.imsave('sample{0}-{1}-polarity.png'.format(dataid, compile_),
                pixels3, cmap=mpcm.gray, dpi=5)
        mpimg.imsave('sample{0}-{1}-hm1.png'.format(dataid, compile_),
                pixels4, cmap=mpcm.gray, dpi=5)
        mpimg.imsave('sample{0}-{1}-hm0.png'.format(dataid, compile_),
                pixels5, cmap=mpcm.gray, dpi=5)

        # pixels = []  # this will contain an array of masked pixels
        # for i in range(sz):
        #     row = []
        #     for j, v in enumerate(sample[(i * sz):(i + 1) * sz]):
        #         row.append(tuple([v, v, v]))
        #     pixels.append(row)

        # pixels = np.asarray(pixels, dtype=np.uint8)
        # mpimg.imsave('sample-digit{0}-{1}.svg'.format(index, way), pixels,
        #         cmap=mpcm.gray, dpi=5)

        # pixels = []  # this will contain an array of masked pixels
        # for i in range(sz):
        #     row = []
        #     for j, v in enumerate(sample[(i * sz):(i + 1) * sz]):
        #         if i * sz + j in expl:
        #             row.append(tuple([255, 255, 255]))
        #         else:
        #             row.append(tuple([0, 0, 0]))
        #     pixels.append(row)

        # pixels = np.asarray(pixels, dtype=np.uint8)
        # mpimg.imsave('sample-expl{0}-{1}.svg'.format(index, way), pixels,
        #         cmap=mpcm.gray, dpi=5)


#
#==============================================================================
def parse_options():
    """
        Parses command-line options:
    """

    try:
        opts, args = getopt.getopt(sys.argv[1:],
                                   'a:c:d:f:i:hms:t:v',
                                   ['attempts=',
                                    'compile=',
                                    'data=',
                                    'free=',
                                    'intervals=',
                                    'htype=',
                                    'minsize',
                                    'solver=',
                                    'save',
                                    'traverse=',
                                    'help',
                                    'verb'])
    except getopt.GetoptError as err:
        sys.stderr.write(str(err).capitalize())
        usage()
        sys.exit(1)

    attempts = 1
    compile_ = 0
    datainst = 0
    free = None
    intervals = 8
    smallest = False
    solver = 'z3'
    save = False
    htype = 'lbx'
    traverse = 'simple'
    verb = 0

    for opt, arg in opts:
        if opt in ('-a', '--attempts'):
            attempts = str(arg)
        elif opt in ('-c', '--compile'):
            compile_ = str(arg)
        elif opt in ('-d', '--data'):
            datainst = int(arg)
        elif opt in ('-f', '--free'):
            free = str(arg)
        elif opt in ('-i', '--intervals'):
            intervals = int(arg)
        elif opt in ('-h', '--help'):
            usage()
            sys.exit(0)
        elif opt == ('--htype'):
            htype = str(arg)
        elif opt in ('-m', '--minsize'):
            smallest = True
        elif opt in ('-s', '--solver'):
            solver = str(arg)
        elif opt == ('--save'):
            save = True
        elif opt in ('-t', '--traverse'):
            traverse = str(arg)
        elif opt in ('-v', '--verb'):
            verb += 1
        else:
            assert False, 'Unhandled option: {0} {1}'.format(opt, arg)

    return attempts, compile_, datainst, free, intervals, htype, solver, \
            save, smallest, traverse, verb, args


#
#==============================================================================
def usage():
    """
        Prints usage message.
    """

    print('Usage:', os.path.basename(sys.argv[0]), '[options] smt2-or-lp-file')
    print('Options:')
    print('        -a, --attempts=<int>       Number of samples to explain')
    print('                                   Available values: [1 .. INT_MAX] (default: 1)')
    print('        -c, --compile=<int>        Class to compile')
    print('                                   Available values: [0 .. INT_MAX], true, opposite (default: 0)')
    print('        -d, --data=<int>           Index of data instance to work with')
    print('                                   Available values: [0 .. INT_MAX] (default: 0)')
    print('        -f, --free=<string>        A path to a file containing a comma-separated list of free pixels identifiers')
    print('                                   Default: none (means that all pixels are free)')
    print('        -i, --intervals=<int>      Number of intervals, i.e. values, per pixel')
    print('                                   Available values: [2 .. INT_MAX] (default: 8)')
    print('        -h, --help')
    print('        --htype=<string>           Compute smallest size hitting sets')
    print('                                   Available values: lbx, maxsat/rc2/sorted, mcsls (default: lbx)')
    print('        -m, --minsize              Enumerate smallest size explanations')
    print('        -s, --solver=<string>      SMT solver to use')
    print('                                   Available values: cplex, cvc4, msat, z3, yices (default: z3)')
    print('        --save                     Save the resulting image')
    print('        -t, --traverse=<string>    Traverse pixels based on this preference')
    print('                                   Available values: center, combined, light, simple (default: simple)')
    print('        -v, --verb                 Be verbose')


#
#==============================================================================
if __name__ == '__main__':
    # parse command-line options
    attempts, compile_, dataid, free, intervals, htype, solver, save, \
            smallest, traverse, verb, files = parse_options()

    if files:
        if free:  # let's get the ids of free pixels
            with open(free, 'r') as fp:
                free = [int(p.strip()) for p in ''.join([l.strip() for l in fp.readlines()]).split(',')]

        if solver in ('cvc4', 'msat', 'z3', 'yices'):
            formula, inputs, outputs, data = parse_smt2file(files[0])

            # feature names
            names = data[0].split(',')

            # translating 'all' attempts to the correct number
            attempts = int(attempts) if attempts != 'all' else len(data) - 1

            xlen = []
            time = []
            for i in range(min(attempts, len(data) - 1)):
                print('sample {0}:'.format(i + 1))
                feats = [float(f) for f in data[i + 1].split(',')]

                x = SMTExplainer(formula, zip(inputs, feats), outputs, names,
                        solver, verb)

                x.explain(smallest)
                xlen.append(len(x.rhypos))
                time.append(x.time)

            print('\nxlen: {0} avg; {1} min; {2} max;'.format(sum(xlen) / float(len(xlen)),
                min(xlen), max(xlen)))

            print('\ntime: {0:.2f} avg; {1:.2f} min; {2:.2f} max;'.format(sum(time) / float(len(time)),
                min(time), max(time)))

        else:  # cplex
            ilp, inputs, outputs, data = parse_lpfile(files[0])

            # feature names
            names = data[0].split(',')

            datainst = [int(float(v)) for v in data[dataid + 1].split(',')]

            if not free:
                free = list(range(len(inputs)))

            pmap = {inputs[p]: p for p in free}

            # hitting set enumerator
            h = prepare_hitman(free, inputs, intervals, htype)

            # ILP-based explainer
            x = ILPExplainer(ilp, inputs, outputs, names, datainst, free, \
                    compile_, verb)

            expls, coexs = compile_classifier(h, x, inputs, pmap, intervals,
                    verb)

            if expls and coexs:
                # ee2 = sorted([set(e) for e in expls], key=lambda x: len(x))
                # cc2 = sorted([set(c) for c in coexs], key=lambda x: len(x))

                # for i, e in enumerate(ee2):
                #     for j in range(i + 1, len(ee2)):
                #         if e.issubset(ee2[j]):
                #             print('failed explanation!')
                #             print(i, [l[0] for l in ee2[i]])
                #             print(j, [l[0] for l in ee2[j]])

                # for i, c in enumerate(cc2):
                #     for j in range(i + 1, len(cc2)):
                #         if c.issubset(cc2[j]):
                #             print('failed counterexample!')
                #             print(i, [l[0] for l in cc2[i]])
                #             print(j, [l[0] for l in cc2[j]])

                print('')
                print('# pfree:', len(free))
                print('# expls:', len(expls))
                print('# coexs:', len(coexs))
                print('')
                print('min expl:', len(min(expls, key=lambda x: len(x))))
                print('max expl:', len(max(expls, key=lambda x: len(x))))

                elens = list(map(lambda x: len(x), expls))
                print('avg expl: {0:.2f}'.format(float(sum(elens)) / len(elens)))

                print('')
                print('compiled class:', x.compile, '({0})'.format(compile_))

                if save:
                    x.save_image(datainst, expls, pmap, set(free), min(elens), dataid, compile_)
