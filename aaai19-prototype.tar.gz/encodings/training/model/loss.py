import torch.nn.functional as F


def my_loss(y_input, y_target):
    return F.nll_loss(y_input, y_target)

def NLL_loss(y_input, y_target):
    return F.nll_loss(y_input, y_target)

def BCE_loss(y_input, y_target):
    return F.binary_cross_entropy(y_input, y_target)

def cross_entropy_loss(y_input, y_target):
    return F.cross_entropy(y_input, y_target)
