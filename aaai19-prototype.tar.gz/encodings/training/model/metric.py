import numpy as np


def my_metric(y_input, y_target):
    assert len(y_input) == len(y_target)
    correct = 0
    for y0, y1 in zip(y_input, y_target):
        if np.array_equal(y0, y1):
            correct += 1
    return correct / len(y_input)

def my_metric_per_class(y_input, y_target):
    assert len(y_input) == len(y_target)
    correct = 0
    per_target = {} 
    per_target_total = {} 
    for y0, y1 in zip(y_input, y_target):        
        if (y1 not in per_target_total):
            per_target_total[y1] = 0
        else:
            per_target_total[y1] += 1
            
        if np.array_equal(y0, y1):           
            correct += 1
            if (y1 not in per_target):
                per_target[y1] = 0
            else:
                per_target[y1] +=1
    
    for y0, y1 in zip(per_target, per_target_total):            
        per_target[y0] =  per_target[y0]/per_target_total[y0]
    
    return  per_target


def my_metric2(y_input, y_target):
    assert len(y_input) == len(y_target)
    correct = 0
    for y0, y1 in zip(y_input, y_target):
        if np.array_equal(y0, y1):
            correct += 1
    return correct / len(y_input) * 2
