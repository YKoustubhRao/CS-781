from utils import *
import torch

from base import BaseModel
import torch.nn as nn
import torch.nn.functional as F
from pysmt.shortcuts import Symbol, LE, GE, TRUE, Real, Bool, Int, And, Equals, Plus, Solver, Times, Equals, Implies, Not, is_sat, get_model, to_smtlib,write_smtlib
import cplex

class SimpleDatasetsModel(BaseModel, object):
    def __init__(self, config):
        super(SimpleDatasetsModel, self).__init__(config)

    def ilp_encode(self, ilpsolver, input_type, min_input_value, max_input_value):
        self.ilp_vars_info = {}
        switch_max_off = True
        for  id_logic_layer, block in self.logical_blocks.items():

            ln = block[1]
            input_sz =  ln.weight.shape[1]
            output_sz =  ln.weight.shape[0]
            #print(input_sz, output_sz)
            #form input variables
            is_special_vars = None
            if (id_logic_layer == 0):
                input_names = ilpsolver.add_variables_vec_bounds(label = "x",
                                                ids = [id_logic_layer],
                                                obj = 0,
                                                lb = min_input_value,
                                                ub = max_input_value,
                                                type = input_type,
                                                sz = input_sz)
                ilpsolver.store_ilp_var_info(self.ilp_vars_info, SMT_LABELED_X_VARS + str(id_logic_layer), input_names, is_special_vars = INPUT_VARS_TAG)
            else:
                input_names = output_names

            #print("input_names", input_names)
            #form output variables

            if (block[0] == LOGICAL_BLOCK_LIN_RELU): # encode lin+relu
                output_names = ilpsolver.add_variables(label = SMT_LABELED_X_VARS,
                                                 ids = [id_logic_layer + 1],
                                                 obj = 0,
                                                 lb = 0,
                                                 ub = cplex.infinity,
                                                 type = ilpsolver.solver.variables.type.continuous,
                                                 sz = output_sz)

                if (id_logic_layer == len(self.logical_blocks) - 1):
                    is_special_vars = OUTPUT_VARS_TAG

                ilpsolver.store_ilp_var_info(self.ilp_vars_info, SMT_LABELED_X_VARS + str(id_logic_layer + 1), output_names, is_special_vars =  is_special_vars)
                #print("output_names", output_names)

                #form s variables
                s_names = ilpsolver.add_variables(label = SMT_LABELED_S_VARS,
                                            ids = [id_logic_layer],
                                            obj = 0,
                                            lb = 0,
                                            ub = cplex.infinity,
                                            type = ilpsolver.solver.variables.type.continuous,
                                            sz = output_sz)
                ilpsolver.store_ilp_var_info(self.ilp_vars_info, SMT_LABELED_S_VARS + str(id_logic_layer), s_names)
                #print("s", s_names)

                #form z variables
                z_names = ilpsolver.add_variables(label = SMT_LABELED_Z_VARS,
                                            ids = [id_logic_layer],
                                            obj = 0,
                                            lb = 0,
                                            ub = 1,
                                            type = ilpsolver.solver.variables.type.binary,
                                            sz = output_sz)
                ilpsolver.store_ilp_var_info(self.ilp_vars_info, SMT_LABELED_Z_VARS + str(id_logic_layer), z_names)
                #print("z", z_names)
                self.encode_linear_relu_layer(ln,
                                          ilpsolver,
                                          x = input_names,
                                          y = output_names,
                                          s = s_names,
                                          z = z_names,
                                          tag = "Layer_{}_{}_lin".format(id_logic_layer, id_logic_layer+1))

            if (block[0] == LOGICAL_BLOCK_LIN): # encode lin
                output_names = ilpsolver.add_variables(label = SMT_LABELED_X_VARS,
                                                 ids = [id_logic_layer + 1],
                                                 obj = 0,
                                                 lb = -cplex.infinity,
                                                 ub = cplex.infinity,
                                                 type = ilpsolver.solver.variables.type.continuous,
                                                 sz = output_sz)

                if(switch_max_off):
                    is_special_vars = OUTPUT_VARS_TAG
                ilpsolver.store_ilp_var_info(self.ilp_vars_info, SMT_LABELED_X_VARS + str(id_logic_layer + 1), output_names, is_special_vars =  is_special_vars)
                #print("output_names", output_names)

                self.encode_linear_layer(ln,
                                         ilpsolver,
                                         input_names,
                                         output_names,
                                         tag = "Layer_{}_{}_lin".format(id_logic_layer, id_logic_layer+1))



    def smt_encode(self, smt, input_type, min_input_value, max_input_value):
        self.smt_vars_info = {}
        switch_max_off = True
        for  id_logic_layer, block in self.logical_blocks.items():

            ln = block[1]
            input_sz =  ln.weight.shape[1]
            output_sz =  ln.weight.shape[0]
            #print(input_sz, output_sz)
            #form input variables
            is_special_vars = None
            if (id_logic_layer == 0):
                input_names = smt.add_variables_vec_bounds(label = "x",
                                                ids = [id_logic_layer],
                                                obj = 0,
                                                lb = min_input_value,
                                                ub = max_input_value,
                                                type = input_type,
                                                sz = input_sz)
                smt.store_smt_var_info(self.smt_vars_info, SMT_LABELED_X_VARS + str(id_logic_layer), input_names, is_special_vars = INPUT_VARS_TAG)
            else:
                input_names = output_names

            #print("input_names", input_names)
            #form output variables


            if (block[0] == LOGICAL_BLOCK_LIN_RELU): # encode lin+relu
                output_names = smt.add_variables(label = SMT_LABELED_X_VARS,
                                                 ids = [id_logic_layer + 1],
                                                 obj = 0,
                                                 lb = 0,
                                                 ub = None,                                                  
                                                 type = TYPE_SMT_REAL,
                                                 sz = output_sz)

                if (id_logic_layer == len(self.logical_blocks) - 1):
                    is_special_vars = OUTPUT_VARS_TAG

                smt.store_smt_var_info(self.smt_vars_info, SMT_LABELED_X_VARS + str(id_logic_layer + 1), output_names, is_special_vars =  is_special_vars)
                #print("output_names", output_names)


                #form s variables
                s_names = smt.add_variables(label = SMT_LABELED_S_VARS,
                                            ids = [id_logic_layer],
                                            obj = 0,
                                            lb = 0,
                                            ub = None,
                                            type = TYPE_SMT_REAL,
                                            sz = output_sz)
                smt.store_smt_var_info(self.smt_vars_info, SMT_LABELED_S_VARS + str(id_logic_layer), s_names)
                #print("s", s_names)

                #form z variables
                z_names = smt.add_variables(label = SMT_LABELED_Z_VARS,
                                            ids = [id_logic_layer],
                                            obj = 0,
                                            lb = 0,
                                            ub = None,
                                            type = TYPE_SMT_BOOL,
                                            sz = output_sz)
                smt.store_smt_var_info(self.smt_vars_info, SMT_LABELED_Z_VARS + str(id_logic_layer), z_names)
                #print("z", z_names)
                self.encode_linear_relu_layer(ln,
                                          smt,
                                          x = input_names,
                                          y = output_names,
                                          s = s_names,
                                          z = z_names,
                                          tag = "Layer_{}_{}_lin".format(id_logic_layer, id_logic_layer+1))

            if (block[0] == LOGICAL_BLOCK_LIN): # encode lin
                output_names = smt.add_variables(label = SMT_LABELED_X_VARS,
                                                 ids = [id_logic_layer + 1],
                                                 obj = 0,
                                                 lb = None,
                                                 ub = None,
                                                 type = TYPE_SMT_REAL,
                                                 sz = output_sz)

                if(switch_max_off):
                    is_special_vars = OUTPUT_VARS_TAG
                smt.store_smt_var_info(self.smt_vars_info, SMT_LABELED_X_VARS + str(id_logic_layer + 1), output_names, is_special_vars =  is_special_vars)
                #print("output_names", output_names)

                self.encode_linear_layer(ln,
                                         smt,
                                         input_names,
                                         output_names,
                                         tag = "Layer_{}_{}_lin".format(id_logic_layer, id_logic_layer+1))

        id_logic_layer = len(self.logical_blocks)

        if(not switch_max_off):

            #max function
            max_value_names = smt.add_variables(label = SMT_LABELED_MAX_VALUE_VARS,
                                                     ids = [id_logic_layer],
                                                     obj = 0,
                                                     lb = None,
                                                     ub = None,
                                                     type = TYPE_SMT_REAL,
                                                     sz = 1)
            smt.store_smt_var_info(self.smt_vars_info, SMT_LABELED_MAX_VALUE_VARS + str(id_logic_layer), max_value_names)
            smt.add_max_constraint(output_names, max_value_names[0])

            #classifier function
            is_special_vars = OUTPUT_VARS_TAG
            class_names = smt.add_variables(label = SMT_LABELED_CLASS_VARS,
                                                     ids = [id_logic_layer],
                                                     obj = 0,
                                                     lb = None,
                                                     ub = None,
                                                     type = TYPE_SMT_INT,
                                                     sz = 1)
            smt.store_smt_var_info(self.smt_vars_info, SMT_LABELED_CLASS_VARS + str(id_logic_layer), class_names, is_special_vars =  is_special_vars)
            smt.add_classification_constraint(output_names, max_value_names[0], class_names[0])


# class DiabetsModel(SimpleDatasetsModel, object):
#     def __init__(self, config):
#         super(DiabetsModel, self).__init__(config)
#         self.config = config
#         self.l1 = torch.nn.Linear(config['inputs'][0], config['layers'][0])
# #        self.l2 = torch.nn.Linear(10, 10)
#         #self.l3 = torch.nn.Linear(10, config['outputs'][0])
#         self.l2 = torch.nn.Linear(config['layers'][0], config['outputs'][0])
#         self.relu = torch.nn.ReLU()
#         self.logical_blocks  =  {}
#
#         self.logical_blocks[0] = [LOGICAL_BLOCK_LIN_RELU, self.l1]
#         #self.logical_blocks[1] = [LOGICAL_BLOCK_LIN_RELU, self.l2]
#         self.logical_blocks[1] = [LOGICAL_BLOCK_LIN, self.l2]
#         #self.logical_blocks[2] = [LOGICAL_BLOCK_LIN, self.l3]
#
#     def forward(self, x):
#         out1 = self.relu(self.l1(x))
#         #out2 = self.relu(self.l2(out1))
#         y_pred = self.l2(out1)
#         return  F.log_softmax(y_pred, dim=1)
#
#     def forward_no_soft_max(self, x):
#         out1 = self.relu(self.l1(x))
#         #out2 = self.relu(self.l2(out1))
#         y_pred = self.l2(out1)
#         #y_pred = self.l2(out1)
#         return  y_pred[0], [x[0], out1[0], y_pred[0]] #out2[0],
#
#
# class YeastModel(SimpleDatasetsModel, object):
#     def __init__(self, config):
#         super(YeastModel, self).__init__(config)
#         self.config = config
#         self.l1 = torch.nn.Linear(8, 20)
#         self.l2 = torch.nn.Linear(20, 20)
#         self.l3 = torch.nn.Linear(20, 9)
#         self.relu = torch.nn.ReLU()
#         self.logical_blocks  =  {}
#
#         self.logical_blocks[0] = [LOGICAL_BLOCK_LIN_RELU, self.l1]
#         self.logical_blocks[1] = [LOGICAL_BLOCK_LIN_RELU, self.l2]
#         self.logical_blocks[2] = [LOGICAL_BLOCK_LIN, self.l3]
#         #self.logical_blocks[2] = [LOGICAL_BLOCK_LIN, self.l3]
#
#     def forward(self, x):
#         out1 = self.relu(self.l1(x))
#         out2 = self.relu(self.l2(out1))
#         y_pred = self.l3(out2)
#         return  F.log_softmax(y_pred, dim=1)
#
#     def forward_no_soft_max(self, x):
#         out1 = self.relu(self.l1(x))
#         out2 = self.relu(self.l2(out1))
#         y_pred = self.l3(out2)
#         #y_pred = self.l2(out1)
#         return  y_pred[0], [x[0], out1[0], out2[0], y_pred[0]]

# class AppendicitisModel(SimpleDatasetsModel, object):
#     def __init__(self, config):
#         super(AppendicitisModel, self).__init__(config)
#         self.config = config
#         self.l1 = torch.nn.Linear(config['inputs'][0], config['layers'][0])
#         #self.l2 = torch.nn.Linear(5, 5)
#         self.l2 = torch.nn.Linear(config['layers'][0], config['outputs'][0])
#         self.relu = torch.nn.ReLU()
#         self.logical_blocks  =  {}
#
#         self.logical_blocks[0] = [LOGICAL_BLOCK_LIN_RELU, self.l1]
#         self.logical_blocks[1] = [LOGICAL_BLOCK_LIN, self.l2]
#
#         #self.logical_blocks[1] = [LOGICAL_BLOCK_LIN_RELU, self.l2]
#         #self.logical_blocks[2] = [LOGICAL_BLOCK_LIN, self.l3]
#         #self.logical_blocks[2] = [LOGICAL_BLOCK_LIN, self.l3]
#
#     def forward(self, x):
#         out1 = self.relu(self.l1(x))
#         y_pred = self.l2(out1)
#         return  F.log_softmax(y_pred, dim=1)
#
#     def forward_no_soft_max(self, x):
#         out1 = self.relu(self.l1(x))
#         y_pred = self.l2(out1)
#         return  y_pred[0], [x[0], out1[0], y_pred[0]]
#
# class Heart_statlogModel(SimpleDatasetsModel, object):
#     def __init__(self, config):
#         super(Heart_statlogModel, self).__init__(config)
#         self.config = config
#         self.l1 = torch.nn.Linear(config['inputs'][0], config['layers'][0])
#         self.l2 = torch.nn.Linear(config['layers'][0], config['outputs'][0])
#         self.relu = torch.nn.ReLU()
#         self.logical_blocks  =  {}
#
#         self.logical_blocks[0] = [LOGICAL_BLOCK_LIN_RELU, self.l1]
#         self.logical_blocks[1] = [LOGICAL_BLOCK_LIN, self.l2]
#
#
#     def forward(self, x):
#         out1 = self.relu(self.l1(x))
#         y_pred = self.l2(out1)
#         return  F.log_softmax(y_pred, dim=1)
#
#     def forward_no_soft_max(self, x):
#         out1 = self.relu(self.l1(x))
#         y_pred = self.l2(out1)
#         return  y_pred[0], [x[0], out1[0], y_pred[0]]

class BiasedConsistentDatasetsModel(SimpleDatasetsModel, object):
    def __init__(self, config):
        super(BiasedConsistentDatasetsModel, self).__init__(config)
        self.config = config
        self.l1 = torch.nn.Linear(config['model']['inputs'][0], config['model']['layers'][0])
        self.l2 = torch.nn.Linear(config['model']['layers'][0], config['model']['outputs'][0])
        self.relu = torch.nn.ReLU()
        self.logical_blocks  =  {}

        self.logical_blocks[0] = [LOGICAL_BLOCK_LIN_RELU, self.l1]
        self.logical_blocks[1] = [LOGICAL_BLOCK_LIN, self.l2]


    def forward(self, x):
        out1 = self.relu(self.l1(x))
        y_pred = self.l2(out1)
        return  F.log_softmax(y_pred, dim=1)

    def forward_no_soft_max(self, x):
        out1 = self.relu(self.l1(x))
        y_pred = self.l2(out1)
        return  y_pred[0], [x[0], out1[0], y_pred[0]]

class MnistDatasetsModel(SimpleDatasetsModel, object):
    def __init__(self, config):
        super(MnistDatasetsModel, self).__init__(config)
        self.config = config        
        self.config['model']['inputs'][0] = config['data_loader']['side']*config['data_loader']['side']
        self.l1 = torch.nn.Linear(config['model']['inputs'][0], config['model']['layers'][0])
        self.l2 = torch.nn.Linear(config['model']['layers'][0], config['model']['outputs'][0])
        self.relu = torch.nn.ReLU()
        self.logical_blocks  =  {}

        self.logical_blocks[0] = [LOGICAL_BLOCK_LIN_RELU, self.l1]
        self.logical_blocks[1] = [LOGICAL_BLOCK_LIN, self.l2]


    def forward(self, x):
        #print(x.shape)
        #x = x.view(x.shape[0], -1)
        out1 = self.relu(self.l1(x))
        y_pred = self.l2(out1)
        return  F.log_softmax(y_pred, dim=1)

    def forward_no_soft_max(self, x):
        #x = x.view(x.shape[0], -1)
        out1 = self.relu(self.l1(x))
        y_pred = self.l2(out1)
        return  y_pred[0], [x[0], out1[0], y_pred[0]]
