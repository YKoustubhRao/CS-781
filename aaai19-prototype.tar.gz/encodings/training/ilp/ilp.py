#!/usr/bin/env python
#-*- coding:utf-8 -*-

import os
import json
import logging
import argparse
import sys
import numpy as np
from utils import *

import cplex
from cplex.exceptions import CplexError


class ILPSolver:
    def __init__(self, save_file_name = None):
        self.solver = cplex.Cplex()
        self.save_file_name = save_file_name
        self.inputs = {}
        self.outputs = {}

    def store_ilp_var_info(self, ilp_dict, label, vars_names, is_special_vars = None):
        ilp_dict[label] = vars_names
        if (is_special_vars == INPUT_VARS_TAG):
            self.inputs = vars_names
        if (is_special_vars == OUTPUT_VARS_TAG):
            self.outputs = vars_names
        if (is_special_vars == BIN_DOMAIN_VARS_TAG):
            self.bin_domains = vars_names
    def form_var_name(self, tag, ids):
        for id in ids:
            tag = tag + "_" + str(id)
        return tag+"$"

    def add_variables(self, label, ids,  obj, lb, ub, type, sz):
        names = [""] * sz
        for i in range(sz):
           names[i] = self.form_var_name(label,   np.append(ids, [i]))

        objective = [obj] * sz
        lower_bounds = [lb] * sz
        upper_bounds = [ub] * sz
        types = [type] * sz

        #print(objective, lower_bounds, upper_bounds, names)
        self.solver.variables.add( obj =objective,
                              lb =lower_bounds,
                              ub =upper_bounds,
                              names = names,
                              types = types)

        return names

    def add_variables_vec_bounds(self, label, ids,  obj, lb, ub, type, sz):
        names = [""] * sz
        for i in range(sz):
           names[i] = self.form_var_name(label,   np.append(ids, [i]))

        objective = [obj] * sz
        lower_bounds = [float(i) for i in lb]
        upper_bounds = [float(i) for i in ub]
        types = [type] * sz

        self.solver.variables.add( obj =objective,
                              lb =lower_bounds,
                              ub =upper_bounds,
                              names = names,
                              types = types)
        return names
    def add_variables_vec_obj(self, label, ids,  obj, lb, ub, type, sz):
        names = [""] * sz
        for i in range(sz):
           names[i] = self.form_var_name(label,   np.append(ids, [i]))

        objective = [float(i) for i in obj]
        lower_bounds = [lb] * sz
        upper_bounds = [ub] * sz
        types = [type] * sz


        self.solver.variables.add( obj =objective,
                              lb =lower_bounds,
                              ub =upper_bounds,
                              names = names,
                              types = types)
        return names

    def add_linear_constraint(self, vars, coefs, rhs, senses, tag):
        #print(vars, coefs, rhs, senses, tag)
        self.solver.linear_constraints.add( rhs = rhs,
                                        senses = [senses],
                                        lin_expr = [[vars, coefs]],
                                        names = [tag])

    def add_indicator_constraint_simple(self, indicator_vars, vars, coefs, rhs, senses, complemented, tag):
        self.solver.indicator_constraints.add(indvar = indicator_vars,
                       complemented = complemented,
                       rhs = rhs,
                       sense = senses,
                       lin_expr = [vars, coefs],
                       name = tag)

    def add_set_intreval_domain(self, var, idx,  binary_values, e, bd_name):
        vars_sz = 1

        tag = "domain"
        for i, bv in enumerate(binary_values):
                #bd_names = 1 → var =  value_1
                ind_vars = bd_name
                vars = [var]
                rhs = bv+e
                coefs = [1]
                tag_con = tag + "_ind_1_" + str(i) + "_"+ str(idx)
                self.add_indicator_constraint_simple(
                                                   indicator_vars = ind_vars,
                                                   vars = vars,
                                                   coefs = coefs,
                                                   rhs = rhs,
                                                   senses = 'L',
                                                   complemented = i,
                                                   tag = tag_con)
#
                rhs = bv-e
                tag_con = tag + "_ind_2_" + str(i) + "_"+ str(idx)
                self.add_indicator_constraint_simple(
                                                   indicator_vars = ind_vars,
                                                   vars = vars,
                                                   coefs = coefs,
                                                   rhs = rhs,
                                                   senses = 'G',
                                                   complemented = i,
                                                   tag = tag_con)
