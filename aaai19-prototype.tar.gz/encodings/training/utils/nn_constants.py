
#######################
LOGICAL_BLOCK_LIN_RELU = "linrelu"
LOGICAL_BLOCK_LIN = "lin"


###################3
TYPE_SMT_REAL = "Real"
TYPE_SMT_INT  = "Int"
TYPE_SMT_BOOL = "Bool"
SMT_LABELED_X_VARS = "x"
SMT_LABELED_S_VARS = "s"
SMT_LABELED_Z_VARS = "z"
SMT_LABELED_BIN_DOMAIN_VARS = "bd"
SMT_LABELED_MAX_VALUE_VARS = "m"
SMT_LABELED_CLASS_VARS = "c"

#########################

INPUT_VARS_TAG = "inputs"
OUTPUT_VARS_TAG = "outputs"
BIN_DOMAIN_VARS_TAG = "bindomain_switchers"


ARG_ENCODING_SMT = "smt"
ARG_ENCODING_ILP = "ilp"