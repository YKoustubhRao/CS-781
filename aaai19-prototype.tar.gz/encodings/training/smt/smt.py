#!/usr/bin/env python
#-*- coding:utf-8 -*-

import numpy as np
import torch
from base import BaseEncoder
from pysmt.shortcuts import Symbol, LE, GE, TRUE, Real, Bool, Int, And, Or, Equals, Plus, Solver, Times, Equals, Implies, Not, Max, Ite, ToReal
from pysmt.typing import INT, REAL, BOOL
from utils import *

class SMTEncoding:
    def __init__(self, file_name = None):
        self.variables = {}
        self.inputs = {}
        self.outputs = {}
        self.smt_dict = {}
        self.formula =  None
    def store_smt_var_info(self, smt_dict, label, vars_names, is_special_vars = None):
        self.smt_dict[label] = vars_names
        if (is_special_vars == INPUT_VARS_TAG):
            self.inputs = vars_names
        if (is_special_vars == OUTPUT_VARS_TAG):
            self.outputs = vars_names

    def form_var_name(self, tag, ids):
        for id in ids:
            tag = tag + "_" + str(id)
        return tag+"_"

    def smt_and(self, a ,b):
        if (a is None)  and  (b is None):
            return None
        if (a is None):
            return b
        if (b is None):
            return a
        return And(a,b)

    def set_domain(self, var, lb, ub, type):
        domain = TRUE()

        if(lb is not None):
            if (type == TYPE_SMT_INT):
                domain = self.smt_and(domain, LE(Int(int(ub)), var))

            if (type  ==  TYPE_SMT_REAL):
                domain = self.smt_and(domain, LE(Real(float(lb)), var))
        if(ub is not None):
            if (type == TYPE_SMT_INT):
                domain = self.smt_and(domain, GE(Int(int(ub)), var))
            if (type  ==  TYPE_SMT_REAL):
                domain = self.smt_and(domain,   GE(Real(float(ub)), var))
        #print(domain)
        return domain

    def add_variables(self, label, ids,  obj, lb, ub, type, sz):
        names = [""] * sz
        for i in range(sz):
           names[i] = self.form_var_name(label,   np.append(ids, [i]))

           if (type == TYPE_SMT_INT):
               var  =  Symbol(names[i], INT)
           if (type == TYPE_SMT_BOOL ):
               var  =  Symbol(names[i], BOOL)
           if (type  ==  TYPE_SMT_REAL):
               var  =  Symbol(names[i], REAL)

           domain = self.set_domain(var, lb, ub, type)
           self.formula = self.smt_and(self.formula,  domain)
           self.variables[names[i]] = var
        return names

    def add_variables_vec_bounds(self, label, ids,  obj, lb, ub, type, sz):
        names = [""] * sz
        for i in range(sz):
           names[i] = self.form_var_name(label,   np.append(ids, [i]))

           if (type == TYPE_SMT_INT):
               var  =  Symbol(names[i], INT)
           if (type == TYPE_SMT_BOOL ):
               var  =  Symbol(names[i], BOOL)
           if (type  ==  TYPE_SMT_REAL):
               var  =  Symbol(names[i], REAL)

           domain = self.set_domain(var, lb[i], ub[i], type)
           self.formula = self.smt_and(self.formula,  domain)
           self.variables[names[i]] = var
        return names


    def add_linear_constraint(self, vars, coefs, rhs, senses, tag):

        # form variables with coeffients
        sz = len(vars)
        terms_exprs = [""] * sz

        for i in range(sz):
            var = self.variables[vars[i]]
            terms_exprs[i] = Times(ToReal(var), Real(float(coefs[i])))

        lhs =  Plus(terms_exprs)
        if (senses == 'E'):
            le = Equals(lhs, Real(float(rhs[0])))
        else:
            assert(False)
        self.formula = self.smt_and(self.formula,  le)
        #print(le)
        return le

    def add_max_constraint(self, vars, max_var):
        #print(vars, max_var)

        mvar =  self.variables[max_var]

        sz = len(vars)
        terms_exprs = [""] * sz
        for i in range(sz):
            var = self.variables[vars[i]]
            terms_exprs[i] = var

        maxexpr =  Max(terms_exprs)
        mexp = Equals(mvar, maxexpr)
        self.formula = self.smt_and(self.formula,  mexp)
        #print(mexp)
        return mexp

    def add_classification_constraint(self, vars, max_var, class_var):
        #print(vars, max_var, class_var)

        mvar =  self.variables[max_var]
        cvar =  self.variables[class_var]

        sz = len(vars)
        terms_exprs = [""] * sz

        var = self.variables[vars[sz - 1]]
        #print(var, mvar, cvar)
        terms_exprs[sz - 1] = Ite(Equals(var, mvar), Equals(cvar, Int(int(sz-1))), TRUE())
        #print(terms_exprs[sz - 1], sz)

        rng = range(sz)
        rrng = reversed(rng[:-1])
        for i in rrng:
            var = self.variables[vars[i]]
            #print(i, terms_exprs[i+1])
            terms_exprs[i] = Ite(Equals(var, mvar), Equals(cvar, Int(i)), terms_exprs[i+1])

        class_expr =  terms_exprs[0]
        self.formula = self.smt_and(self.formula,  class_expr)
        #print(class_expr)
        #exit()
        return class_expr


    def add_indicator_constraint_simple(self, indicator_vars, vars, coefs, rhs, senses, complemented, tag):
        #z = a → x ? b
        z =  self.variables[indicator_vars]

        assert(len(vars) == 1)
        x = self.variables[vars[0]]

        exp_right = {}
        if (senses == "L"):
            exp_right = LE(x, Real(rhs))
        elif (senses == "R"):
            exp_right = GE(x, Real(rhs))
        else:
            assert(False)


        if (complemented == 1):
            z = Not(z)

        imply = Implies( z,
                         exp_right)
        self.formula = self.smt_and(self.formula,
                     imply
                     )
        #print(imply)
        return imply

    def add_set_intreval_domain(self, var, values, e):
        sz = len(values)
        terms_exprs = [""] * sz
        var = self.variables[var]
        for i in range(sz):
            value = values[i]
            #print(value - e, var)
            terms_exprs[i] = And(LE( Real(float(value - e)), var), GE(Real(float(value + e)), var))
            #print(LE( Real(float(value - e)), var), value - e)
            #print( GE(Real(float(value + e)), var), value+ e)
            #exit()
        expr = Or(terms_exprs)
        self.formula = self.smt_and(self.formula,  expr)
