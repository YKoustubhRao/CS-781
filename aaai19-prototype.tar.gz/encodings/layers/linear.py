from __future__ import print_function, division
import os
import argparse
import os
import numpy as np
from parser import *
from con2cnf import *
from utils import *

import math 
import string


class Linear(object):
    """A definition of the linear layer:
    
    Attributes:
        number of rows:
        number of cols: 
    """
    def __init__(self, id, nb_rows, nb_cols):        
        self.id         = id
        self.next_lin_id    = id+2
        self.nb_rows    = nb_rows
        self.nb_cols    = nb_cols        
        self.name       = NAME_LINEAR_LAYER_ID
        
        self.use_reduction_a = False
        
        self.sym_a      = [[0 for i in range(self.nb_cols)] for j in range(self.nb_rows)] 
        self.a          = [[0 for i in range(self.nb_cols)] for j in range(self.nb_rows)]
        self.sym_bias   = [0 for i in range(self.nb_rows)]
        self.bias       = [0 for i in range(self.nb_rows)]
        
        # need to simulate a =0 with an extra variable
        self.sym_r      = [[0 for i in range(self.nb_cols)] for j in range(self.nb_rows)] 
        self.r          = [[0 for i in range(self.nb_cols)] for j in range(self.nb_rows)]

        for i in range(0, self.nb_rows):
            bias_id =   create_indexed_variable_name(LAYER_BIAS_VAR_ID,[self.id,i])
            self.sym_bias[i] = bias_id;
            for j in range(0, self.nb_cols):
                a_id =   create_indexed_variable_name(LAYER_VAR_ID,[self.id,i,j])
                self.sym_a[i][j] = a_id;
                r_id =   create_indexed_variable_name(LAYER_REMOVE_A_VAR_ID,[self.id,i,j])
                self.sym_r[i][j] = r_id;
                
        # convert to numpy        
        self.sym_a = np.array(self.sym_a)
        self.a = np.array(self.a)
        self.sym_bias = np.array(self.sym_bias)
        self.bias = np.array(self.bias)

        self.sym_r = np.array(self.sym_r)
        self.r = np.array(self.r)

    def set_a_to_constant(self, value, rows = None):
        for i in range(0, self.nb_rows):
            if (rows is not None):
                if i not in rows:
                    continue;                
            for j in range(0, self.nb_cols):
                self.a[i][j] = value
    def set_r_to_constant(self, value, rows = None):
         for i in range(0, self.nb_rows):
            if (rows is not None):
                if i not in rows:
                    continue;         
            
            for j in range(0, self.nb_cols):
                self.r[i][j] = value
                
    def set_a_from_dictionary_sybmol(self, set_a_sym):
        for (a_sym, value) in set_a_sym.items():
            inds = np.where(self.sym_a == a_sym)
            if not inds[0].size:
                print("Error: an attempt to set a non-existing variable {} by symbol".format(a_sym))
                exit()
            i = int(inds[0])
            j = int(inds[1])
            self.a[i][j] = value

    def is_r_i_j_by_symbol(self, ra_sym):
        inds = np.where(self.sym_r == ra_sym)
        if inds[0].size:
            return True
        return False

    def is_a_i_j_by_symbol(self, ra_sym):
        inds = np.where(self.sym_a == ra_sym)
        if inds[0].size:
            return True
        return False
    
    def set_ra_i_j_by_symbol(self, ra_sym, value):
        inds = np.where(self.sym_a == ra_sym)
        if inds[0].size:
            return self.set_a_i_j_by_symbol(ra_sym)
        inds = np.where(self.sym_r == ra_sym)
        if inds[0].size:
            return self.set_r_i_j_by_symbol(ra_sym)
        print("Error: an attempt to set a non-existing variable {} by symbol".format(ra_sym))
        exit()
    
 
    def set_a_i_j_by_symbol(self, a_sym, value):
        inds = np.where(self.sym_a == a_sym)
        if not inds[0].size:
            print("Error: an attempt to set a non-existing variable {} by symbol".format(a_sym))
            exit()
        i = int(inds[0])
        j = int(inds[1])
        self.a[i][j] = value
        
    def set_r_i_j_by_symbol(self, r_sym, value):
        inds = np.where(self.sym_r == r_sym)
        if not inds[0].size:
            print("Error: an attempt to set a non-existing variable {} by symbol".format(r_sym))
            exit()
        i = int(inds[0])
        j = int(inds[1])
        self.r[i][j] = value

    def get_r_dot_a(self):
        ra = [[0 for i in range(self.nb_cols)] for j in range(self.nb_rows)]
        for i in range(0, self.nb_rows):
            for j in range(0, self.nb_cols):
                ra[i][j] = (1 - self.r[i][j])*self.a[i][j]
        return np.array(ra)

               
    def set_a_i_j(self, i, j, value):
        self.a[i][j] = value
        
    def set_b_i(self, i, value):
        self.bias[i] = value
    
    def get_all_symbols(self, nobias = True, rows = None):
        symbols = []
        
        for i in range(0, self.nb_rows):
            if (rows is not None):
                if i not in rows:
                    continue;      
            for j in range(0, self.nb_cols):
                symbols.append(self.sym_a[i][j])
            if (not nobias):
                symbols.append(self.sym_bias[i])
 
        return symbols

    def get_all_reduction_symbols(self, rows = None):
        symbols = []
        for i in range(0, self.nb_rows):
            if (rows is not None):
                if i not in rows:
                    continue;     
            for j in range(0, self.nb_cols):
                symbols.append(self.sym_r[i][j])
        return symbols

    def get_var_i_j_by_symbol(self, ra_sym):
        inds = np.where(self.sym_a == ra_sym)
        if inds[0].size:
            return self.get_a_i_j_by_symbol(ra_sym)
        inds = np.where(self.sym_r == ra_sym)
        if inds[0].size:
            return self.get_r_i_j_by_symbol(ra_sym)
        print("Error: an attempt to set a non-existing variable {} by symbol".format(ra_sym))
        exit()
    
    def get_a_i_j_by_symbol(self, a_sym):
        inds = np.where(self.sym_a == a_sym)
        if not inds[0].size:
            print("Error: an attempt to set a non-existing variable {} by symbol".format(a_sym))
            exit()
        i = int(inds[0])
        j = int(inds[1])
        return self.a[i][j]
    
    def get_r_i_j_by_symbol(self, r_sym):
        inds = np.where(self.sym_r == r_sym)
        if not inds[0].size:
            print("Error: an attempt to set a non-existing variable {} by symbol".format(r_sym))
            exit()
        i = int(inds[0])
        j = int(inds[1])
        return self.r[i][j]

                
    def __str__(self, nobias = True):
        s = ""    
        if(self.use_reduction_a):
            s = s + "With reduction \n"        
        for i in range(0, self.nb_rows):
            for j in range(0, self.nb_cols):
                if(self.use_reduction_a):
                    s = s + self.sym_a[i][j] + " = " + str(self.a[i][j]*(1-self.r[i][j])).ljust(2) + " "
                else:
                    s = s + self.sym_a[i][j] + " = " + str(self.a[i][j]).ljust(2) + " "
            if (not nobias):    
                s = s + self.sym_bias[i] + " = "  +  str(self.bias[i]).ljust(5) + "\n"
            else:
                s = s + "\n"    
#         
#         s = s + "\n"    
#         if(self.use_reduction_a):
#             for i in range(0, self.nb_rows):
#                 for j in range(0, self.nb_cols):
#                     s = s + self.sym_a[i][j] + " = " + str(self.a[i][j]).ljust(2) + " "
#                 s = s + "\n"    
#         s = s + "\n"                    
#         if(self.use_reduction_a):
#             for i in range(0, self.nb_rows):
#                 for j in range(0, self.nb_cols):
#                     s = s + self.sym_r[i][j] + " = " + str(self.r[i][j]).ljust(2) + " "
#                 s = s + "\n"                        
        return s