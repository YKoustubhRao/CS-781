from __future__ import print_function, division
import os
import argparse
import os
import numpy as np
from parser import *
from con2cnf import *
from utils import *

import math 
import string


class BatchNorm(object):
    """A definition of the bn layer:
    
    Attributes:
        number of rows:
        number of cols: 
    """
    def __init__(self, id,  nb_cols):        
        self.id         = id
        self.nb_cols    = nb_cols
        self.name       = NAME_BN_LAYER_ID

        self.sym_eps   = 0
        self.eps       = 0.0

        self.sym_bias   = [0 for i in range(self.nb_cols)]
        self.bias       = [0.0 for i in range(self.nb_cols)]

        self.sym_weights   = [0 for i in range(self.nb_cols)]
        self.weights       = [0.0 for i in range(self.nb_cols)]
        
        self.sym_runmean   = [0 for i in range(self.nb_cols)]
        self.runmean       = [0.0 for i in range(self.nb_cols)]
        
        self.sym_runvar   = [0 for i in range(self.nb_cols)]
        self.runvar       = [0.0 for i in range(self.nb_cols)]
        
        self.sym_eps = create_indexed_variable_name(LAYER_BN_EPS_ID,[self.id])
        for i in range(0, self.nb_cols):
            self.sym_bias[i] = create_indexed_variable_name(LAYER_BN_BIAS_ID,[self.id,i])
            self.sym_weights[i] = create_indexed_variable_name(LAYER_BN_WEIGHT_ID,[self.id,i])
            self.sym_runmean[i] = create_indexed_variable_name(LAYER_BN_RUNMEAN_ID,[self.id,i])
            self.sym_runvar[i] = create_indexed_variable_name(LAYER_BN_RUNVAR_ID,[self.id,i])
                
        # convert to numpy        
        self.sym_bias   = np.array(self.sym_bias)
        self.bias       = np.array(self.bias)

        self.sym_weights   = np.array(self.sym_weights)
        self.weights       = np.array(self.weights)
        
        self.sym_runmean   = np.array(self.sym_runmean)
        self.runmean       = np.array(self.runmean)
        
        self.sym_runvar   = np.array(self.sym_runvar)
        self.runvar       = np.array(self.runvar)
               
    def set_eps(self,value):
        self.eps = value
        
    def set_bias_i(self, i, value):
        self.bias[i] = value
        
    def set_weight_i(self, i, value):
        self.weights[i] = value    

    def set_runmean_i(self, i, value):
        self.runmean[i] = value    

    def set_runvar_i(self, i, value):
        self.runvar[i] = value    
    
    def get_all_symbols(self, nobias = True):
        symbols = []
        symbols.append(self.sym_eps)
        for i in range(0, self.nb_cols):
            symbols.append(self.sym_bias[i])
            symbols.append(self.sym_weights[i])
            symbols.append(self.sym_runmean[i])
            symbols.append(self.sym_runvar[i])            
        return symbols    
                    
    def __str__(self):
        s = ""    
        s = s + self.sym_eps + " = "+ str(self.eps) + " \n"
        for i in range(0, self.nb_cols):
            s = s + self.sym_bias[i] + " = " + str(self.bias[i]).ljust(10) + " "
            s = s + self.sym_weights[i] + " = " + str(self.weights[i]).ljust(10) + " "
            s = s + self.sym_runmean[i] + " = " + str(self.runmean[i]).ljust(10) + " "
            s = s + self.sym_runvar[i] + " = " + str(self.runvar[i]).ljust(10) + " "
            s = s + "\n"    
        return s