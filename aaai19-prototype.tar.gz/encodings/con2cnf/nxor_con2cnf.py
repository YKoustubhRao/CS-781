from __future__ import print_function, division
import numpy as np
import math 
from utils import *
import string
from con2cnf.con2cnf import *

      
#########################      
# nxor       
#########################
def form_nxor_constraint_name(l,r,c):
    return "{}_l_{}_r_{}_c_{}".format(NXOR_CON_ID, l,r,c)


def nxor_input_reified(dist_output, varids2cnf_varids, x, y, z, constraint_prefix):
    
    var_prefix_local = constraint_prefix
    # x NXOR y <=> z
    # we rewrite it as:
    # 1.  x AND  y =>  z
    # 2. -x AND -y =>  z
    # 3.  x AND -y => -z
    # 4. -x AND  y => -z
    # 5.  z=> ( x AND y) OR (-x AND -y)  
    # 6. -z=> (-x AND y) OR ( x AND -y)    
    
    ###########################################
    # Start encoding
    ###########################################
    # 1.  x AND  y =>  z
    #     -x OR -y OR z    
    # we will replace later
    add_clause(dist_output, varids2cnf_varids, ["-" + x, "-" + y, z])
    
    # 2. -x AND -y =>  z
    # x OR y OR z
    add_clause(dist_output, varids2cnf_varids, [x, y, z])
    # 3.  x AND -y => -z
    #    -x OR y OR -z
    add_clause(dist_output, varids2cnf_varids, ["-" + x, y, "-" + z])

    # 4. -x AND  y => -z
    #    x OR -y OR -z
    add_clause(dist_output, varids2cnf_varids, [x, "-" + y, "-" + z])


    #     introduce new aux variables
    #     t1 <=> x and y    
    #     t2 <=> -x and -y    
    #     t3 <=> -x and y    
    #     t4 <=> x and -y    
    
    t_A_x_y = and_input_reified(dist_output, varids2cnf_varids,  x = x,       y = y, constraint_prefix = var_prefix_local);
    t_A_nx_ny = and_input_reified(dist_output, varids2cnf_varids,x = "-" + x, y = "-" + y, constraint_prefix = var_prefix_local);    
    t_A_nx_y = and_input_reified(dist_output, varids2cnf_varids, x = "-" + x, y = y, constraint_prefix = var_prefix_local);
    t_A_x_ny = and_input_reified(dist_output, varids2cnf_varids, x = x,       y = "-" + y,constraint_prefix = var_prefix_local);    

    # 5.  z=> ( x AND y) OR (-x AND -y)  
    #     -z OR [( x AND y) OR (-x AND -y)]
    #     -z OR ( x AND y) OR (-x AND -y)    

    add_clause(dist_output, varids2cnf_varids, ["-" + z, t_A_x_y, t_A_nx_ny])
    # 6. -z=> (-x AND y) OR ( x AND -y)    
    #   z OR (-x AND y) OR ( x AND -y)          
    add_clause(dist_output, varids2cnf_varids, [z, t_A_nx_y, t_A_x_ny])
