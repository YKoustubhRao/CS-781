from __future__ import print_function, division
import numpy as np
import math 
from utils import *
import string
from con2cnf.con2cnf import *


#########################      
#  unary       
#########################
def form_unary_constraint_name(var_id):
    return "{}_{}".format(UNARY_CON_ID, var_id)



def unary_constraint4bool_var(dist_output, varids2cnf_varids, x, value):
    if (value == 1):
        add_clause(dist_output, varids2cnf_varids, [x])
    else:
        add_clause(dist_output, varids2cnf_varids, ["-" + x])

