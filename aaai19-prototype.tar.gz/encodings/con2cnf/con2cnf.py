from __future__ import print_function, division
import os
import argparse
import os
import pandas as pd

import numpy as np
import math 
from utils import *
import string
from io import IOBase
from numpy import source

def check_var_cnf_id(varids2cnf_varids, varid=None, is_must_be_in=False):
    if (varid == None):
        if (is_must_be_in):
            print("Var is None. Must have had cnf id".format(varid))
            exit()
        else:
            return False
        
    varid = remove_negations_varid(varid)   
    if varid not in varids2cnf_varids:
        if (is_must_be_in):
            print("Var - \"{}\" must have had cnf id".format(varid))
            exit()
        else:
            return False
    return True

def remove_negations_varid(varid):
    return varid.replace("-", "")  

def get_cnf_varid(varids2cnf_varids, varid):
    if varid not in varids2cnf_varids:
        varids2cnf_varids[varid] = len(varids2cnf_varids) + 1
    
    return varids2cnf_varids[varid] 
    

def add_clause(dist_output, varids2cnf_varids,  vars):
    #print("clause:  {}".format(vars))
    dist_type = dist_output[0]
    dist_point = dist_output[1]
    clause = []
    clause_print = []
    for x in vars:
        #check_var_cnf_id(varids2cnf_varids, x, True)
        #print(x, end=' ')
        x = x.replace("--", "")                  
        # FOR LATER         
        clause_print.append(x)
        if (x[:1] != "-"):
            x = varids2cnf_varids[x]
        else:
            x = -varids2cnf_varids[x[1:]]
        clause_print.append("("+str(x)+") ")    
        if (dist_type == CNF_DESTINATION):
            dist_point.write("{} ".format(x))            
        elif (dist_type == LIST_DESTINATION):    
            # we assume that assumptions are added to he solver!      
            clause.append(x)        
        elif (dist_type == SOLVER_DESTINATION):            
            clause.append(x)
            while dist_point.nvars() < abs(x):
                dist_point.new_var()
    #print(clause_print)            
    if (dist_type == CNF_DESTINATION):
        dist_point.write("0\n")
    elif (dist_type == SOLVER_DESTINATION):            
        dist_point.add_clause(clause)
    elif (dist_type == LIST_DESTINATION):
        if (len(clause) > 1):
            print(" Error: assumption is not unary")            
        dist_point.append(clause[0])

def eq(dist_output, varids2cnf_varids, x, y):
    check_var_cnf_id(varids2cnf_varids, x, True)                
    check_var_cnf_id(varids2cnf_varids, y, True)                
    # -x V y
    add_clause(dist_output, varids2cnf_varids, ["-" + x, y])
    # x V -y
    add_clause(dist_output, varids2cnf_varids, [x,"-" +  y])

    
def and_input_reified(dist_output, varids2cnf_varids, x, y, z = None, constraint_prefix = randomword(5)):
    #     introduce new variables
    #     t <=> x and y    
    
    var_prefix_local =  constraint_prefix + TEMP_VAR_ID
    if (z == None):
        t_A_x_y = create_indexed_variable_name(var_prefix_local, [x, y])
        get_cnf_varid(varids2cnf_varids, t_A_x_y)
    else:
        t_A_x_y = z
    cnf_t_A_x_y = varids2cnf_varids[t_A_x_y]
    
    #  t => x and y
    #  -t OR x
    #  -t OR y    
    add_clause(dist_output, varids2cnf_varids, ["-" + t_A_x_y, x])
    add_clause(dist_output, varids2cnf_varids, ["-" + t_A_x_y, y])
    
    #  t or -x or -y
    add_clause(dist_output, varids2cnf_varids, [t_A_x_y, "-" + x, "-" + y])    
    return  t_A_x_y 




