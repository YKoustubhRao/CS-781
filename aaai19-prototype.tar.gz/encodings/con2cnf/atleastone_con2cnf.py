from __future__ import print_function, division
import numpy as np
import math 
from utils import *
import string
from con2cnf.con2cnf import *

#########################      
#  ar least one       
#########################
def form_atleastone_constraint_name(vars_ids):
    print(vars_ids)
    s = ""
    for k in vars_ids:        
        s = s + "{}_".format(k)
    return "{}_{}".format(ATLEASTONE_CON_ID, s)


def atleastone_constraint4bool_var(dist_output, varids2cnf_varids, vars_ids):
    add_clause(dist_output, varids2cnf_varids, vars_ids)

