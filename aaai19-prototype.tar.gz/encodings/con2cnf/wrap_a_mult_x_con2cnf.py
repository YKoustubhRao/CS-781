from __future__ import print_function, division
import numpy as np
import math 
from utils import *
import string
from con2cnf.con2cnf import *

#########################      
# wrap multiplication for model reuduction      
#########################
def form_wrap_a_mult_x_constraint_name(l,r,c):
    return "{}_l_{}_r_{}_c_{}".format(WRAP_A_MULT_X_CON_ID, l,r,c)

def wrap_a_mult_x_input_reified(dist_output, varids2cnf_varids, r, b, w, s, constraint_prefix):
    var_prefix_local = constraint_prefix
    
    ############################################################
    # r_i = 0 AND b_i= 0 -->  w = 0 AND s = 1 
    # r_i = 0 AND b_i= 1 -->  w = 1 AND s = 0 
    # r_i = 1 -->  w = 0 AND s = 0
    # w=0  OR s=0 
    
    ##########################################
    # 1. r_i = 0 AND b_i= 0 -->  w= 0 AND s = 1
    #1.a  -r_i AND -b_i <-> r_0_b_0_id
    r_0_b_0_id = and_input_reified(dist_output, varids2cnf_varids,  x = "-" + r,  y =  "-" + b, constraint_prefix = var_prefix_local);    
    
    #1.b  -w_i AND s_i <-> w_0_s_1_id          
    w_0_s_1_id =  and_input_reified(dist_output, varids2cnf_varids,  x = "-" + w,  y =  s, constraint_prefix = var_prefix_local);
    
    #1.c   - (r_0_b_0_id)  \/ w_0_s_1_id    
    add_clause(dist_output, varids2cnf_varids, ["-" + r_0_b_0_id, w_0_s_1_id])
    
    ##########################################    
    # 2. r_i = 0 AND b_i= 1 --> w = 1 AND s = 0
    #2.a  -r_i AND b_i <-> r_0_b_1_id
    r_0_b_1_id = and_input_reified(dist_output, varids2cnf_varids,  x = "-" + r,  y =  b, constraint_prefix = var_prefix_local);    
    
    #2.b  w_i AND -s_i <-> w_1_s_0_id          
    w_1_s_0_id =  and_input_reified(dist_output, varids2cnf_varids,  x = w,  y = "-"+ s, constraint_prefix = var_prefix_local);
    
    #2.c   - (r_0_b_1_id)  \/ w_1_s_0_id    
    add_clause(dist_output, varids2cnf_varids, ["-" + r_0_b_1_id, w_1_s_0_id])

    ##########################################
    #3 r_i = 1 -->  w = 0 AND s = 0
   
    #3.a  -w_i AND -s_i <-> w_0_s_0_id          
    w_0_s_0_id =  and_input_reified(dist_output, varids2cnf_varids,  x = "-"+ w,  y = "-"+ s, constraint_prefix = var_prefix_local);

    #3.b -r_i OR w_0_s_0_id
    add_clause(dist_output, varids2cnf_varids, ["-" + r, w_0_s_0_id])

    ##########################################
    # w=0  OR s=0 
    add_clause(dist_output, varids2cnf_varids, ["-" + w, "-" + s])

#     
#     var_prefix_local = constraint_prefix
#     # x XOR y <=> z
#     # we rewrite it as:
#     # 1.  x AND  y =>  -z
#     # 2. -x AND -y =>  -z
#     # 3.  x AND -y => z
#     # 4. -x AND  y => z
#     # 5. -z=> ( x AND y) OR (-x AND -y)  
#     # 6. z=> (-x AND y) OR ( x AND -y)    
#     
#     ###########################################
#     # Start encoding
#     ###########################################
#     # 1.  x AND  y =>  -z
#     #     -x OR -y OR -z    
#     # we will replace later
#     add_clause(dist_output, varids2cnf_varids, ["-" + x, "-" + y, "-" + z])
#     
#     # 2. -x AND -y =>  -z
#     # x OR y OR -z
#     add_clause(dist_output, varids2cnf_varids, [x, y, "-" +z])
#     
#     # 3.  x AND -y => z
#     #    -x OR y OR z
#     add_clause(dist_output, varids2cnf_varids, ["-" + x, y,  z])
# 
#     # 4. -x AND  y => z
#     #    x OR -y OR z
#     add_clause(dist_output, varids2cnf_varids, [x, "-" + y, z])
# 
# 
#     #     introduce new aux variables
#     #     t1 <=> x and y    
#     #     t2 <=> -x and -y    
#     #     t3 <=> -x and y    
#     #     t4 <=> x and -y    
#     
#     t_A_x_y = and_input_reified(dist_output, varids2cnf_varids,  x = x,       y = y, constraint_prefix = var_prefix_local);
#     t_A_nx_ny = and_input_reified(dist_output, varids2cnf_varids,x = "-" + x, y = "-" + y, constraint_prefix = var_prefix_local);    
#     t_A_nx_y = and_input_reified(dist_output, varids2cnf_varids, x = "-" + x, y = y, constraint_prefix = var_prefix_local);
#     t_A_x_ny = and_input_reified(dist_output, varids2cnf_varids, x = x,       y = "-" + y,constraint_prefix = var_prefix_local);    
# 
#     # 5.  -z=> ( x AND y) OR (-x AND -y)  
#     #     z OR [( x AND y) OR (-x AND -y)]
#     #     z OR ( x AND y) OR (-x AND -y)    
# 
#     add_clause(dist_output, varids2cnf_varids, [ z, t_A_x_y, t_A_nx_ny])
#     # 6. z=> (-x AND y) OR ( x AND -y)    
#     #   -z OR (-x AND y) OR ( x AND -y)          
#     add_clause(dist_output, varids2cnf_varids, ["-" +z, t_A_nx_y, t_A_x_ny])
