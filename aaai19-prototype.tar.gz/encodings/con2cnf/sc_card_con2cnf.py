from __future__ import print_function, division
import numpy as np
import math 
from utils import *
import string
from con2cnf.con2cnf import *
from con2cnf.unary_con2cnf import *




#########################      
#  linear
#########################    
def form_linear_reified_constraint_name(l,r, c = "*"):
    return "{}_l_{}_r_{}_c_{}".format(LIN_REIFIED_CON_ID, l,r,c)    


def seqcounters4unary_coeff_linear_reified(dist_output, varids2cnf_varids, coeffs, vars_ids, output_var_id, constterm, constraint_prefix):
    #print(">>>>>>>>>>>>>>>>>>> SQ <<<<<<<<<<<<<<<<<<<")
    #print("input variables:")
    #print(vars_ids)
    
    var_prefix_local = constraint_prefix + "_" + SEQCOUNTERS_TEMP_VAR_ID 

    # sum_i=0^n-1 l_i >= C <=> b
    n = len(vars_ids)
    # we iterate over variables and replave -x with (not x - 1) as x  + not x = 1
    #print("linear constraint (input):")
    #print_linear_constraint([coeffs, vars_ids, constterm])
    #print(coeffs)  
    for i in range(0, n):
        if (coeffs[i] < 0):
            coeffs[i] = 1
            vars_ids[i] = "-{}".format(vars_ids[i])         
            constterm = constterm - 1            
    #print("cardinality constraint (transformed):")
    #print_card_constraint([vars_ids, output_var_id, constterm])
  

    x = vars_ids
    k = int(-constterm)
    
    if (k > n):
        print("----> Trivial UNSAT constraint as rhs ({}) > nb vars = ".format(k, n))
        unary_constraint4bool_var(dist_output, varids2cnf_varids, x = output_var_id, value  = 0)
        return     
        
    if (k <= 0):
        # constraint is trivially satisfied 
        print("----> Trivial SAT constraint as rhs ({}) < 0".format(k))
        unary_constraint4bool_var(dist_output, varids2cnf_varids, x = output_var_id, value = 1)          
        return

    if (n == 1):
        # special case
        # we only have 1 var
        # lit >= k <=> b
                
        # if k > 1 then constraint is unsat
        if (k > 1):
            print("---->  Trivial UNSAT constraint as rhs ({}) > nb vars = {}".format(k, n))
            unary_constraint4bool_var(dist_output, varids2cnf_varids, x = output_var_id, value = 0)
        else:
        # otherwsie lit <=>  b    
            print("---->  Trivial case  of equvalnce  -- rhs ({}) ,  nb vars = {}".format(k, n))
            eq(dist_output, varids2cnf_varids, vars_ids[0], output_var_id)
        return

    
    s = [[0] * (k+1) for i in range(n+1)]
    # note that seq counters assume that we have variables from 1..n
    # s[1][1] <=>  x[1]
    # (not x[0] V  s[1][1])
    # (x[0] V  not s[1][1])     
    s[1][1] = create_indexed_variable_name(var_prefix_local, [1, 1])
    get_cnf_varid(varids2cnf_varids, s[1][1])

    # (not x[0] V  s[1][1])
    add_clause(dist_output, varids2cnf_varids, ["-" + x[0], s[1][1]])
    # (x[0] V  not s[1][1])     
    add_clause(dist_output, varids2cnf_varids, [x[0], "-" + s[1][1]])

    # 1 < j <=k
    for j in range(2, k+1):
        #(not s[1][j])
        s[1][j] = create_indexed_variable_name(var_prefix_local, [1, j])
        get_cnf_varid(varids2cnf_varids, s[1][j])
        add_clause(dist_output, varids2cnf_varids, ["-" + s[1][j]])
    #print("after first block s = ", s)
    # 1 < i <= n    
    for i in range(2, n+1):         
        s[i][1] = create_indexed_variable_name(var_prefix_local,[ i, 1])
        get_cnf_varid(varids2cnf_varids, s[i][1])
        
        #s[i][1] <=> x[i-1] \/ s[i-1][1]
        #s[i][1] \/ not x[i-1] 
        #s[i][1] \/ not s[i-1][1]
        #not s[i][1] \/ x[i-1] \/ s[i-1][1]
        
        # (s[i][1] \/ not x[i-1] )        
        add_clause(dist_output, varids2cnf_varids, ["-" + x[i-1], s[i][1]])

        # (s[i][1] \/ not s[i-1][1] )                
        add_clause(dist_output, varids2cnf_varids, ["-" + s[i-1][1], s[i][1]])
        
        # not s[i][1] \/ x[i-1] \/ s[i-1][1]     
        add_clause(dist_output, varids2cnf_varids, ["-" + s[i][1], x[i-1], s[i-1][1]])
    
    for j in range(2, k+1):
        for i in range(j, n+1): 
        # 1 < j <=k
            s[i][j] = create_indexed_variable_name(var_prefix_local, [i, j])
            get_cnf_varid(varids2cnf_varids, s[i][j])
            #print(i,j, s[i][j])
            
            if (i == j):
                # corner case, e.g. we are at s_3,3 and look s_2,3 which must be false 
                s[i-1][j] = create_indexed_variable_name(var_prefix_local, [i-1, j])
                get_cnf_varid(varids2cnf_varids, s[i-1][j])
                add_clause(dist_output, varids2cnf_varids, ["-" + s[i-1][j]])
        
            #s[i][j] <=> (x[i-1] /\ s[i-1][j-1]) \/ s[i-1][j]

            ##############################################
            #s[i][j] <= x[i-1] /\ s[i-1][j-1] \/ s[i-1][j]
            ###############################################
            #s[i][j] \/ not x[i-1] \/ not s[i-1][j-1] 
            #s[i][j] \/ not s[i-1][j]
            #not s[i][j] \/(x[i-1] /\ s[i-1][j-1] \/ s[i-1][j])

            #s[i][j] => x[i-1] /\ s[i-1][j-1] \/ s[i-1][j]
            # not s[i][j] \/ x[i-1]  \/ s[i-1][j]
            # not s[i][j] \/ s[i-1][j-1] \/ s[i-1][j]
            
            
            
            #s[i][j] \/ not x[i-1] \/ not s[i-1][j-1]                
            add_clause(dist_output, varids2cnf_varids, [s[i][j], "-" + x[i-1], "-" + s[i-1][j-1]])
            
            #s[i][j] \/ not s[i-1][j]                
            #print(i-1,j, s[i-1][j])
            add_clause(dist_output, varids2cnf_varids, [s[i][j], "-" + s[i-1][j]])

            #not s[i][j] \/ x[i-1]  \/ s[i-1][j]   
            add_clause(dist_output, varids2cnf_varids, ["-" + s[i][j], x[i-1],  s[i-1][j]])

            #not s[i][j] \/ s[i-1][j-1] \/ s[i-1][j]
            add_clause(dist_output, varids2cnf_varids, ["-" + s[i][j], s[i-1][j-1],  s[i-1][j]])
            
    
    # add reification constraint 
    # s[n][k] = 1 <==> output = 1    
    #print(s[n][k], output_var_id)
    eq(dist_output, varids2cnf_varids, s[n][k], output_var_id)
    #print("final s = ", s)
