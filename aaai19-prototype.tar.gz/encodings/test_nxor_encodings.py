from __future__ import print_function, division
import os
import argparse
import os
import numpy as np
import math 
from utils import *
import string
from con2cnf import *
import random

parser = argparse.ArgumentParser(description='Test NXOR')
parser.add_argument('--nbtest', '-t',  default=100, help='number of tests')
args = parser.parse_args()
args.nbtest = int(args.nbtest)

def test_nxor_input_reified():
    # We test: 
    # x NXOR y <=> z
    cnt = 0
    x_id = "x"
    y_id = "y"
    z_id = "z"
    varids2cnf_varids = {}
    varids2cnf_varids[x_id] = 1;
    varids2cnf_varids[y_id] = 2;
    varids2cnf_varids[z_id] = 3;
    
    temp_file = "test_nxor.txt";
    output_file = "test_nxor.cnf";
    solver_result_file = "solver_res.txt";
   
    project_dir = '/home/nina/workspace/loglearn/'
    while(cnt < args.nbtest):
        print(cnt)
        cnf_file = open(temp_file, 'w')
        cnt += 1
        x = bool(random.getrandbits(1))
        y = bool(random.getrandbits(1))
        z = bool(random.getrandbits(1))
        nxor = bool(x) == bool(y)
        result = bool(z) == bool(nxor)
        
        print("We have x = {}, y = {}, z = {}, result {}".format(x,y,z,result))
        
        # add constraints
        unary_constraint4bool_var(cnf_file, varids2cnf_varids, [x_id, x])
        unary_constraint4bool_var(cnf_file, varids2cnf_varids, [y_id, y])
        unary_constraint4bool_var(cnf_file, varids2cnf_varids, [z_id, z])
        
        nxor_input_reified(cnf_file, varids2cnf_varids, [x_id, y_id, z_id])
        cnf_file.close() 
        add_first_line2cnf(temp_file, output_file, len(varids2cnf_varids))
        
        # execute SAT solver
        os.system(project_dir + '/src/encodings/glucose/glucose_static  -model ' + project_dir + output_file  +  " > " +  project_dir + solver_result_file)
        
        #parse the output of the solver   
        sat_result, model = process_SAT_solver_output(project_dir + solver_result_file)    

        #check if it produced the wright outcome                        
        if (result == True and  sat_result == 'UNSATISFIABLE'):
            print("Invalid encoding, should be SAT")
            exit()
        if (result == False and  sat_result == 'SATISFIABLE'):
            print("Invalid encoding, should be SAT") 
            exit()
        if (result):
            if (x != ( True  if model[varids2cnf_varids[x_id] ] >= 0 else False)):
                print("x gets an invalid value, should be {}, model {}".format(x, model[varids2cnf_varids[x_id]]))
                exit()         
            if (y != ( True  if model[varids2cnf_varids[y_id] ] >= 0 else False)):
                print("y gets an invalid value, should be {}".format(x))
                exit() 
            if (z != ( True  if model[varids2cnf_varids[z_id] ] >= 0 else False)):
                print("z gets an invalid value, should be {}".format(x))
                exit() 
            
    
test_nxor_input_reified()