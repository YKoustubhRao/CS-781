from __future__ import print_function, division
import os
import numpy as np
import itertools
from layers import *

def parse_input(inputfile, focuslabels = None):
    try:
        myfile = open(inputfile, "r+") # or "a+", whatever you need
    except IOError:
        print ("cannot open".format())
        exit()
    with myfile:
        lines = iter(myfile.read().splitlines())
    x = []
    for line in lines:
        if (line[:1] == 'c'):
            continue;   
        if (line[:5] == LABEL_ID): 
            label = int(line.split()[1])
            #print(focuslabels)
            if focuslabels != None:
                back = label
                label = focuslabels.index(label)
                #if (label != back):
                #    exit()
                #print(label)
                            
            
            #print ("read label \n {}".format(label))
        if (line[:5] == INPUT_ID): 
            nbinputs = int(line.split()[1])
            for xi in itertools.islice(lines, nbinputs):                
                x.append(int(xi))
            x = np.array(x)
            #print ("read input \n {}".format(x))
    return x, label

def parse_linear_layer(first_line, lines, nb_layers):
    nbrows = int(first_line.split()[1])
    nbcols = int(first_line.split()[2])            
    L = Linear(nb_layers, nbrows, nbcols)
    i = 0
    for row in itertools.islice(lines, nbrows):
        row =  row.split()
        row = list(map(int, row))
        for j in range(0,nbcols):
            L.set_a_i_j(i, j, row[j])
        L.set_b_i(i, row[-1])        
        i +=1        
    return L

def parse_definition_linear_layer(first_line, nb_layers):
    nbrows = int(first_line.split()[1])
    nbcols = int(first_line.split()[2])            
    L = Linear(nb_layers, nbrows, nbcols)
    return L

def parse_batchnorm_layer(first_line, lines, nb_layers):
    nbcols = int(first_line.split()[1])        
    B = BatchNorm(nb_layers, nbcols)
    # EPS 
    for eps_name in itertools.islice(lines, 1):
        #print(eps_name)
        assert eps_name in SET_BN_EPS_ID
    for eps in itertools.islice(lines, 1):  
        #print(eps)
        eps = float(eps)  
        B.set_eps(eps)
        

    # SET_BN_WEIGHT_ID 
    for weights_name in itertools.islice(lines, 1):
        #print(weights_name)
        assert weights_name in SET_BN_WEIGHT_ID
    for weights in itertools.islice(lines, 1):    
        #print(weights)
        weights =  weights.split()
        weights = list(map(float, weights))
        for i in range(nbcols):
            B.set_weight_i(i, weights[i])
        #weights = list(map(int, weights))

        
    
    # SET_BN_BIAS_ID 
    for bias_name in itertools.islice(lines, 1):
        #print(bias_name)
        assert bias_name in SET_BN_BIAS_ID
    for bias in itertools.islice(lines, 1):    
        bias =  bias.split()
        bias = list(map(float, bias))
        for i in range(nbcols):
            B.set_bias_i(i, bias[i])
        #print(bias)

    # SET_BN_RUNMEAN_ID 
    for runmean_name in itertools.islice(lines, 1):
        #print(runmean_name)
        assert runmean_name in SET_BN_RUNMEAN_ID
    for runmean in itertools.islice(lines, 1):    
        runmean =  runmean.split()
        runmean = list(map(float, runmean))
        for i in range(nbcols):
            B.set_runmean_i(i, runmean[i])
        #print(runmean)

    # SET_BN_RUNVAR_ID 
    for runvar_name in itertools.islice(lines, 1):
        #print(runvar_name)
        assert runvar_name in SET_BN_RUNVAR_ID
    for runvar in itertools.islice(lines, 1):
        runvar =  runvar.split()    
        runvar = list(map(float, runvar))
        for i in range(nbcols):
            B.set_runvar_i(i, runvar[i])
    return B
            #print(runvar)
def parse_network(inputfile):
    # 1.  input 
    # layers are enumerated
    try:
        myfile = open(inputfile, "r+") # or "a+", whatever you need
    except IOError:
        print ("cannot open".format())
        exit()
    with myfile:
        lines = iter(myfile.read().splitlines())
    layers = [] 
    nb_layers = 0
    for line in lines:
        #print(line)
        if (line[:1] == 'c'):
            continue;   
        if (SET_LAYER_ID in line):             
            L = parse_linear_layer(line, lines, nb_layers)
            layers.append(L)
            nb_layers = nb_layers + 1            

        if (DEF_LAYER_ID in line):
            #print (L)
            L = parse_definition_linear_layer(line, nb_layers)
            layers.append(L)    
            nb_layers = nb_layers + 1 
        
        if SET_LAYER_BN_ID in line:
            L = parse_batchnorm_layer(line, lines, nb_layers)     
            layers.append(L)    
            nb_layers = nb_layers + 1 
                   
    return layers    