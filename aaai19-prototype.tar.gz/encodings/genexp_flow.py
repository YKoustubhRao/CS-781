from __future__ import print_function, division
import os
import argparse
import os
#import pandas as pd
import numpy as np
from parser import *
from con2cnf import *
from utils import *
from bnnencoder import *
from bnnlearner import *
from satsolver import *
from pyminisolvers import minisolvers
import copy

import math 
import string

#  python src/encodings/main.py -s src/encodings/tests/input.txt -c cnf.txt
parser = argparse.ArgumentParser(description='BNN to CNF')
parser.add_argument('--database', '-d', default='mnist10_10', help='Input description file')
parser.add_argument('--gencnfs', '-g', default= False, help='Generate CNF files before running SAT solver')
parser.add_argument('--process', '-p', default= ACTION_CONVER2CNF)
parser.add_argument('--focuslabels_teacher', '-f', nargs='+', type=int, default=[0,1,2,3,4,5,6,7,8,9])
# parser.add_argument('--source', '-s', default='', help='Inputdescription file')
parser.add_argument('--network', '-w', default='', help='Network file')
parser.add_argument('--reduce',   default= True)
parser.add_argument('--restore',  default= False)
parser.add_argument('--acc_drop',  type=float, default=0.0)
parser.add_argument('--timeout',  type=int, default=1000)

args = parser.parse_args()




outdir = '/data/nina_results/loglearn/1229_flow/'
print('mkdir ' + outdir)


for o in range(80,0,-10):
    cnt = 0
    out_min = o
    out_max = o + 10
    while(cnt < 100):
        cnt = cnt + 1
        i1 = random.sample([1,2,3,4,5,10,11,12,13,14], 1)[0]
        i2 = random.randint(6,9)
        j1 = random.sample([1,2,3,4,5,10,11,12,13,14], 1)[0]
        j2 = random.randint(6,9)
        if (o <= 50):
            d = random.randint(2,3)
        if (o > 50 and o <= 70):
            d = random.randint(2,3)            
        if (o > 70):
            d = random.randint(1,1)
        seed = random.randint(1,100000)

        p = math.pow(o/100,1.5)
    
        s =      '/home/nina/workspace/loglearn/timeout -t ' + str(args.timeout) +' -m 20000000'
        s = s +  ' python3.5 /home/nina/workspace/loglearn/src/encodings/main.py'
        s = s +  ' --database  /home/nina/workspace/loglearn/flow_data/'
        s = s +  ' --network /home/nina/workspace/loglearn/flow_data/networks/16x16_200_100_100_1/'
        s = s +  ' --process Generator2ILP' 
        s = s +  ' --gen_nb_grains 3' 
        s = s +  ' --gen_central_points_i '+ str(i1) + " " + str(i2) + " "  + str(15) 
        s = s +  ' --gen_central_points_j '+ str(j1) + " " + str(j2) + " "  + str(15) 
        s = s +  ' --gen_output_min  '+ str(out_min) 
        s = s +  ' --gen_output_max  '+ str(out_max)  
        s = s +  ' --seed  '+ str(seed)
        s = s +  ' --timelim  '+ str(args.timeout)
        s = s +  ' --saveimages  '+ outdir
        s = s +  ' --prev_cir  1 '+ str(d) + " 16 "
        s = s +  ' --card_min  4 2 '+ str(  int(16*16*(max(p-0.1,0))))
        s = s +  ' --card_max  5 300 '+ str( 16*4  + int(16*16*(min(p+0.1,1))))
         
        #s = s +  ' >  '+ outdir + net + '.txt'
        print(s)