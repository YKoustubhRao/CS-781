from __future__ import print_function, division
import os
import argparse
import os
import numpy as np
import math 
from utils.constants import *
import random

def cnf_asm2gcnf(cnf_file_name, asm_file_name, gcnf_file_name, nb_vars, is_suffle_asm):
    # copy to a new file as we need to add the first line  to be in DIMACS format

    try:
        cnf_file = open(cnf_file_name, "r+") # or "a+", whatever you need
    except IOError:
        print ("cannot open {}".format(cnf_file_name))
        exit()
    with cnf_file:
        cnf_lines_raw = cnf_file.read().splitlines()
        cnf_lines = iter(cnf_lines_raw)
        cnf_file.close()

    try:
        asm_file = open(asm_file_name, "r+") # or "a+", whatever you need
    except IOError: 
        print ("cannot open {}".formatasm_file_name())
        exit()
    with asm_file:
        asm_lines_raw = asm_file.read().splitlines()
        if (is_suffle_asm):
            random.shuffle(asm_lines_raw)
        asm_lines = iter(asm_lines_raw)
        asm_file.close()
 
 
    try:
        gcnf_file = open(gcnf_file_name, "w") # or "a+", whatever you need
    except IOError:
        print ("cannot open {}".format(gcnf_file_name))
        exit()


    gcnf_file.write("p gcnf {} {} {}\n".format(nb_vars, len(cnf_lines_raw)+len(asm_lines_raw), len(asm_lines_raw)))
        
    group2asm = {}
    for i, line in enumerate(asm_lines):
        gcnf_file.write("{"+str(i+1)+"} "+line + "\n")
        group2asm[str(i+1)] = int(line.split()[0])

    for line in cnf_lines:
        gcnf_file.write("{0} "+line + "\n")
    gcnf_file.close()
    return group2asm 

def add_first_line2cnf(orig_file, new_file, nb_vars):
    # copy to a new file as we need to add the first line  to be in DIMACS format
    with open(orig_file, 'r') as file:
        # read a list of lines into data
        data = file.readlines()
        file.close()
        data[0]  = "p cnf {} {} \n".format(nb_vars, len(data))  + data[0]
    # and write everything back
    with open(new_file, 'w') as file:
        file.writelines( data )
        file.close()

def process_SAT_solver_output(file_name):
    try:
        myfile = open(file_name, "r+") # or "a+", whatever you need
    except IOError:
        print ("cannot open {}".format(file_name))
        exit()
    with myfile:
        lines = iter(myfile.read().splitlines())
        
    model = []
    res = []
    for line in lines:
        #print(line)
        if (line[:1] == 's'):
            result = line.split()[1]
            #print(result)
        if (line[:1] == 'v'):
            model= line.split()
            model[0] = '0'
            model = model[0:-1]
            model = list(map(int, model))
            print(model)       

    return result, model            


def print_constraints(constraints, constraints_ordering = None):
    print("Print constraints:")
    if (constraints_ordering is not None):
        for id,names in sorted(constraints_ordering.items()):
            params = constraints[names]
            print_constraint(names, params)
    else:
        for names,params in sorted(constraints.items()):
            print_constraint(names, params)

def print_constraint(name, params):
    if (UNARY_CON_ID in name): 
        print_unary_constraint(params)
    if (ASSUMPTION_CON_ID in name): 
        print_assumption_constraint(params)
    if (NXOR_CON_ID  in name): 
        print_nxor_constraint(params)
    if (LIN_REIFIED_CON_ID  in name):     
        print_linear_reified_constraint(params)
    if (WRAP_A_MULT_X_CON_ID  in name):     
        print_wrap_a_mult_x_constraint(params)        
    if (LIN_EQUALITY_CON_ID  in name):     
        print_linear_equality_constraint(params)    
def print_assumption_constraint(inputs):
    print ("ASM: {} = {} ".format(inputs[0], inputs[1]))    

def print_atleastone_constraint(vars_ids):
    for k in vars_ids[:-1]:          
        print ("{} \/ ".format(k), end="")
    print ("ALO: {}".format(vars_ids[-1]))    

def print_nxor_constraint(inputs):
    print ("NXO: {} NXOR {}  <==>  {} ".format(inputs[0], inputs[1], inputs[2]))     

def print_unary_constraint(inputs):
    print ("UNA: {} = {} ".format(inputs[0], inputs[1]))     


def print_xor_constraint(inputs):
    print ("XOR: {} XOR {}  <==>  {} ".format(inputs[0], inputs[1], inputs[2]))     
    

def print_wrap_a_mult_x_constraint(inputs):
    print ("WRAP a mult x: {} REL_1  {}  REL  {} REL_2 {} ".format(inputs[0], inputs[1], inputs[2], inputs[3]))     
    
def form_linear_constraint_name(l,r):
    return "{}_l_{}_r_{}".format(LIN_CON_ID, l,r)    
    




def print_linear_reified_constraint(inputs):
    coeffs       = inputs[0];
    vars_ids     = inputs[1];
    reif_var     = inputs[2];
    constterm    = inputs[3];
    print('LRC: ', end='')
    for k in range(0, len(coeffs)):        
        print ("{}*{} ".format(int(coeffs[k]), vars_ids[k]), end="")
        if k < len(coeffs) -1:
            print(" + ", end="")
        if k > 8:
            print(" .. ", end="")
            break
    if (constterm >= 0):
        print("+", end="")
    print("{} >= 0 <=> {}".format(constterm, reif_var))
    

def print_linear_equality_constraint(inputs):
    coeffs       = inputs[0];
    vars_ids     = inputs[1];
    coeffs_eq_var= inputs[2];
    eq_var       = inputs[3];
    constterm    = inputs[4];
    print('LRE: ', end='')
    for k in range(0, len(coeffs)):        
        print ("{}*{} ".format(int(coeffs[k]), vars_ids[k]), end="")
        if k < len(coeffs) -1:
            print(" + ", end="")
        if k > 8:
            print(" .. ", end="")
            break
    if (constterm >= 0):
        print("+", end="")
    print("{} = {}*{}".format(constterm, coeffs_eq_var, eq_var))
        
def print_linear_constraint(inputs):
    coeffs       = inputs[0];
    vars_ids     = inputs[1];
    constterm    = inputs[2];
    print('LIN: ', end='')
    for k in range(0, len(coeffs)):        
        print ("{}*{} ".format(int(coeffs[k]), vars_ids[k]), end="")
        if k < len(coeffs) -1:
            print(" + ", end="")
        if k > 8:
            print(" .. ", end="")
            break

    print(" +  {} > = 0".format(constterm))
    
    
def print_card_constraint(inputs):
    vars_ids     = inputs[0];
    reif_var     = inputs[1];
    constterm    = inputs[2];
    
    print('CAR: ', end='')
    for k in range(0, len(vars_ids)):        
        print ("{} ".format(vars_ids[k]), end="")
    if (constterm >= 0):
        print("+ ", end="")
    print("{} >= 0 <=> {}".format(constterm, reif_var))
