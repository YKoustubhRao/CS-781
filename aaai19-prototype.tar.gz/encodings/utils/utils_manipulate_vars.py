from __future__ import print_function, division
import numpy as np
import math 


def format_indexes(inds):
    return "_"+"".join(["[{}]".format(x) for x in inds])

def create_indexed_variable_name(name, inds):
    x_id =   ("{}".format(name))
    x_id = x_id  + format_indexes(inds)
    x_id = x_id.replace("-","n_")
    return x_id

def get_sat_value_by_id(var_id, var2cnf, model):
    #print(var_id, var2cnf[var_id])

    cnf_id = var2cnf[var_id]
    var_with_pol = model[cnf_id]
    var_cnf_id = abs(var_with_pol)
    if (var_with_pol <= 0):
        return 0
    else:
        return 1

def get_sat_value_by_cnf_id(cnf_id, model):
    var_with_pol = model[cnf_id]
    var_cnf_id = abs(var_with_pol)
    #print(cnf_id, var_cnf_id)
    if (var_with_pol <= 0):
        return 0
    else:
        return 1