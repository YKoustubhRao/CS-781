###### input defintion
INPUT_ID = 'INPUT' 
LABEL_ID = 'LABEL' 

################# network outpcomes
WINNER_TIE  = -1

########### modes of programm

ACTION_CONVER2CNF = 'Convertor2CNF'
ACTION_LEARNLASTLAYER = 'LearnLastLayer'
ACTION_LEARNREDUCELASTLAYER = 'LearnReduceLastLayer'
ACTION_GENERATOR2ILP = 'Generator2ILP'



############ network definitions
NAME_LINEAR_LAYER_ID = 'LAYER_LIN' 
NAME_BN_LAYER_ID = 'LAYER_BN' 

SET_LAYER_ID = 'SET_LAYER_LIN' 
DEF_LAYER_ID = 'DEF_LAYER_LIN' 

SET_LAYER_BN_ID = 'SET_LAYER_BN' 
SET_BN_EPS_ID = 'SET_LAYERBN_EPS' 
SET_BN_WEIGHT_ID = 'SET_BN_WEIGHT' 
SET_BN_BIAS_ID = 'SET_BN_BIAS' 
SET_BN_RUNMEAN_ID = 'SET_BN_RUNMEAN' 
SET_BN_RUNVAR_ID = 'SET_BN_RUNVAR' 


###### linear layer variables labels
LAYER_VAR_ID = 'a' 
LAYER_BIAS_VAR_ID = 'bias' 
LAYER_REMOVE_A_VAR_ID = 'r' 


###### BatchNorm layer variables labels
LAYER_BN_EPS_ID = 'bn_e'
LAYER_BN_BIAS_ID = 'bn_b'
LAYER_BN_WEIGHT_ID = 'bn_w'
LAYER_BN_RUNMEAN_ID = 'bn_rm'
LAYER_BN_RUNVAR_ID = 'bn_rv'
 

########## constraint symbolic names
LAYER_CON_ID = 'l'
ROW_CON_ID = 'r'
COLUMN_CON_ID = 'c'
WRAP_A_MULT_X_CON_ID = 'wrap_a_mult_x'
NXOR_CON_ID = 'nxor'
AND_CON_ID = 'and'
OR_CON_ID = '__or'
XOR_CON_ID = '_xor'
LIN_REIFIED_CON_ID = 'linR'
LIN_EQUALITY_CON_ID = 'linEquality'
LIN_CON_ID = 'linC'
UNARY_CON_ID = 'unar'
ATLEASTONE_CON_ID = 'atlo'
ASSUMPTION_CON_ID = 'assump'

############ executables

SAT_GEN_FILES_DIR = "./sat_outputs/"
EXE_FILES_DIR = "./executables/"


############# variables for metwork encoding
COLORS_VAR_ID = 'c' 

NEURON_VAR_ID = 'y' 
NEURON_VAR_TEST_ID = 'test_y' 

LAYER_VAR_ID = 'a' 
MULT_VAR_ID = 'q' 
MULT_TWO_LEVEL_ONE_VAR_ID = 'w' 
MULT_TWO_LEVEL_TWO_VAR_ID = 's' 

ORDER_VAR_ID = 'o'
FILE_TEMP_EXTENTION = "_temp"
ASSUMPTIONS_FILE_TEMP_EXTENTION = "_assump"
CNF_FILE_TEMP_EXTENTION = "_cnf"
GCNF_FILE_TEMP_EXTENTION = "_gcnf"
GCNF_FILE_OUT_EXTENTION = "_gout"
############## SAT output 
SOLVER_SAT_RESULT = 'SATISFIABLE'
SOLVER_UNSAT_RESULT = 'UNSATISFIABLE'


############## Output constraints to  
CNF_DESTINATION = 'CNF_DIST'
LIST_DESTINATION = 'LIST_DIST'
SOLVER_DESTINATION = 'SOLVER_DIST'
ILP_SOLVER_DESTINATION = 'ILP_SOLVER_DIST'

############## Learner  SAT output 
LEARNER_POS_RESULT = 'FIT'
LEARNER_NEG_RESULT = 'CORE'

# temp vars

TEST_VAR_PREF_ID = 'test_'
TEMP_VAR_ID = 't'
LINEAR_INEQ_IND_GEQ_ILP_TEMP_VAR_ID = 'lin_ind_geq'
LINEAR_INEQ_IND_LESS_ILP_TEMP_VAR_ID = 'lin_ind_less'
LINEAR_EQ_ILP_TEMP_VAR_ID = 'lin_eq'


SEQCOUNTERS_TEMP_VAR_ID = 's'
CONSTRAINT_TEMP_VAR_PREFIX = "C"


#######################
LOGICAL_BLOCK_LIN_RELU = "linrelu"
LOGICAL_BLOCK_LIN = "lin"

