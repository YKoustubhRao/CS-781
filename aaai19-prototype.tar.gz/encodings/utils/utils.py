from __future__ import print_function, division
import numpy as np
import math 
from utils.constants import *
import random, string
import os


# Print iterations progress
def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 100, fill = '█'):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = '\r')
    # Print New Line on Complete
    if iteration == total: 
        print()


def getkey_by_value(d, search_v):
    for k, v in d.items():
        if  (v == search_v) :
            return k

def print_vec_as_textimage(v, side):
    for i in range(side):
        for j in range(side):
            print('{message: >2}'.format(message = v[side*(i-1)+j]), end='')
        print("")
def createdir (dir):
    try:
        os.stat(dir)
    except:
        os.mkdir(dir)   
    return;

def randomword(length):
   letters = string.ascii_lowercase
   return ''.join(random.choice(letters) for i in range(length))