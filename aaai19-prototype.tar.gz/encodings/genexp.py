from __future__ import print_function, division
import os
import argparse
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from parser import *
from con2cnf import *
from utils import *
from bnnencoder import *
from bnnlearner import *
from satsolver import *
from pyminisolvers import minisolvers
import copy

import math 
import string

#  python src/encodings/main.py -s src/encodings/tests/input.txt -c cnf.txt
parser = argparse.ArgumentParser(description='BNN to CNF')
parser.add_argument('--database', '-d', default='mnist10_10', help='Input description file')
parser.add_argument('--gencnfs', '-g', default= False, help='Generate CNF files before running SAT solver')
parser.add_argument('--process', '-p', default= ACTION_CONVER2CNF)
parser.add_argument('--focuslabels_teacher', '-f', nargs='+', type=int, default=[0,1,2,3,4,5,6,7,8,9])
# parser.add_argument('--source', '-s', default='', help='Inputdescription file')
parser.add_argument('--network', '-w', default='', help='Network file')
parser.add_argument('--reduce',   default= True)
parser.add_argument('--restore',  default= False)
parser.add_argument('--acc_drop',  type=float, default=0.0)
parser.add_argument('--timeout',  type=int, default=100000)

args = parser.parse_args()


networks_name = {'mnist28_28_l_0_1_2_250':[0, 1, 2], 
                 'mnist28_28_l_0_3_6_250':[0, 3, 6], 
                 'mnist28_28_l_2_3_8_250':[2, 3, 8],
                 'mnist28_28_l_3_4_7_250':[3, 4, 7],
                 'mnist28_28_l_1_2_7_250':[1, 2, 7],
                 'mnist28_28_l_2_5_9_250':[2, 5, 9],
                 'mnist28_28_l_4_5_9_250':[4, 5, 9]}


outdir = '/data/nina_results/loglearn/1222_' + str(args.acc_drop).replace(".", "") + '_Reduce' +  str(args.reduce) + "_Restore" +  str(args.restore) + '/'
print('mkdir ' + outdir)
for net in networks_name:
    s =      '/home/nina/workspace/loglearn/timeout -t ' + str(args.timeout) +' -m 20000000'
    s = s +  ' python /home/nina/workspace/loglearn/src/encodings/main.py'
    s = s +  ' --database /home/nina/workspace/loglearn/data/images_vec/mnist28_28_250/'
    s = s +  ' --network  /home/nina/workspace/loglearn/data/networks/' + net
    s = s +  ' --process LearnReduceLastLayer' 
    s = s +  ' --gencnfs False' 
    f = ''.join([str(x) +' ' for x in networks_name[net]])
    s = s +  ' --focuslabels_teacher ' + f
    s = s +  ' --acc_drop ' + str(args.acc_drop) +' '
    s = s +  ' --restore ' + str(args.restore) + ' '
    s = s +  '  --reduce ' + str(args.reduce) + ' ' 
    s = s +  ' >  '+ outdir + net + '.txt'
    print(s)