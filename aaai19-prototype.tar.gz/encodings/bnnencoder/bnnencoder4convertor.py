from __future__ import print_function, division
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from torch.autograd import Variable
from torch.utils.data import Dataset, DataLoader
import os
from PIL import Image
from PIL import ImageOps
import torchvision.models as models

import pandas as pd
from skimage import io, transform
import numpy as np
import matplotlib.pyplot as plt
from adam import Adam

import numpy as np
from parser import *
from con2cnf import *
from utils import *
from parser import *
from layers import *
import json
import math 
import string

class BNNEncoder4Convertor(object):
    """A encoding of BNN to CNFs:
    
    Attributes:
        config file: network structure
    """

    def __init__(self, config, var2cnf):
        #print("start BNNEncoder")
        self.config = config
        self.layers = parse_network(config)
        print(self.layers)

        self.side = int(math.sqrt(self.layers[0].nb_cols))

        self.nb_layers = len(self.layers)
        self.var2cnf = var2cnf
       
        self.global_counter = 0
        self.constraints_ordering = {}
        self.learnable_parameters = {}
    def aux_nxor_for_linear(self, layer,  i, j , constraints):
        ############ form xnor constraint #################             
        # form coeff id
        a_id =  layer.sym_a[i][j]

        # form neuron id
        x_id = create_indexed_variable_name(NEURON_VAR_ID,[layer.id,j]) 
        get_cnf_varid(self.var2cnf, x_id)
 
        # form mult extar var id
        b_id =  create_indexed_variable_name(MULT_VAR_ID,[layer.id,i, j]) 
        get_cnf_varid(self.var2cnf, b_id)
                
        #store NXOR constraint 
        constraints[form_nxor_constraint_name(layer.id,i,j)] = [a_id,x_id, b_id]
        self.constraints_ordering[self.global_counter] = form_nxor_constraint_name(layer.id,i,j)
        self.global_counter += 1
        return b_id
    
    def aux_xor_for_linear(self, layer,  i, j , constraints):
        ############ form xor constraint #################             
        # form coeff id
        a_id =  layer.sym_a[i][j]

        # form neuron id
        x_id = create_indexed_variable_name(NEURON_VAR_ID,[layer.id,j]) 
        get_cnf_varid(self.var2cnf, x_id)
 
        # form mult extar var id
        b_id =  create_indexed_variable_name(MULT_VAR_ID,[layer.id,i, j]) 
        get_cnf_varid(self.var2cnf, b_id)
                
        #store NXOR constraint 
        constraints[form_xor_constraint_name(layer.id,i,j)] = [a_id,x_id, b_id]
        self.constraints_ordering[self.global_counter] = form_xor_constraint_name(layer.id,i,j)
        self.global_counter += 1
        return b_id
#     
    def aux_ineq_for_linear(self, layer, i, constraints, a_coeff = None):
        coeffs = []
        vars_ids = []
        constterm = 0                
        for j in range(0, layer.nb_cols):
            if (a_coeff is None) or (a_coeff == 1): 
                #################################################
                # a[k,i,j] = 1 * y[k,j] = 1 <=>  b[k,i,j] =1
                ###############################################                    
                b_id = self.aux_nxor_for_linear(layer, i, j, constraints)
            else:    
                #################################################
                # -a[k,i,j] = 1 * y[k,j] = 1 <=>  b[k,i,j] =1
                ###############################################                    
                b_id = self.aux_xor_for_linear(layer, i, j, constraints)

            #######################################################
            # form linear constraint 
            ####################################################3
            coeffs = np.append(coeffs, 2)
            vars_ids = np.append(vars_ids, b_id)
            constterm = constterm  - 1 
        return  (coeffs, vars_ids, constterm)

    def aux_ineq_for_linear_with_reduction(self, layer, i, constraints, a_coeff = None):
        coeffs = []
        vars_ids = []
        constterm = 0                
        for j in range(0, layer.nb_cols):
            if (a_coeff is None) or (a_coeff == 1): 
                #################################################
                # a[k,i,j] = 1 * y[k,j] = 1 <=>  b[k,i,j] =1
                ###############################################                    
                b_id = self.aux_nxor_for_linear(layer, i, j, constraints)
            else:    
                #################################################
                # -a[k,i,j] = 1 * y[k,j] = 1 <=>  b[k,i,j] =1
                ###############################################                    
                b_id = self.aux_xor_for_linear(layer, i, j, constraints)

            ############################################################
            # r_i = 0 AND b_i= 0 -->  w = 0 AND s = 1 
            # r_i = 0 AND b_i= 1 -->  w = 1 AND s = 0 
            # r_i = 1 -->  w = 0 AND s = 0 

            
            r_id = layer.sym_r[i][j]
            w_id =  create_indexed_variable_name(MULT_TWO_LEVEL_ONE_VAR_ID,[layer.id,i, j])
            get_cnf_varid(self.var2cnf, w_id)
            s_id =  create_indexed_variable_name(MULT_TWO_LEVEL_TWO_VAR_ID,[layer.id,i, j])
            get_cnf_varid(self.var2cnf, s_id) 
            constraints[form_wrap_a_mult_x_constraint_name(layer.id,i,j)] = [r_id, b_id,w_id,s_id]
            self.constraints_ordering[self.global_counter] = form_wrap_a_mult_x_constraint_name(layer.id,i,j)
            self.global_counter += 1
            
            #######################################################
            # form linear constraint using two variables
            #  w_i - s_i
            ####################################################3
            coeffs = np.append(coeffs, 1)
            vars_ids = np.append(vars_ids, w_id)

            coeffs = np.append(coeffs, -1)
            vars_ids = np.append(vars_ids, s_id) 
        return  (coeffs, vars_ids, constterm)
# 
#     
    def enc2cnf_lin_sign(self, layer, constraints, rhs_all, a_coeff, div_by_value = 1):
        for i in range(0, layer.nb_rows):                
            (coeffs, vars_ids, constterm)  = self.aux_ineq_for_linear(layer, i, constraints, a_coeff[i])
            constterm = constterm - rhs_all[i]                  
            # form output neuron id +2 becuase we count BN as a separate layer
            z_id =  create_indexed_variable_name(NEURON_VAR_ID,[layer.next_lin_id,i])
            get_cnf_varid(self.var2cnf, z_id)
             
            coeffs = [math.floor(c / div_by_value) for c in coeffs]  
            constterm = math.floor(constterm / div_by_value) 
             
            constraints[form_linear_reified_constraint_name(layer.id,i)] = [coeffs, vars_ids, z_id, constterm]
            self.constraints_ordering[self.global_counter] = form_linear_reified_constraint_name(layer.id,i)
            self.global_counter += 1
# 
    def enc2cnf_lin(self, layer, constraints, is_assum = None):
        for i in range(0, layer.nb_rows):                
            self.enc2cnf_matrix_a_row(layer, i, constraints, is_assum)
            (coeffs, vars_ids, constterm)  = self.aux_ineq_for_linear(layer, i, constraints)                  
            # form output neuron id
            constraints[form_linear_constraint_name(layer.id,i)] = [coeffs, vars_ids, constterm]
            self.constraints_ordering[self.global_counter] = form_linear_constraint_name(layer.id,i)
            self.global_counter += 1
    
    def enc2cnf_lin_with_reduction(self, layer, constraints, is_assum = None, row2reduce = None):
        for i in range(0, layer.nb_rows):
            if i in row2reduce:
                self.enc2cnf_matrix_a_row(layer, i, constraints, is_assum = is_assum)
                self.enc2cnf_matrix_r_row(layer, i, constraints, is_assum = is_assum)
            else:
                self.enc2cnf_matrix_a_row(layer, i, constraints)
                self.enc2cnf_matrix_r_row(layer, i, constraints)

            (coeffs, vars_ids, constterm)  = self.aux_ineq_for_linear_with_reduction(layer, i, constraints)                  
            # form output neuron id
            constraints[form_linear_constraint_name(layer.id,i)] = [coeffs, vars_ids, constterm]
            self.constraints_ordering[self.global_counter] = form_linear_constraint_name(layer.id,i)
            self.global_counter += 1


    def enc2cnf_matrix_a_row(self, layer, i, constraints, is_assum = None):
        for j in range(0, layer.nb_cols):
            a_id =  layer.sym_a[i][j]
            a_value =  layer.a[i][j]                                   
            get_cnf_varid(self.var2cnf, a_id)
            if (is_assum is not None):
                constraints[form_assumption_constraint_name(a_id)] = [a_id,  1  if a_value >= 0 else 0]
                #print([a_id,  1  if a_value >= 0 else 0])
                self.constraints_ordering[self.global_counter] = form_assumption_constraint_name(a_id)
                self.learnable_parameters[a_id] = get_cnf_varid(self.var2cnf, a_id)
                self.global_counter += 1
            else:
                constraints[form_unary_constraint_name(a_id)] = [a_id,  1  if a_value >= 0 else 0]
                self.constraints_ordering[self.global_counter] = form_unary_constraint_name(a_id)
                self.global_counter += 1
    
    def enc2cnf_matrix_r_row(self, layer, i, constraints, is_assum = None):
        for j in range(0, layer.nb_cols):
            r_id =  layer.sym_r[i][j]
            r_value =  layer.r[i][j]                                   
            get_cnf_varid(self.var2cnf, r_id)
            if (is_assum is not None):
                constraints[form_assumption_constraint_name(r_id)] = [r_id,  r_value]
                #print([r_id,  1  if a_value >= 0 else 0])
                self.constraints_ordering[self.global_counter] = form_assumption_constraint_name(r_id)
                self.learnable_parameters[r_id] = get_cnf_varid(self.var2cnf, r_id)
                self.global_counter += 1
            else:
                constraints[form_unary_constraint_name(r_id)] = [r_id,  r_value]
                self.constraints_ordering[self.global_counter] = form_unary_constraint_name(r_id)
                self.global_counter += 1
             
    def forward(self, x):
        model_outs = {}
        forward_assignments = {}                
        for j in range(0, len(x)):
            y_id  = create_indexed_variable_name(NEURON_VAR_ID,[0,j])
            forward_assignments[y_id] =  1  if x[j] >= 0 else 0 
                
        for k in range(0, self.nb_layers-1,2):
            layerL = self.layers[k]
            layerB = self.layers[k+1]
            if (layerL.use_reduction_a == True):
                ra = layerL.get_r_dot_a()
                x = ra.dot(x) + layerL.bias
            else:
                x = layerL.a.dot(x) + layerL.bias
            
            
            eps = layerB.eps 
            bias = layerB.bias
            weights = layerB.weights
            runmean = layerB.runmean
            runvar = layerB.runvar
            
            runstd = np.sqrt(runvar +  eps ) 
            invstd = (1 / runstd)
            y = ((x - runmean) * invstd) * weights + bias
            
            for j in range(0, len(y)):
                y_id  = create_indexed_variable_name(NEURON_VAR_ID,[layerB.id + 1,j])
                forward_assignments[y_id] =  1  if y[j] >= 0 else 0 

            x[y >= 0] = 1
            x[y < 0] = -1
        
            x = x.astype(int)
            model_outs[k] = x         
        layerL = self.layers[-1]
        if (layerL.use_reduction_a == True):
            ra = layerL.get_r_dot_a()
            x = ra.dot(x) + layerL.bias
        else:
            x = layerL.a.dot(x) + layerL.bias
        model_outs[self.nb_layers-1] = x
        
        for i in range(0, self.layers[-1].nb_rows):
            for j in range(0, self.layers[-1].nb_rows):    
                if(i == j):
                    continue
                o_id  = create_indexed_variable_name(ORDER_VAR_ID,[i,j])
                forward_assignments[o_id] =  1  if x[i] >= x[j] else 0 
        #print("Forward path  output:   {}".format(x))
        winner  = np.argmax(x)
        x.sort()
        if (x[0] == x[1]):
            winner = WINNER_TIE    
        return forward_assignments, winner
        
    def generate_linear_bn_constraints(self, layerL, layerB, constraints, is_assum = None):        
        # x = a_11 x_1 + .. + a_1n*x_n + b
        
                  #runstd = np.sqrt(runvar +  eps ) 
        #invstd = (1 / runstd)
        
        #y = ((x - runmean) * (1/(runvar +  eps)) * weights + bias
        # y >= 0 <=> b_j = 1
        # ((x - runmean) * sqrt(1/(runvar +  eps))) * weights + bias >= 0  <=> b_j = 1
        # ((x - runmean) * sqrt(1/(runvar +  eps)) )    >= - bias/weights  <=> b_j = 1
        # ((x - runmean)    >= - bias*sqrt(runvar +  eps)/weights  <=> b_j = 1
        # x     >= runmean + - bias*sqrt(runvar +  eps)/weights  <=> b_j = 1
        #  a_11 x_1 + .. + a_1n*x_n      >=  -b  + runmean + - bias*sqrt(runvar +  eps)/weights  <=> b_j = 1
        
        # if weights >=0 then 
        #  a_11 x_1 + .. + a_1n*x_n      >=  CEIL[-b  + runmean + - bias*sqrt(runvar +  eps)/weights]  <=> b_j = 1
        #  bb_11 <=> a_11 _x 1 = (2ab-1)*(2xb-1)
        # a_11 (ab)  x_1 (xb)   bb  b
        #   1   1    1    1     1   1
        #   -1  0    1    1     0   -1
        #   1   1   -1    0     0   -1
        #   -1  0   -1    0     1   1
        # b_11 <=>  a_11 NXOR x_1
        
        # b_11 <=>   -a_11  x_1
        # a_11 (ab)  x_1 (xb)   bb  b
        #   1   1    1    1     0   -1
        #   -1  0    1    1     1   1
        #   1   1   -1    0     1   1
        #   -1  0   -1    0     0   -1
        #b_11 <=>  a_11 XOR x_1
        
        
        #  2b_11 - 1 + .. + 2(b_1n - 1)      -  CEIL[-b  + runmean + - bias*sqrt(runvar +  eps)/weights] >= 0 <=> b_j = 1
        #  b_11  + .. + b_1n    +  1/2(- n - CEIL[-b  + runmean + - bias*sqrt(runvar +  eps)/weights]) >= 0  <=> b_j = 1
        
        
        # if weights < 0 then 
        #  -a_11 x_1 + .. - a_1n*x_n      >=  -FLOOR[-b  + runmean + - bias*sqrt(runvar +  eps)/weights]  <=> b_j = 1
        
        
        
        # FROM LUA y >= mean - carry_bias -  beta*(sqrt(var + e))/gamma
        
        # compute RHS
        rhs_all = {}
        coef_all = {}
        for i in range (layerL.nb_rows):
            rhs = -layerL.bias[i] + layerB.runmean[i] - layerB.bias[i]*(math.sqrt(layerB.runvar[i] + layerB.eps))/layerB.weights[i]
            rhs_floor = math.floor(rhs)
            rhs_ceil = math.ceil(rhs)
            
            if (layerB.weights[i] >= 0):
                rhs_all[i]  = rhs_ceil
                coef_all[i] =  1
            else:
                rhs_all[i]  = -rhs_floor
                coef_all[i]  = -1       

            # set values of a_ij                         
            self.enc2cnf_matrix_a_row(layerL, i, constraints, is_assum)
        # we divide all coffs and the constant term by 2 ()and round down!)   as we know that all coeef are equal to 2     
        self.enc2cnf_lin_sign(layerL, constraints, rhs_all, a_coeff =  coef_all, div_by_value = 2)
    
    def generate_last_linear_constraints_with_reduction(self, layerL, constraints, is_assum = None, row2reduce = None):
        k = len(self.layers) - 1
        self.o = []
        #print(layerL)        
        # set values of a_ij
        if (row2reduce is None):
            row2reduce = []
            #add all rows 
            for i in range(0, layerL.nb_rows):
                row2reduce.append(i)                

        self.enc2cnf_lin_with_reduction(layerL, constraints, is_assum, row2reduce)        
        # ordering            
        for i in range(0, layerL.nb_rows):
            for j in range(0, layerL.nb_rows):                        
                if(i == j):
                    continue            
                coeff_one  = constraints[form_linear_constraint_name(k,i)][0]
                vars_ids_one  = constraints[form_linear_constraint_name(k,i)][1]
                constterm_one  = constraints[form_linear_constraint_name(k,i)][2]
                
                coeff_two  = -1 *constraints[form_linear_constraint_name(k,j)][0]
                vars_ids_two  = constraints[form_linear_constraint_name(k,j)][1]
                constterm_two  = -1 * constraints[form_linear_constraint_name(k,j)][2]            
                
                coeff_new  = np.append(coeff_one,   coeff_two)  
                vars_ids_new  = np.append(vars_ids_one,   vars_ids_two)
                constterm_new = constterm_one + constterm_two
                                         
                o_id = create_indexed_variable_name(ORDER_VAR_ID,[i,j])  
                self.o =  np.append(self.o, o_id)
                get_cnf_varid(self.var2cnf,  o_id)  
                 
                div_by_value = 1
                coeff_new = [math.floor(c / div_by_value) for c in coeff_new]  
                constterm_new = math.floor(constterm_new / div_by_value)           
                 
                constraints[form_linear_reified_constraint_name(k,i,j)] = [coeff_new, vars_ids_new, o_id, constterm_new]
                self.constraints_ordering[self.global_counter] = form_linear_reified_constraint_name(k,i,j)
                self.global_counter += 1                 
                 
                # ensure that the true label bits others
                #constraints[form_unary_constraint_name(o_id)] = [o_id,  1]        

    
    def generate_last_linear_constraints(self, layerL, constraints, is_assum = None):
        k = len(self.layers) - 1
        self.o = []
        #print(layerL)        
        # set values of a_ij
        self.enc2cnf_lin(layerL, constraints, is_assum)
        
        # ordering            
        for i in range(0, layerL.nb_rows):
            for j in range(0, layerL.nb_rows):                        
                if(i == j):
                    continue            
                coeff_one  = constraints[form_linear_constraint_name(k,i)][0]
                vars_ids_one  = constraints[form_linear_constraint_name(k,i)][1]
                constterm_one  = constraints[form_linear_constraint_name(k,i)][2]
                
                coeff_two  = -1 *constraints[form_linear_constraint_name(k,j)][0]
                vars_ids_two  = constraints[form_linear_constraint_name(k,j)][1]
                constterm_two  = -1 * constraints[form_linear_constraint_name(k,j)][2]            
                
                coeff_new  = np.append(coeff_one,   coeff_two)  
                vars_ids_new  = np.append(vars_ids_one,   vars_ids_two)
                constterm_new = constterm_one + constterm_two
                                         
                o_id = create_indexed_variable_name(ORDER_VAR_ID,[i,j])  
                self.o =  np.append(self.o, o_id)
                get_cnf_varid(self.var2cnf,  o_id)  
                 
                div_by_value = 2
                coeff_new = [math.floor(c / div_by_value) for c in coeff_new]  
                constterm_new = math.floor(constterm_new / div_by_value)           
                 
                constraints[form_linear_reified_constraint_name(k,i,j)] = [coeff_new, vars_ids_new, o_id, constterm_new]
                self.constraints_ordering[self.global_counter] = form_linear_reified_constraint_name(k,i,j)
                self.global_counter += 1                 
                 
                # ensure that the true label bits others
                #constraints[form_unary_constraint_name(o_id)] = [o_id,  1]        

    def generate_network_constraints(self):        
        constraints = {}
        
        # for debuging
        self.global_counter = 0
        self.constraints_ordering = {}
        self.learnable_parameters = {}
        
        for k in range(0, self.nb_layers-1,2):
            layerL = self.layers[k]
            layerB = self.layers[k+1]
            self.generate_linear_bn_constraints(layerL, layerB, constraints)
            
        layerL = self.layers[-1]
        self.generate_last_linear_constraints(layerL, constraints)
        #print_constraints(constraints)
        return constraints, self.constraints_ordering

    
   # def enc2cnf(self, cnf_file):
   #     generate_constraints()
    
    def __str__(self):
        s = ""
        for layer in self.layers:
            s = s + "Layer " + str(layer.id) + "\n"
            s = s + layer.__str__()    
        return s    