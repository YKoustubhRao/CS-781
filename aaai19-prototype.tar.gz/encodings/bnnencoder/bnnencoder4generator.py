from __future__ import print_function, division
import numpy as np
from parser import *
from con2cnf import *
from con2ilp import *

from utils import *
from parser import *
from layers import *
import json
import math 
import string

class BNNEncoder4Generator(object):
    """A encoding of BNN to CNFs:
    
    Attributes:
        config file: network structure
    """

    def __init__(self, config, var2cnf):
        #print("start BNNEncoder")
        self.config = config
        self.layers = parse_network(config)
        print(self.layers)

        self.side = int(math.sqrt(self.layers[0].nb_cols))

        self.nb_layers = len(self.layers)
        self.var2cnf = var2cnf
       
        self.global_counter = 0
        self.constraints_ordering = {}
        self.learnable_parameters = {}
        
    def forward(self, x):
        model_outs = {}
        forward_assignments = {}                
        for j in range(0, len(x)):
            y_id  = create_indexed_variable_name(NEURON_VAR_ID,[0,j])
            forward_assignments[y_id] =  1  if x[j] >= 0 else 0 
                
        for k in range(0, self.nb_layers-1,2):
            layerL = self.layers[k]
            layerB = self.layers[k+1]
            if (layerL.use_reduction_a == True):
                ra = layerL.get_r_dot_a()
                x = ra.dot(x) + layerL.bias
            else:
                x = layerL.a.dot(x) + layerL.bias
            
            
            eps = layerB.eps 
            bias = layerB.bias
            weights = layerB.weights
            runmean = layerB.runmean
            runvar = layerB.runvar
            
            runstd = np.sqrt(runvar +  eps ) 
            invstd = (1 / runstd)
            y = ((x - runmean) * invstd) * weights + bias
            y_test = x - runmean + bias/(invstd * weights)
            #print(layerL.a[0], x[0],y[0], runmean[0],  invstd[0],  weights[0],  bias[0])
            #exit()
            for j in range(0, len(y)):
                y_id_test  = TEST_VAR_PREF_ID + create_indexed_variable_name(NEURON_VAR_ID,[layerB.id + 1,j])
                forward_assignments[y_id_test] =  y_test[j]
                    
                y_id  = create_indexed_variable_name(NEURON_VAR_ID,[layerB.id + 1,j])
                forward_assignments[y_id] =  1  if y[j] >= 0 else 0
                #if (weights[j] > 0):
                #    forward_assignments[y_id] =  1  if y[j] >= 0 else 0
                #else:
                #    forward_assignments[y_id] =  1  if y[j] <= 0 else 0
                 

            x[y >= 0] = 1
            x[y < 0] = -1
        
            x = x.astype(int)
            model_outs[k] = x         
        layerL = self.layers[-1]
        if (layerL.use_reduction_a == True):
            ra = layerL.get_r_dot_a()
            x = ra.dot(x) + layerL.bias
        else:
            x = layerL.a.dot(x) + layerL.bias
        
        for j in range(0, len(x)):    
            x_id  = create_indexed_variable_name(NEURON_VAR_ID,[layerL.next_lin_id,j])
            forward_assignments[x_id] =  x[j]
            
        model_outs[self.nb_layers-1] = x
        winner  = x
        return forward_assignments, winner
        
    def generate_linear_bn_constraints(self, layerL, layerB, constraints, is_assum = None):        
        # x = a_11 (2*x_1 - 1)+ .. + a_1n*(2 x_n - 1) + b        
                  #runstd = np.sqrt(runvar +  eps ) 
        #invstd = (1 / runstd)
        
        #y = ((x - runmean) * (1/(runvar +  eps)) * weights + bias
        # y >= 0 <=> b_j = 1
        # ((x - runmean) * sqrt(1/(runvar +  eps))) * weights + bias >= 0  <=> b_j = 1
        # ((x - runmean) * sqrt(1/(runvar +  eps)) )    >= - bias/weights  <=> b_j = 1
        # ((x - runmean)    >= - bias*sqrt(runvar +  eps)/weights  <=> b_j = 1
        # x     >= runmean + - bias*sqrt(runvar +  eps)/weights  <=> b_j = 1
        #  a_11 x_1 + .. + a_1n*x_n      >=  -b  + runmean + - bias*sqrt(runvar +  eps)/weights  <=> b_j = 1
        
        # if weights >=0 then 
        #  a_11 (2*x_1 - 1)+ .. + a_1n*(2 x_n - 1)      >=  CEIL[-b  + runmean + - bias*sqrt(runvar +  eps)/weights]  <=> b_j = 1
        # if weights < 0 then 
        #  -(a_11 (2*x_1 - 1)+ .. + a_1n*(2 x_n - 1))    >=  -FLOOR[-b  + runmean + - bias*sqrt(runvar +  eps)/weights]  <=> b_j = 1
        
        # FROM LUA y >= mean - carry_bias -  beta*(sqrt(var + e))/gamma
        
        # compute RHS
        rhs_all = {}
        coef_all = {}
        for i in range (layerL.nb_rows):
            rhs = -layerL.bias[i] + layerB.runmean[i] - layerB.bias[i]*(math.sqrt(layerB.runvar[i] + layerB.eps))/layerB.weights[i]
            rhs_floor = math.floor(rhs)
            rhs_ceil = math.ceil(rhs)
            
            if (layerB.weights[i] >= 0):
                rhs_all[i]  = rhs_ceil
                coef_all[i] =  1
            else:
                rhs_all[i]  = -rhs_floor
                coef_all[i]  = -1         
        
        for i in range (layerL.nb_rows):
            coeffs = []
            constterm = - rhs_all[i]
                    
            vars_ids = []               
            for j in range(0, layerL.nb_cols):
                # (?) a_ij*(2 xij - 1)
                # 1. coef_all[i]*2*a[i][j]
                # 2. -1*layerL.a[i][j]*coef_all[i]
                coeff = 2*layerL.a[i][j]
                coeff = coeff*coef_all[i]
                constterm = constterm + -1*layerL.a[i][j]*coef_all[i]
                coeffs.append(coeff)
                
                # form neuron id
                x_id = create_indexed_variable_name(NEURON_VAR_ID,[layerL.id,j]) 
                get_cnf_varid(self.var2cnf, x_id)
                vars_ids.append(x_id)


                    
                        
            div_by_value = 2
            coeffs = [math.floor(c / div_by_value) for c in coeffs]  
            constterm = math.floor(constterm / div_by_value)    
            
            z_id =  create_indexed_variable_name(NEURON_VAR_ID,[layerL.next_lin_id,i])
            get_cnf_varid(self.var2cnf, z_id)
            
            constraints[form_linear_reified_constraint_name(layerL.id,i)] = [coeffs, vars_ids, z_id, constterm]
            self.constraints_ordering[self.global_counter] = form_linear_reified_constraint_name(layerL.id,i)
            self.global_counter += 1
                
    
    def generate_last_linear_constraints(self, layerL, constraints, is_assum = None):
        k = len(self.layers) - 1
        
        # ordering            
        for i in range (layerL.nb_rows):
            coeffs = []
            constterm = 0
            vars_ids = []               
            for j in range(0, layerL.nb_cols):
                # (?) a_ij*(2 xij - 1)
                # 1. 2*a[i][j]
                # 2. -1*layerL.a[i][j]
                coeff = 2*layerL.a[i][j]
                constterm = constterm + -1*layerL.a[i][j]
                coeffs.append(coeff)
                
                # form neuron id
                x_id = create_indexed_variable_name(NEURON_VAR_ID,[layerL.id,j]) 
                get_cnf_varid(self.var2cnf, x_id)
                vars_ids.append(x_id)
            
            div_by_value = 1
            coeffs = [math.floor(c / div_by_value) for c in coeffs]  
            constterm = math.floor(constterm / div_by_value)    
            
            z_id =  create_indexed_variable_name(NEURON_VAR_ID,[layerL.next_lin_id,i])
            get_cnf_varid(self.var2cnf, z_id)
            
            coef_z_id = 1
            
            constraints[form_linear_equlaity_constraint_name(layerL.id,i)] = [coeffs, vars_ids, coef_z_id, z_id, constterm]
            self.constraints_ordering[self.global_counter] = form_linear_equlaity_constraint_name(layerL.id,i)
            self.global_counter += 1
                 
                # ensure that the true label bits others
                #constraints[form_unary_constraint_name(o_id)] = [o_id,  1]        

    def generate_network_constraints(self):        
        constraints = {}
        
        # for debuging
        self.global_counter = 0
        self.constraints_ordering = {}
        self.learnable_parameters = {}
        
        for k in range(0, self.nb_layers-1,2):
            layerL = self.layers[k]
            layerB = self.layers[k+1]
            self.generate_linear_bn_constraints(layerL, layerB, constraints)
            
        #print_constraints(constraints)
        layerL = self.layers[-1]
        self.generate_last_linear_constraints(layerL, constraints)
        return constraints, self.constraints_ordering

    
   # def enc2cnf(self, cnf_file):
   #     generate_constraints()
    
    def __str__(self):
        s = ""
        for layer in self.layers:
            s = s + "Layer " + str(layer.id) + "\n"
            s = s + layer.__str__()    
        return s    