from __future__ import print_function, division
import numpy as np
from parser import *
from con2cnf import *
from utils import *
from parser import *
from layers import *
import json
import math 
import string

class BNNEncoder4Learner(object):
    """A encoding of BNN to CNFs:
    
    Attributes:
        config file: network structure
    """

    def __init__(self, config, var2cnf):
        #print("start BNNEncoder")
        self.config = config
        self.layers = parse_network(config)
        print(self.layers)

        self.nb_layers = len(self.layers)
        self.varsym2layer = {}
        # collect all labels 
        learnable_vars_symbol = []
        for i in  range(0, len(self.layers)):
            layer = self.layers[i]
            symbols =  layer.get_all_symbols()
            learnable_vars_symbol.append(symbols)
            for s in symbols:
                self.varsym2layer[s]  = i
                    
        self.learnable_vars_symbol = list(itertools.chain(*learnable_vars_symbol))
        
        self.var2cnf = var2cnf
        for s in self.learnable_vars_symbol: 
             get_cnf_varid(self.var2cnf,  s)
    
             
        #build neurons map
            
#         print(self.var2cnf)    
#         self.learnable_parameters_map = self.get_learnable_vars_symbol_as_dict()
#         print(self.learnable_parameters_map)
    def forward(self, x):
        forward_assignments = {}                
        y = x[:] 
        for j in range(0, len(y)):
            y_id  = create_indexed_variable_name(NEURON_VAR_ID,[0,j])
            forward_assignments[y_id] =  1  if y[j] >= 0 else 0 
            
        for k in range(0, self.nb_layers-1):
            layer = self.layers[k]
            #print(layer.a, y)
            z = layer.a.dot(y)
            if (k < self.nb_layers - 1):
                y = np.sign(z)
                y[y == 0] = 1
                for j in range(0, len(z)):
                    y_id  = create_indexed_variable_name(NEURON_VAR_ID,[layer.id + 1,j])
                    forward_assignments[y_id] =  1  if y[j] >= 0 else 0 

        y = self.layers[-1].a.dot(y)
        for i in range(0, self.layers[-1].nb_rows):
            for j in range(0, self.layers[-1].nb_rows):    
                if(i == j):
                    continue
                o_id  = create_indexed_variable_name(ORDER_VAR_ID,[i,j])
                forward_assignments[o_id] =  1  if y[i] >= y[j] else 0 
        #print("Forward path  output:   {}".format(y))
        winner  = np.argmax(y)
        return forward_assignments, winner

    def set_learnable_vars_asignment_from_dict(self, assigmnet_dict):
        learnable_parameters_assignment_map = []
        for (s,value) in assigmnet_dict.items():
            layer_id =  self.varsym2layer[s]
            layer = self.layers[layer_id]       
            layer.set_a_i_j_by_symbol(s, value)     
        
                     
    def get_learnable_vars_symbol_as_dict(self):
        learnable_parameters_map = []
        for s in self.learnable_vars_symbol:
            learnable_parameters_map.append((s, self.var2cnf[s]))
        return dict(learnable_parameters_map)
    
    def get_learnable_vars_asignment_as_dict(self):
        learnable_parameters_assignment_map = []
        for s in self.learnable_vars_symbol:
            layer_id =  self.varsym2layer[s]
            layer = self.layers[layer_id]       
            value = layer.get_a_i_j_by_symbol(s)     
            learnable_parameters_assignment_map.append((s, value))
        return dict(learnable_parameters_assignment_map)
    
    def aux_nxor_for_linear(self, layer,  i, j , constraints):
        ############ form xnor constraint #################             
        # form coeff id
        a_id =  layer.sym_a[i][j]

        # form neuron id
        x_id = create_indexed_variable_name(NEURON_VAR_ID,[layer.id,j]) 
        get_cnf_varid(self.var2cnf, x_id)

        # form mult extar var id
        b_id =  create_indexed_variable_name(MULT_VAR_ID,[layer.id,i, j]) 
        get_cnf_varid(self.var2cnf, b_id)
               
        #store NXOR constraint 
        constraints[form_nxor_constraint_name(layer.id,i,j)] = [a_id,x_id, b_id]
        return b_id
    
    def aux_ineq_for_linear(self, layer, i, constraints):
        coeffs = []
        vars_ids = []
        constterm = 0                
        for j in range(0, layer.nb_cols):
            #################################################
            # a[k,i,j] = 1 NXOR y[k,j] = 1 <=>  b[k,i,j] =1
            ###############################################                    
            b_id = self.aux_nxor_for_linear(layer, i, j, constraints)
            #######################################################
            # form linear constraint 
            ####################################################3
            coeffs = np.append(coeffs, 2)
            vars_ids = np.append(vars_ids, b_id)
            constterm = constterm  - 1 
        return  (coeffs, vars_ids, constterm)

    
    def enc2cnf_lin_sign(self, layer, constraints, div_by_value = 1):
        for i in range(0, layer.nb_rows):                
            (coeffs, vars_ids, constterm)  = self.aux_ineq_for_linear(layer, i, constraints)                  
            # form output neuron id
            z_id =  create_indexed_variable_name(NEURON_VAR_ID,[layer.id+1,i])
            get_cnf_varid(self.var2cnf, z_id)
            
            coeffs = [math.floor(c / div_by_value) for c in coeffs]  
            constterm = math.floor(constterm / div_by_value) 
            
            constraints[form_linear_reified_constraint_name(layer.id,i)] = [coeffs, vars_ids, z_id, constterm]

    def enc2cnf_lin(self, layer, constraints):
        for i in range(0, layer.nb_rows):                
            (coeffs, vars_ids, constterm)  = self.aux_ineq_for_linear(layer, i, constraints)                  
            # form output neuron id
            constraints[form_linear_constraint_name(layer.id,i)] = [coeffs, vars_ids, constterm]
        
    def enc2cnf_a_matrix(self, layer, constraints):
        for i in range(0, layer.nb_rows):
            for j in range(0, layer.nb_cols):
                a_id =  layer.sym_a[i][j]
                a_value =  layer.a[i][j]                                
                constraints[form_assumption_constraint_name(a_id)] = [a_id,  1  if a_value >= 0 else 0]     
                
    
    def generate_network_constraints(self):
        
        constraints = {}
        self.o = []
        for k in range(0, self.nb_layers):
            layer = self.layers[k]
            
            # unary
            self.enc2cnf_a_matrix(layer, constraints)
            
            #linear 
            # we divide all coffs and the constant term by 2 ()and round down!)   as we know that all coeef are equal to 2     
            self.enc2cnf_lin_sign(layer, constraints, div_by_value = 2)
            if (k == self.nb_layers - 1 and True):
                self.enc2cnf_lin(layer, constraints)
                # ordering            
                for i in range(0, layer.nb_rows):
                    for j in range(0, layer.nb_rows):                        
                        if(i == j):
                            continue            
                        coeff_one  = constraints[form_linear_constraint_name(k,i)][0]
                        vars_ids_one  = constraints[form_linear_constraint_name(k,i)][1]
                        constterm_one  = constraints[form_linear_constraint_name(k,i)][2]
            
                        coeff_two  = -1 *constraints[form_linear_constraint_name(k,j)][0]
                        vars_ids_two  = constraints[form_linear_constraint_name(k,j)][1]
                        constterm_two  = -1 * constraints[form_linear_constraint_name(k,j)][2]            
                
                        coeff_new  = np.append(coeff_one,   coeff_two)  
                        vars_ids_new  = np.append(vars_ids_one,   vars_ids_two)
                        constterm_new = constterm_one + constterm_two
                                                
                        o_id = create_indexed_variable_name(ORDER_VAR_ID,[i,j])  
                        self.o =  np.append(self.o, o_id)
                        get_cnf_varid(self.var2cnf,  o_id)  
                        
                        div_by_value = 2
                        coeff_new = [math.floor(c / div_by_value) for c in coeff_new]  
                        constterm_new = math.floor(constterm_new / div_by_value)           
                        
                        constraints[form_linear_reified_constraint_name(k,i,j)] = [coeff_new, vars_ids_new, o_id, constterm_new]
                        
                        
                        # ensure that the true label bits others
                        #constraints[form_unary_constraint_name(o_id)] = [o_id,  1]
        return constraints
    
    def enc2cnf(self, cnf_file):
        generate_constraints()
    
    def __str__(self):
        s = ""
        for layer in self.layers:
            s = s + "Layer " + str(layer.id) + "\n"
            s = s + layer.__str__()    
        return s    